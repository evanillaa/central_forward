Hallo, dit is mijn eerste GTA mod, de 2017 Ford F-150 Raptor Dutch Police. Ik heb hier aardig wat tijd in zitten, de skin klopt nog niet helemaal, maar dat word gefixt in de volgende versie.

Replaces: policeold1

mods/update/x64/dlcpacks/patchday14ng/dlc.rpf/x64/levels/gta5/vehicles.rpf

Changelog:
2.0:
-Template has been added in file
-Skin retexture
1.0:
-Added license plates
-Skin retexture


Credits:
2017 Ford F150 Raptor - Zach Plays
Achtergrond kleuren: Marked
Contourstriping: JustRPFunMods - Iddo
Striping: JustRPFunMods - Iddo <b>
Logos: JustRPFunMods - Iddo, Marked, MOHAalsmeer
Striping kleuren: JustRPFunMods - Iddo, Marked, MOHaalsmeer
Templates - Zach Plays
Textures - Zach Plays
Skin: QVrolijk
Zwaailampen: MOHaalsmeer

Veel plezier met spelen!