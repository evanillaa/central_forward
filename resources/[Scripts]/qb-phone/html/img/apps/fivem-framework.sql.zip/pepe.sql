-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Gegenereerd op: 11 feb 2021 om 10:47
-- Serverversie: 10.4.14-MariaDB
-- PHP-versie: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pepe-framework`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `characters_accounts`
--

CREATE TABLE `characters_accounts` (
  `id` int(11) NOT NULL,
  `citizenid` varchar(50) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `bankid` varchar(50) DEFAULT NULL,
  `balance` int(20) DEFAULT 0,
  `authorized` varchar(500) DEFAULT NULL,
  `transactions` varchar(60000) DEFAULT '{}'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `characters_bills`
--

CREATE TABLE `characters_bills` (
  `id` int(11) NOT NULL,
  `citizenid` varchar(50) DEFAULT NULL,
  `amount` int(11) DEFAULT NULL,
  `invoiceid` varchar(50) DEFAULT NULL,
  `sender` varchar(50) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `characters_bindings`
--

CREATE TABLE `characters_bindings` (
  `id` int(11) NOT NULL,
  `citizenid` varchar(50) DEFAULT NULL,
  `key` text DEFAULT NULL,
  `command` text DEFAULT NULL,
  `argument` text DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `characters_contacts`
--

CREATE TABLE `characters_contacts` (
  `id` int(11) NOT NULL,
  `citizenid` varchar(50) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `number` varchar(50) DEFAULT NULL,
  `iban` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `characters_houses`
--

CREATE TABLE `characters_houses` (
  `id` int(11) NOT NULL,
  `citizenid` varchar(50) DEFAULT '[]',
  `name` varchar(50) DEFAULT NULL,
  `label` varchar(50) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `tier` int(11) DEFAULT NULL,
  `owned` varchar(50) DEFAULT NULL,
  `coords` text DEFAULT NULL,
  `keyholders` text DEFAULT NULL,
  `decorations` longtext DEFAULT NULL,
  `stash` text DEFAULT NULL,
  `outfit` text DEFAULT NULL,
  `logout` text DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `characters_inventory-stash`
--

CREATE TABLE `characters_inventory-stash` (
  `id` int(11) NOT NULL,
  `stash` varchar(50) NOT NULL,
  `items` longtext DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `characters_inventory-vehicle`
--

CREATE TABLE `characters_inventory-vehicle` (
  `id` int(11) NOT NULL,
  `plate` varchar(50) NOT NULL,
  `trunkitems` longtext DEFAULT NULL,
  `gloveboxitems` longtext DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `characters_mails`
--

CREATE TABLE `characters_mails` (
  `id` int(11) NOT NULL,
  `citizenid` varchar(50) DEFAULT NULL,
  `sender` varchar(50) DEFAULT NULL,
  `subject` varchar(50) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `read` tinytext DEFAULT NULL,
  `mailid` int(11) DEFAULT NULL,
  `date` timestamp NULL DEFAULT current_timestamp(),
  `button` text DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `characters_messages`
--

CREATE TABLE `characters_messages` (
  `id` int(11) NOT NULL,
  `citizenid` varchar(50) DEFAULT NULL,
  `number` varchar(50) DEFAULT NULL,
  `messages` longtext DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `characters_metadata`
--

CREATE TABLE `characters_metadata` (
  `id` int(11) NOT NULL,
  `citizenid` varchar(50) DEFAULT NULL,
  `cid` int(11) DEFAULT NULL,
  `steam` varchar(50) DEFAULT NULL,
  `license` varchar(50) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `money` text DEFAULT NULL,
  `charinfo` text DEFAULT NULL,
  `job` tinytext DEFAULT NULL,
  `position` text DEFAULT NULL,
  `globals` text DEFAULT NULL,
  `inventory` varchar(65000) DEFAULT '[]',
  `ammo` text DEFAULT NULL,
  `licenses` text DEFAULT NULL,
  `skill` varchar(50) DEFAULT NULL,
  `addiction` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `characters_outfits`
--

CREATE TABLE `characters_outfits` (
  `id` int(11) NOT NULL,
  `citizenid` varchar(50) DEFAULT NULL,
  `outfitname` varchar(50) DEFAULT NULL,
  `model` varchar(50) DEFAULT NULL,
  `skin` text DEFAULT NULL,
  `outfitId` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `characters_reputations`
--

CREATE TABLE `characters_reputations` (
  `id` int(11) NOT NULL,
  `citizenid` varchar(50) DEFAULT NULL,
  `job` text DEFAULT NULL,
  `dealer` text DEFAULT NULL,
  `crafting` text DEFAULT NULL,
  `handweaponcrafting` text DEFAULT NULL,
  `weaponcrafting` text DEFAULT NULL,
  `attachmentcrafting` text DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `characters_skins`
--

CREATE TABLE `characters_skins` (
  `id` int(11) NOT NULL,
  `citizenid` varchar(50) NOT NULL DEFAULT '',
  `model` varchar(50) NOT NULL DEFAULT '0',
  `skin` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `characters_vehicles`
--

CREATE TABLE `characters_vehicles` (
  `id` int(11) NOT NULL,
  `citizenid` varchar(50) DEFAULT NULL,
  `vehicle` varchar(50) DEFAULT NULL,
  `plate` varchar(50) DEFAULT NULL,
  `garage` varchar(50) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `mods` text DEFAULT NULL,
  `metadata` mediumtext DEFAULT NULL,
  `forSale` int(11) DEFAULT 0,
  `salePrice` int(11) DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `laws`
--

CREATE TABLE `laws` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `fine` int(11) NOT NULL DEFAULT 0,
  `months` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `laws`
--

INSERT INTO `laws` (`id`, `name`, `description`, `fine`, `months`) VALUES
(9, 'Artikel 447e - Wet identificatieplicht', 'Hij die niet voldoet aan de verplichting om een identiteitsbewijs ter inzage aan te bieden of medewerking te verlenen aan het nemen van een of meer vingerafdrukken.', 4150, 1),
(10, 'Artikel 461 - Verboden toegang', 'Hij die, zonder daartoe gerechtigd te zijn, zich op eens anders grond waarvan de toegang op een voor hem blijkbare wijze door de rechthebbende is verboden, bevindt of daar vee laat lopen.', 415, 1),
(11, 'Artikel 239 - Zedelijkheid', 'schennis van de eerbaarheid:\r\n1: op of aan een plaats, voor het openbaar verkeer bestemd;\r\n2: op een andere dan onder 1Â° bedoelde openbare plaats, toegankelijk voor personen beneden de leeftijd van zestien jaar;\r\n3: op een niet openbare plaats, indien een ander daarbij zijns ondanks tegenwoordig is. ', 4350, 3),
(12, 'Artikel 184 - Niet voldoen aan een bevel of vordering', 'Hij die opzettelijk niet voldoet aan een bevel of een vordering. Weg vluchten van de politie hoort hier bij', 2500, 3),
(13, 'Artikel 6 - Wegenverkeerswet (Ongeval met verwonding)', 'Het is een ieder die aan het verkeer deelneemt verboden zich zodanig te gedragen dat een aan zijn schuld te wijten verkeersongeval plaatsvindt waardoor een ander wordt gedood of waardoor een ander zwaar lichamelijk letsel wordt toegebracht of zodanig lichamelijk letsel dat daaruit tijdelijke ziekte of verhindering in de uitoefening van de normale bezigheden ontstaat.', 2500, 12),
(14, 'Artikel 7 - Wegenverkeerswet (Wegrijden van ongeval)', 'Wegvluchten na een verkeers ongeval.', 435, 7),
(15, 'Artikel 267 - Belediging ambt.', 'Het beledigen met een bepaalde taal/woord keuze naar een ambtenaar in functie toe.', 600, 0),
(16, 'R602 - Niet stoppen voor rood licht', 'Het negeren van het rode stoplicht.', 240, 0),
(17, 'R601 - Niet doorgaan bij groen licht', 'Niet door rijden bij het krijgen van een groen licht teken door een stoplicht.', 140, 0),
(18, 'R628b - Niet opvolgen stopteken politie', 'Het negeren van een stop teken van een dienstvoertuig bij een verkeerscontrole.', 390, 0),
(19, 'R326 - Rechts inhalen', 'Het illegaal inhalen van een ander voertuig via de rechterkant.', 240, 0),
(20, 'D505 - Baldadigheid', 'Overtreding door zich in het openbaar tegen personen of goederen zodanig ruw en onbezonnen te gedragen dat daardoor nadeel kan ontstaan.\r\n', 415, 0),
(21, 'D510 - Openbaar dronkenschap', 'Door verdovende middelen beÃ¯nvloed zijn in het openbaar.', 415, 0),
(22, 'Administratiekosten', 'Standaard administratie kosten politie Los Santos.', 9, 0),
(23, 'D517 - Identiteitsbewijs', 'Geen Legitimatie bij zich hebben.', 95, 0),
(24, 'D515 - Valse gegevens opgeven', 'Het verlenen van valse informatie over de persoon zelf.', 380, 0),
(25, 'D537 - Verboden toegang', 'Het schenden van een verboden toegangs-zone.', 95, 0),
(26, 'F116a - Inbrekerswerktuig', 'In bezit zijn van inbrekerswerktuig. (Lockpicks zijn alleen inbrekerswerktuig als de verdachte een gekwalificeerde diefstal of diefstal met geweld heeft gedaan)', 415, 0),
(27, 'F120a - Klimmen of klauteren', 'Klimmen of zich bevinden op een beeld, monument, overkapping.', 95, 0),
(28, 'F120b - Overlast veroorzaken', 'Het verstoren van de openbare orde.', 140, 0),
(29, 'F125a - Onnodig ophouden', 'Het onnodig ophouden.', 95, 0),
(31, 'R397 - Foutief parkeren', 'Het foutief parkeren van het desbetreffende voertuig.', 95, 0),
(32, 'R395 - Gevaar of hinder veroorzaken met een stilstaand voertuig', 'Dat het verboden is om gevaar of hinder te veroorzaken volgt uit artikel 5 van de Wegenverkeerswet.', 140, 0),
(33, 'Geldboete van de 1e categorie', 'Voor elk strafbaar feit kunt u een geldboete krijgen. Strafbare geiten zijn ingedeeld in 4 categorieÃ«n. De categorie bepaalt de maximale hoogte van de boete ', 435, 0),
(34, 'Geldboete van de 2e categorie', 'Voor elk strafbaar feit kunt u een geldboete krijgen. Strafbare geiten zijn ingedeeld in 4 categorieÃ«n. De categorie bepaalt de maximale hoogte van de boete ', 4350, 0),
(35, 'Geldboete van de 3e categorie', 'Voor elk strafbaar feit kunt u een geldboete krijgen. Strafbare geiten zijn ingedeeld in 4 categorieÃ«n. De categorie bepaalt de maximale hoogte van de boete ', 8700, 0),
(36, 'Geldboete van de 4e categorie', 'Voor elk strafbaar feit kunt u een geldboete krijgen. Strafbare geiten zijn ingedeeld in 4 categorieÃ«n. De categorie bepaalt de maximale hoogte van de boete ', 21750, 0),
(37, 'R536a - Geen helm dragen op een bromfiets', 'Het niet dragen van een beschermende helm op een bromfiets.', 140, 0),
(38, 'R536b - Geen helm dragen op een motorfiets', 'Het niet dragen van een beschermende helm op een motorfiets.', 140, 0),
(39, 'VA 015 - Snelheidsoverschrijding 15 km/h', 'Het overschrijden van de maximale snelheid met 15 km/h', 185, 0),
(40, 'VA 020 - Snelheidsoverschrijding 20 km/h', 'Het overschrijden van de maximale snelheid met 20 km/h', 257, 0),
(41, 'VA 030 - Snelheidsoverschrijding 30 km/h', 'Het overschrijden van de maximale snelheid met 30 km/h', 430, 0),
(42, 'VA 040 - Snelheidsoverschrijding 40 km/h', 'Het overschrijden van de maximale snelheid met 40 km/h', 525, 0),
(43, 'VA 050 - Snelheidsoverschrijding 50 km/h', 'Het overschrijden van de maximale snelheid met 50 km/h', 700, 0),
(44, 'Artikel 13 - WWM Categorie I', 'Het is verboden een wapen of munitie van de categorieÃ«n I in bezit te hebben.\r\n\r\nHier onder vallen alle voorwerpen die als een slag/steek wapen gebruikt kan worden (Messen/Hamers/Boksbeugels en zo)', 350, 0),
(45, 'Artikel 45  - Poging en/of voorbereiding', 'Poging tot misdrijf is strafbaar, wanneer het voornemen van de dader zich door een begin van uitvoering heeft geopenbaard.', 0, 0),
(46, 'K030 - Kenteken niet behoorlijk zichtbaar op/aan moter voertuig', 'Geen zichtbaar kenteken hebben of het kenteken is erg slecht zichtbaar.', 140, 0),
(47, 'N420d - Lichtdoorlatendheid ruiten minder dan 55%', 'Het motor voertuig heeft te donkere ruiten waar je niet doorheen kan kijken. Hierbij komt meestal ook een WOK status.', 240, 0),
(49, 'Artikel 10 - Wegenverkeerswet (Racen)', 'Het is verboden op de weg een wedstrijd met voertuigen te houden of daaraan deel te nemen.', 4350, 4),
(50, 'Artikel 48 - Medeplichtigheid', 'Het medeplichtig zijn van een illegale activiteit.', 0, 0),
(51, 'Artikel 4 - Gezichtsbedekking', 'Het bedekken van het gezicht met bijvoorbeeld een masker of bivak.', 120, 0),
(52, 'Artikel 231b - Valsheid met geschriften, gegevens en biometrische kenmerken', 'Hij die opzettelijk en wederrechtelijk identificerende persoonsgegevens, niet zijnde biometrische persoonsgegevens, van een ander gebruikt met het oogmerk om zijn identiteit te verhelen of de identiteit van de ander te verhelen of misbruiken, waardoor uit dat gebruik enig nadeel kan ontstaan.', 4200, 0),
(53, 'R549a - Niet stoppen bij stopbord', 'Het negeren van het verkeer stopbord.', 140, 0),
(54, 'R421a - Geen dim- of grootlicht voeren bij nacht', 'Het niet aan hebben van het motorvoertuig\'s licht systeem in de nacht ', 95, 0),
(55, 'K150c - Rijbewijs niet kunnen tonen', 'Niet op eerste vordering behoorlijk het rijbewijs ter inzage afgeven', 500, 0),
(57, 'Artikel 9 - Wegenverkeerswet (Rijden zonder rijbewijs)', 'Het is degene die weet of redelijkerwijs moet weten dat hem bij rechterlijke uitspraak of strafbeschikking de bevoegdheid tot het besturen van motorrijtuigen is ontzegd, Bijvoorbeeld wanneer de verdachte zijn rijbewijs is ingetrokken door de politie en hij rijdt opnieuw rond, Of rijd rond zonder een rijbewijs te hebben', 2000, 6),
(59, 'Artikel 188 - Valse aangifte', 'Het opgeven van een valse aangifte.', 1150, 12),
(61, 'Artikel 138 - Huisvredebreuk', 'Het betreden van iemand ander zijn eigendom of grond zonder toestemming.', 1250, 12),
(62, 'Artikel 196 - Onrechtmatig voordoen als een politie ambt.', 'Het na doen van een politie ambtenaar in functie.', 435, 12),
(63, 'Artikel 3 - Opiumwet (Softdrugs)(Eigen gebruik)', 'Het is verboden een middel als bedoeld in de bij deze wet behorende lijst op zak te hebben, Voorbeelden zijn Cannabisproducten (hasj en wiet) en Pijnstillers (Max 5gram= 5 zakjes en/of 5 pijnstillers)', 2250, 12),
(64, 'Artikel 2 - Opiumwet (Hard drugs)(Eigen gebruik)', 'Het is verboden een middel als bedoeld in de bij deze wet behorende lijst op zak te hebben, Voorbeelden zijn heroÃ¯ne, cocaÃ¯ne, amfetamine, xtc en GHB. (Eigen gebruik = 1 zakje)(Meer dan 1zakje of 1 soort drug = Dealer)', 4350, 15),
(65, 'Artikel 285 - Bedreiging', 'Het bedreigen van een burger of ambtenaar in functie op een dodelijke wijze.', 1500, 18),
(66, 'Artikel 300 - Mishandeling', 'Het mishandelen van een burger of ambtenaar in functie.', 4350, 20),
(67, 'Artikel 310 - Eenvoudige diefstal (Beroven)', 'Het stelen of afpakken van simpele goederen die niet van deze persoon zijn. (Beroven van mensen)', 950, 15),
(68, 'Artikel 141 - Openlijke geweldpleging', 'Geweld plegen tegen een burger of ambtenaar in een openbare plek/ruimte waar andere burgers bij zijn.', 1500, 30),
(69, 'Artikel 416 - Heling (Diefstal van voertuigen)', 'Diefstal van iemands eigendom.', 4350, 20),
(70, 'Artikel 326 - Oplichting', 'Het oplichten van een burger of ambtenaar in functie. Vormen van oplichting is meestal in de richting van goederen, geld of auto\'s.', 2500, 28),
(72, 'Artikel 5 - Wegenverkeerswet (gevaarlijk rijden)', 'Het is een ieder verboden zich zodanig te gedragen dat gevaar op de weg wordt veroorzaakt of kan worden veroorzaakt of dat het verkeer op de weg wordt gehinderd of kan worden gehinderd', 850, 2),
(73, 'Artikel 8 - Wegenverkeerswet (Rijden onder invloed)', 'Het is een ieder verboden een voertuig te besturen of als bestuurder te doen besturen, terwijl hij verkeert onder zodanige invloed van een stof, waarvan hij weet of redelijkerwijs moet weten, dat het gebruik daarvan - al dan niet in combinatie met het gebruik van een andere stof - de rijvaardigheid kan verminderen, dat hij niet tot behoorlijk besturen in staat moet worden geacht. ', 435, 3),
(74, 'Artikel 266 - Eenvoudige belediging', 'Komt nog', 435, 0),
(75, 'Artikel 142 - Misbruik noodnummer', 'Het maken van een valse 112 melding.', 3400, 0),
(76, 'Artikel 435a - Overtreding openbare orde', 'Hij die in het openbaar kledingstukken of opzichtige onderscheidingstekens draagt of voert, welke uitdrukking zijn van een bepaald staatkundig streven.', 2350, 0),
(77, 'Artikel 367 - Helpen bij ontsnapping', 'Het helpen bij een ontsnapping van een persoon.', 4350, 2),
(78, 'Artikel 180 - Wederspanningheid', 'Hij die zich met geweld of bedreiging met geweld verzet tegen een ambtenaar werkzaam in de rechtmatige uitoefening van zijn bediening.', 2250, 12),
(79, 'Artikel 261 - Smaad & Laster', 'BeÂ­jeÂ­geÂ­ning die ieÂ­mands eer, goeÂ­de naam of aanÂ­zien aanÂ­tast, opÂ­zetÂ­teÂ­lijÂ­ke grieÂ­venÂ­de beÂ­leÂ­diÂ­ging', 4750, 12),
(80, 'Artikel 307 - Dood door schuld', 'Hij aan wiens schuld de dood van een ander te wijten is.', 4350, 24),
(81, 'Artikel 350 - Vandalisme', 'Het opzettelijk vernielen van iemands eigendommen.', 435, 20),
(82, 'Artikel 317 - Afpersing en afdreiging', 'Hij die, met het oogmerk om zich of een ander wederrechtelijk te bevoordelen, door geweld of bedreiging met geweld iemand dwingt hetzij tot de afgifte van enig goed dat een persoon bezit.', 1250, 32),
(83, 'Artikel 311 - Gekwalificeerde diefstal (Winkels/Bank/Huizen)', 'Diefstal met braak, Bijvoorbeeld Kassa\'s, Bank, Huizen.', 1750, 25),
(84, 'Artikel 177 - Omkoping', 'Poging tot het omkopen van een ambtenaar in functie.', 2500, 30),
(85, 'Artikel 420 - Witwassen', 'Het witwassen van oneerlijk gekregen geld.', 4350, 30),
(86, 'Artikel 225 - Bewijsschrift vervalsen', 'Hij die een geschrift dat bestemd is om tot bewijs van enig feit te dienen, valselijk opmaakt of vervalst.', 2500, 25),
(87, 'Artikel 282 - Gijzeling', 'Hij die opzettelijk iemand wederrechtelijk van de vrijheid berooft of beroofd houdt.', 4380, 35),
(88, 'Artikel 302 - Zware mishandeling', 'Hij die aan een ander opzettelijk zwaar lichamelijk letsel toebrengt, wordt, als schuldig aan zware mishandeling berecht.', 4350, 35),
(89, 'Artikel 312 - Diefstal met geweld (Overvallen met wapens of gijzelaars', 'Het plegen van een diefstal met een geweldsmiddel of wapen, Een diefstal/Overval met gijzelaar word ook als diefstal met geweld beschouwd.', 3250, 40),
(91, 'Artikel 255 - Verlating van hulpbehoevenden', 'Hij die opzettelijk iemand tot wiens onderhoud, verpleging of verzorging hij krachtens wet of overeenkomst verplicht is, in een hulpeloze toestand brengt of laat, wordt gestraft met gevangenisstraf van ten hoogste twee jaren of geldboete van de vierde categorie.\r\n', 4350, 35),
(92, 'Artikel 287 - Poging Doodslag', 'Hij die opzettelijk een ander van het leven berooft, wordt, als schuldig aan doodslag, gestraft met gevangenisstraf van ten hoogste vijftien jaren of geldboete van de vijfde categorie.\r\n', 4350, 45),
(93, 'Artikel 289 - Moord', 'Het vermoorden van een burger.', 5250, 50),
(97, 'Artikel 47b - Heterdaad Grinden', 'Iemand op heterdaad betrappen op het grinden.', 12, 5),
(98, 'Inbeslagname Voertuig', 'Vul het Auto inbelslagname pv even in vullen en deze toevoegen!', 0, 0),
(99, 'Artikel 61a - Gebruiken van mobiele telecommunicatieapparatuur', 'Het is degene die een motorvoertuig, bromfiets, snorfiets of gehandicaptenvoertuig dat is uitgerust met een motor bestuurt verboden tijdens het rijden een mobiele telefoon vast te houden.', 140, 0),
(101, 'Artikel 359 - Verduistering', 'is het zich opzettelijk wederrechtelijk toe-eigenen van een goed dat aan een ander toebehoort welk goed men anders dan als gevolg van een misdrijf onder zich heeft.', 15000, 32),
(102, 'Artikel 363 - Corruptie', 'Ambtenaar in functie die corruptie heeft begaan.', 12500, 30),
(103, 'Artikel 26 - WWM Categorie II', 'Het is verboden een wapen of munitie van de categorieÃ«n II in bezit te hebben.\r\n\r\nHieronder vallen vuurwapens waar geen automatisch vuur met gegeven wordt. (SNS/Vintage)\r\n', 4350, 12),
(104, 'Artikel 26 - WWM Categorie III', 'Het is verboden een wapen of munitie van de categorieÃ«n III in bezit te hebben.\r\n\r\nHieronder vallen vuurwapens waar automatisch vuur met gegeven wordt. (AP pistol/Tec9/Mini SMG en zwaardere wapens)\r\n', 6700, 18),
(106, 'Artikel 31 - WWM Wapen handel', 'Het is verboden om een wapen of munitie van de categorieÃ«n II en/of III over te dragen/Verhandelen of verkopen. ', 8350, 26),
(107, 'Artikel 3 - Opiumwet (Softdrugs)(Dealer)', '(Lijst 2 o.a. Softdrugs) Het is verboden een middel als bedoeld in de bij deze wet behorende lijst op zak te hebben, te telen, te bereiden, te bewerken, te verwerken, te verkopen, af te leveren, te verstrekken of te vervoeren, Voorbeelden zijn Cannabisproducten (hasj en wiet) en Pijnstillers, Een verdachte word als dealer gezien als hij meer dan 5 gram drugs of 5 pillen opzak heeft, Dit kan gecombineerd zijn.', 4350, 24),
(108, 'Artikel 2 - Opiumwet (Hard drugs)(Dealer)', 'Het is verboden een middel als bedoeld in de bij deze wet behorende lijst op zak te hebben, te telen, te bereiden, te bewerken, te verwerken, te verkopen, af te leveren, te verstrekken of te vervoeren, Voorbeelden zijn heroÃ¯ne, cocaÃ¯ne, amfetamine, xtc en GHB, Een verdachte word als dealer gezien als hij meer dan 0,5 gram of 1 pil(Xtc) opzak heeft', 8700, 30),
(109, 'Artikel 987 - Niet voldoen aan corona maatregelen', 'Het niet voldoen aan de corona maatregelen of regels.', 50, 2),
(110, 'Artikel 47A - Heterdaad Janken', 'Waneer een verdachte heterdaad aan het janken is na een aanhouding. (Breng deze naar de jank vijver blokkenpark)', 13, 0);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `profiles`
--

CREATE TABLE `profiles` (
  `id` int(11) NOT NULL,
  `citizenid` varchar(255) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `avatar` varchar(255) DEFAULT 'https://i.imgur.com/tdi3NGa.png',
  `fingerprint` varchar(255) DEFAULT NULL,
  `dnacode` varchar(255) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `lastsearch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `reports`
--

CREATE TABLE `reports` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `profileid` int(11) DEFAULT NULL,
  `report` text NOT NULL,
  `laws` text DEFAULT NULL,
  `created` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `server_bans`
--

CREATE TABLE `server_bans` (
  `id` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `steam` varchar(50) DEFAULT NULL,
  `license` varchar(50) DEFAULT NULL,
  `reason` varchar(100) DEFAULT NULL,
  `bannedby` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `server_extra`
--

CREATE TABLE `server_extra` (
  `id` int(11) NOT NULL,
  `steam` varchar(50) DEFAULT NULL,
  `license` varchar(50) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `permission` varchar(50) DEFAULT 'user',
  `priority` int(11) DEFAULT 2
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL,
  `rank` varchar(255) NOT NULL,
  `last_login` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `vehicles`
--

CREATE TABLE `vehicles` (
  `id` int(11) NOT NULL,
  `citizenid` varchar(255) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `plate` varchar(255) NOT NULL,
  `typevehicle` varchar(255) NOT NULL,
  `avatar` varchar(255) DEFAULT 'https://i.imgur.com/tdi3NGa.png',
  `note` text DEFAULT NULL,
  `lastsearch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `vehicles`
--

INSERT INTO `vehicles` (`id`, `citizenid`, `fullname`, `plate`, `typevehicle`, `avatar`, `note`, `lastsearch`) VALUES
(1, 'CND70372', 'Samuel Torros', '5GT093UX', 'TOROS', 'https://imgur.com/E6diRoH.png', 'TOROS<br />\r\nKenteken: 5GT093UX<br />\r\n <br />\r\nEigenaar: Samuel Torros<br />\r\n <br />\r\nAPK: Ja<br />\r\nGesignaleerd: Nee', 1610050927),
(2, 'TIH96369', 'Frits de Wit', '4IL501NY', '911Turbos', 'https://cdn.discordapp.com/attachments/720411017435414569/789577553701896192/unknown.png', '911TURBOS<br />\r\nKenteken: 4IL501NY<br />\r\n <br />\r\nEigenaar: Frits de Wit<br />\r\n <br />\r\nAPK: Ja<br />\r\nGesignaleerd: Nee', 1610050933);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `warrants`
--

CREATE TABLE `warrants` (
  `id` int(11) NOT NULL,
  `citizenid` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `title` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `warrants`
--

INSERT INTO `warrants` (`id`, `citizenid`, `description`, `title`, `author`, `created`) VALUES
(8, 'MNS29913', 'Zie Proces Verbaal Nummer: 188', 'ARRESTATIEBEVEL: Art. 287, Art. 6 WvW, Art. 310 en Art. 141', 'Jan Ravenakkers', '2021-01-03 12:31:26'),
(9, 'LYS96323', 'Zie Proces Verbaal Nummer: 190', 'ARRESTATIEBEVEL: Art. 287, Art. 310 en Art. 141', 'Jan Ravenakkers', '2021-01-03 12:31:58');

--
-- Indexen voor geëxporteerde tabellen
--

--
-- Indexen voor tabel `characters_accounts`
--
ALTER TABLE `characters_accounts`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `characters_bills`
--
ALTER TABLE `characters_bills`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `characters_bindings`
--
ALTER TABLE `characters_bindings`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `characters_contacts`
--
ALTER TABLE `characters_contacts`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `characters_houses`
--
ALTER TABLE `characters_houses`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `characters_inventory-stash`
--
ALTER TABLE `characters_inventory-stash`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `characters_inventory-vehicle`
--
ALTER TABLE `characters_inventory-vehicle`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `characters_mails`
--
ALTER TABLE `characters_mails`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `characters_messages`
--
ALTER TABLE `characters_messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `characters_metadata`
--
ALTER TABLE `characters_metadata`
  ADD PRIMARY KEY (`id`),
  ADD KEY `citizenid` (`citizenid`);

--
-- Indexen voor tabel `characters_outfits`
--
ALTER TABLE `characters_outfits`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `characters_reputations`
--
ALTER TABLE `characters_reputations`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `characters_skins`
--
ALTER TABLE `characters_skins`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `characters_vehicles`
--
ALTER TABLE `characters_vehicles`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `laws`
--
ALTER TABLE `laws`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `profiles`
--
ALTER TABLE `profiles`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `reports`
--
ALTER TABLE `reports`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `server_bans`
--
ALTER TABLE `server_bans`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `server_extra`
--
ALTER TABLE `server_extra`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexen voor tabel `vehicles`
--
ALTER TABLE `vehicles`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `warrants`
--
ALTER TABLE `warrants`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT voor geëxporteerde tabellen
--

--
-- AUTO_INCREMENT voor een tabel `characters_accounts`
--
ALTER TABLE `characters_accounts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT voor een tabel `characters_bills`
--
ALTER TABLE `characters_bills`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=175;

--
-- AUTO_INCREMENT voor een tabel `characters_bindings`
--
ALTER TABLE `characters_bindings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT voor een tabel `characters_contacts`
--
ALTER TABLE `characters_contacts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1112;

--
-- AUTO_INCREMENT voor een tabel `characters_houses`
--
ALTER TABLE `characters_houses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT voor een tabel `characters_inventory-stash`
--
ALTER TABLE `characters_inventory-stash`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT voor een tabel `characters_inventory-vehicle`
--
ALTER TABLE `characters_inventory-vehicle`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=154;

--
-- AUTO_INCREMENT voor een tabel `characters_mails`
--
ALTER TABLE `characters_mails`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=237;

--
-- AUTO_INCREMENT voor een tabel `characters_messages`
--
ALTER TABLE `characters_messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=259;

--
-- AUTO_INCREMENT voor een tabel `characters_metadata`
--
ALTER TABLE `characters_metadata`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT voor een tabel `characters_outfits`
--
ALTER TABLE `characters_outfits`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=874;

--
-- AUTO_INCREMENT voor een tabel `characters_reputations`
--
ALTER TABLE `characters_reputations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT voor een tabel `characters_skins`
--
ALTER TABLE `characters_skins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT voor een tabel `characters_vehicles`
--
ALTER TABLE `characters_vehicles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT voor een tabel `laws`
--
ALTER TABLE `laws`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=111;

--
-- AUTO_INCREMENT voor een tabel `profiles`
--
ALTER TABLE `profiles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT voor een tabel `reports`
--
ALTER TABLE `reports`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT voor een tabel `server_bans`
--
ALTER TABLE `server_bans`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT voor een tabel `server_extra`
--
ALTER TABLE `server_extra`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT voor een tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT voor een tabel `vehicles`
--
ALTER TABLE `vehicles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT voor een tabel `warrants`
--
ALTER TABLE `warrants`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
