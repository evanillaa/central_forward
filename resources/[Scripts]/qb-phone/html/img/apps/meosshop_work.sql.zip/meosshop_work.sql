-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Gegenereerd op: 11 feb 2021 om 11:06
-- Serverversie: 5.7.31
-- PHP-versie: 7.4.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `meosshop_work`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `logs`
--

CREATE TABLE `logs` (
  `logid` bigint(20) NOT NULL,
  `user` mediumtext NOT NULL,
  `content` mediumtext NOT NULL,
  `category` mediumtext NOT NULL,
  `dateline` bigint(20) NOT NULL,
  `visible` int(1) NOT NULL DEFAULT '1' COMMENT '1 = Visible, 0 = Hidden'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `logs`
--

INSERT INTO `logs` (`logid`, `user`, `content`, `category`, `dateline`, `visible`) VALUES
(1, 'f99bdcdd482aea00dec18d03f476d346144da7eb', 'Tom Komkommer Boete uitgeschreven aan Juan Jose Garcia Fuentes voor Alcohol op straat nuttigen (+ overlast)', 'Nieuwe Boete', 1611066195, 1),
(2, 'f99bdcdd482aea00dec18d03f476d346144da7eb', 'Tom Komkommer Boete uitgeschreven aan Juan Jose Garcia Fuentes voor Met een voertuig onnodig geluid producen (Gasgeven)', 'Nieuwe Boete', 1611066201, 1),
(3, 'f99bdcdd482aea00dec18d03f476d346144da7eb', 'Tom Komkommer Boete uitgeschreven aan Elf Een voor Alcohol op straat nuttigen (+ overlast)', 'Nieuwe Boete', 1611066208, 1),
(4, 'f99bdcdd482aea00dec18d03f476d346144da7eb', 'Tom Komkommer Boete uitgeschreven aan Elf Een voor Op eerste vordering niet tonen van een legitimatiebewijs/rijbewijs', 'Nieuwe Boete', 1611066212, 1),
(5, 'f99bdcdd482aea00dec18d03f476d346144da7eb', 'Tom Komkommer Boete uitgeschreven aan Juan Jose Garcia Fuentes voor Het nafluiten of naroepen van vrouwen (straatintimidatie)', 'Nieuwe Boete', 1611154986, 1),
(6, 'd26fcb35327681ded3e1a1573a68cb4a31902ed4', 'Pim De Beer Boete uitgeschreven aan Piet Grasman  voor Alcohol op straat nuttigen (+ overlast)', 'Nieuwe Boete', 1611242600, 1),
(7, 'd26fcb35327681ded3e1a1573a68cb4a31902ed4', 'Pim De Beer Boete uitgeschreven aan Piet Grasman  voor Met een voertuig onnodig geluid producen (Gasgeven)', 'Nieuwe Boete', 1611242604, 1),
(8, 'd26fcb35327681ded3e1a1573a68cb4a31902ed4', 'Pim De Beer Boete uitgeschreven aan Piet Grasman  voor Alcohol op straat nuttigen (+ overlast)', 'Nieuwe Boete', 1611242606, 1),
(9, 'd26fcb35327681ded3e1a1573a68cb4a31902ed4', 'Pim De Beer Boete uitgeschreven aan Piet Grasman  voor Alcohol op straat nuttigen (+ overlast)', 'Nieuwe Boete', 1611242838, 1),
(10, 'd26fcb35327681ded3e1a1573a68cb4a31902ed4', 'Pim De Beer Boete uitgeschreven aan Piet Grasman  voor Alcohol op straat nuttigen (+ overlast)', 'Nieuwe Boete', 1611242840, 1),
(11, 'd26fcb35327681ded3e1a1573a68cb4a31902ed4', 'Pim De Beer Boete uitgeschreven aan Pim De Beer voor Alcohol op straat nuttigen (+ overlast)', 'Nieuwe Boete', 1611243191, 1),
(12, 'd26fcb35327681ded3e1a1573a68cb4a31902ed4', 'Pim De Beer Boete uitgeschreven aan Pim De Beer voor Met een voertuig onnodig geluid producen (Gasgeven)', 'Nieuwe Boete', 1611243194, 1),
(13, 'd26fcb35327681ded3e1a1573a68cb4a31902ed4', 'Pim De Beer Boete uitgeschreven aan Pim De Beer voor Alcohol op straat nuttigen (+ overlast)', 'Nieuwe Boete', 1611243197, 1),
(14, 'd26fcb35327681ded3e1a1573a68cb4a31902ed4', 'Pim De Beer Boete uitgeschreven aan Pim De Beer voor Alcohol op straat nuttigen (+ overlast)', 'Nieuwe Boete', 1611243332, 1),
(15, 'd26fcb35327681ded3e1a1573a68cb4a31902ed4', 'Pim De Beer Boete uitgeschreven aan Pim De Beer voor Het nafluiten of naroepen van vrouwen (straatintimidatie)', 'Nieuwe Boete', 1611243337, 1),
(16, 'd26fcb35327681ded3e1a1573a68cb4a31902ed4', 'Pim De Beer Boete uitgeschreven aan Pim De Beer voor Alcohol op straat nuttigen (+ overlast)', 'Nieuwe Boete', 1611244203, 1),
(17, 'd26fcb35327681ded3e1a1573a68cb4a31902ed4', 'Pim De Beer Boete uitgeschreven aan Pim De Beer voor Alcohol op straat nuttigen (+ overlast)', 'Nieuwe Boete', 1611244314, 1),
(18, 'd26fcb35327681ded3e1a1573a68cb4a31902ed4', 'Pim De Beer Boete uitgeschreven aan Pim De Beer voor Alcohol op straat nuttigen (+ overlast)', 'Nieuwe Boete', 1611244346, 1),
(19, 'f99bdcdd482aea00dec18d03f476d346144da7eb', 'Tom Komkommer Boete uitgeschreven aan Juan Jose Garcia Fuentes voor Alcohol op straat nuttigen (+ overlast)', 'Nieuwe Boete', 1611245198, 1),
(20, 'f99bdcdd482aea00dec18d03f476d346144da7eb', 'Tom Komkommer Boete uitgeschreven aan Juan Jose Garcia Fuentes voor Onnodig gebruik maken van de claxon', 'Nieuwe Boete', 1611245201, 1),
(21, 'd26fcb35327681ded3e1a1573a68cb4a31902ed4', 'Pim De Beer Boete uitgeschreven aan Pim De Beer voor Alcohol op straat nuttigen (+ overlast)', 'Nieuwe Boete', 1611245252, 1),
(22, 'd26fcb35327681ded3e1a1573a68cb4a31902ed4', 'Pim De Beer Boete uitgeschreven aan Pim De Beer voor Alcohol op straat nuttigen (+ overlast)', 'Nieuwe Boete', 1611251569, 1),
(23, 'd26fcb35327681ded3e1a1573a68cb4a31902ed4', 'Pim De Beer Boete uitgeschreven aan Pim De Beer voor Alcohol op straat nuttigen (+ overlast)', 'Nieuwe Boete', 1611259556, 1),
(24, 'f99bdcdd482aea00dec18d03f476d346144da7eb', 'Tom Komkommer Boete uitgeschreven aan Andre  Hazes voor Niet opruimen van je afval', 'Nieuwe Boete', 1611266688, 1),
(25, 'd26fcb35327681ded3e1a1573a68cb4a31902ed4', 'Pim De Beer Boete uitgeschreven aan Andre  Hazes voor Alcohol op straat nuttigen (+ overlast)', 'Nieuwe Boete', 1611310288, 1),
(26, '72fa5a0c753f94d2e71d8ac6af5b23c799d5d638', 'Robin Geldwolf Boete uitgeschreven aan Robin Fox voor Mishandelen van een burger', 'Nieuwe Boete', 1611344971, 1),
(27, '72fa5a0c753f94d2e71d8ac6af5b23c799d5d638', 'Robin Geldwolf Boete uitgeschreven aan Robin Fox voor Niet opruimen van je afval', 'Nieuwe Boete', 1611344979, 1),
(28, '', ' Boete uitgeschreven aan Andre  Hazes voor Moord op een agent', 'Nieuwe Boete', 1611546061, 1),
(29, '', ' Boete uitgeschreven aan Robin Fox voor Het besturen van een gestolen voertuig (aanhouden)', 'Nieuwe Boete', 1611583380, 1),
(30, '', ' Boete uitgeschreven aan Kees DeHunter voor Met een voertuig onnodig geluid producen (Gasgeven)', 'Nieuwe Boete', 1611661853, 1),
(31, '', ' Boete uitgeschreven aan Kees DeHunter voor Alcohol op straat nuttigen (+ overlast)', 'Nieuwe Boete', 1611661859, 1);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `pois`
--

CREATE TABLE `pois` (
  `id` bigint(20) NOT NULL,
  `civ_id` varchar(255) NOT NULL,
  `image` mediumtext NOT NULL,
  `reason` mediumtext NOT NULL,
  `notes` mediumtext NOT NULL,
  `dateline` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `pois`
--

INSERT INTO `pois` (`id`, `civ_id`, `image`, `reason`, `notes`, `dateline`) VALUES
(145, 'b9f6f32ed2e3067f2945df5c0a858a935078756c', '', 'Vluchten voor de politie', 'Reed in groene porsche weg', 1608300451),
(146, '2ad59a21e18af6fc073bc435ab232164cab0a309', '', 'Vluchten voor de politie', 'A6 (mat zwart) kenteken: SFA 331', 1608301647),
(148, '3ab14b3583a41077a5b7bb9cb180d2340a7b0bb8', '', 'vluchten politie/achterlijk r gedrag', 'persoon negeert ale soorten vorderingen van de politie ', 1608382001),
(149, '1772c75a1b350140f4c950f131b3c6c08a9edc6b', '', 'Vluchten voor politie + verkeersovertredingen', 'Combatlog', 1608498371),
(152, 'ff7534df1fe781809a6cf0f5a3f586bb41978a52', '', 'Vluchten voor de politie', 'Je mag hem 20 weken celstraf geven/ rijdt in een rode ferari', 1608569923),
(154, 'b9f6f32ed2e3067f2945df5c0a858a935078756c', '', 'Schieten naast agent + vluchten politie', 'Zat in een zwarte G-klasse', 1608645167),
(156, '509e5882442a023bd69ef7c83970a3ccefb6835a', '', 'mogelijk slagwapen gevaarlijk', 'rijdt in een witte mercedes', 1608729959),
(157, '960dfef0120d1adb68e9c3b46443d6be5ca8b8cb', '', 'Krijgt nog 50 weken voor wapenbezit (mes) en vluchten voor politie', 'Meneer heeft snel /chardel gedaan om een andere naam/uiterlijk te krijgen zodat hij kon ontkomen. Hij mag (ongeacht hoe hij op dit moment heet) alsnog voor 50 weken zitten.', 1608753147),
(159, 'f52fcdbeb66345c9c4a39aeea757fcf5b510980c', '', 'Meneer staat met zijn Nissan Titan op een drugslocatie en draagt een wapenholster aan zijn riem met daarin een op een vuurwapen gelijkend voorwerp', 'Mogelijk vuurwapengevaarlijk', 1608892292),
(160, 'a42767a3a0edff57312adf6f1b45d68b92277059', '', 'betrokken bij schoten en inbraak op HB', 'Wees alert op communicatie afnemen het is mogelijk een groep mensen ', 1608898258),
(161, '1295fdfefd9289bdd2d0b004ecf154befaafedb6', '', 'Geeft drugs aan de ambu', '122opium', 1608908747),
(163, 'b9f6f32ed2e3067f2945df5c0a858a935078756c', '', 'Word verdacht van het verkopen van wiet zakken', '-', 1608994466),
(164, '78d8d1d1b283f7a9574fc49cdc4dfe215398ed8c', '', 'Medeplichtig aan gijzelen van collega en overval op bar.', '-', 1608994719),
(165, '235127453aacd075f7f0435b524e36d67c8b2c77', '', 'Medeplichtig aan gijzelen van collega en overval op bar.', '-', 1608994732),
(166, 'ad8c51f579efe2460da3414e5ed9e5e5ea84be24', '', 'Medeplichtig aan gijzelen van collega en overval op bar.', '-', 1608994752),
(167, '1aa9028baa2b87bcc3174b56dfd156982dc02d44', '', '189 opium in wagen aangetroffen', 'RS6 rood', 1609089634),
(168, '296f66e26b2904b4b339198f8bcf9aec751bc056', '', 'Overval op de tequila bar', 'Gewapende overval met 2 gijzelaars.', 1609110995),
(169, '79aa5a7a47e5f75c0202f81921fe8d72141a8f10', '', 'Overval op de tequila bar', 'Gewapende overval met 2 gijzelaars.', 1609111010),
(170, 'ff9a7e870bd2bcebef05fc09ef7eee8958560cae', '', 'Betrapt op het gijzelen van een persoon met een aantal andere.', '-', 1609193472),
(171, '9e6a4228d141ad85da08fa6fde1d1293bcd9c2e1', '', 'Fabriceren van illegaal waar', 'stond op opium pluk locatie', 1609200336),
(172, '5b0bc9550c305b53d0875ec0039c840b8fcecb35', '', 'Auto  bevat grote hoeveelheid drugs', '', 1609249882),
(173, '235127453aacd075f7f0435b524e36d67c8b2c77', '', 'Gemaskerde man, mogelijk betrokken bij vuurgevecht. Mogelijk vuurwapen gevaarlijk. Medeplichtig bij overval.', 'Zwarte Lamborghini OZW 304', 1609257852),
(174, '66b18c91f3131503fa592866636a4487edad504b', '', 'Ontplofte auto aangetroffen op wiet verkoop locatie', 'Niks in auto aangetroffen ', 1609281243),
(175, 'a3fe13b82c75c892f5e31706a6dc895cb63e9c75', '', 'Voertuig aangetroffen bij een overval', 'Het gaat om zijn enige voertuig.', 1609332794),
(176, '2814e1b2911981a5b679fc6fb6ca3a3684e02222', '', 'Auto bevat grote hoeveelheid drugs', 'kenteken REV 925', 1609337990),
(177, '960dfef0120d1adb68e9c3b46443d6be5ca8b8cb', '', 'Meneer zou met zijn gele Lamborghini een persoon (Mike Oxmaul) hebben aangereden en vervolgens zijn gevlucht.', 'Meneer Spetter heeft aangifte gedaan wegens zware mishandeling cq. poging tot doodslag.', 1609365349),
(178, '4d8985e09ecc3d7f8b4a30e160083153f4fd49e4', '', 'Meneer is betrokken bij een carthief', 'Rijdt ondanks waarschuwingsschoten gewoon door', 1609526538),
(180, '828d19703870ebfefbed6939b5d36527f21f175d', '', 'Medeplichtig aan ov', '', 1609622684),
(181, 'b9f6f32ed2e3067f2945df5c0a858a935078756c', '', 'Medeplichtig aan overval', '', 1609623657),
(182, 'e19631f09bc522ffeb2a6a5e187298c68b461d05', '', 'Zijn voertuig (SVJ) wordt aangetroffen op coke pluk met 364 coke erin', '', 1609792118),
(183, '0cb72f25a1703dc974256a780d8470d7fbe13988', '', 'Is betrokken geweest bij een incident met een knuppel', 'Mag gefouilleerd worden ivm mogelijk slagwapenbezit (knuppel)', 1609792646),
(187, '7b01b6ae89d5ed03ce91e6005c3475723d10f5d6', '', 'Lag dood langs de snelweg met een knuppel.. ', 'knuppel is niet ingenomen want we mogen niet doden af foullieren. Toen is hij na 1 minuut uitgelogd...', 1610048656),
(188, '543a32bd0aa7e3ec12bcd4824a1906332cc20a6a', '', 'Rijbewijs B van deze meneer (Hamzaa Looh) mag ingevorderd worden. Snelheid, achtelijk rijgedrag. Observatie vanuit de heli', 'Boetes heeft meneer al gekregen.', 1610105907),
(189, 'd0f0cfad363f5a2a56ae9dbd9dfa7cf2579f963c', '', 'Vluchten voor de politie, roekeloos rijgedrag', 'Meneer na een achtervolging ontkomen. Boetes via MEOS geschreven en rijbewijs ingevorderd.', 1610106324),
(190, '941fc25aa1d52e32ffa96241d3451f0d0edd058a', '', 'Persoon probeert iemand te ontvoeren met een mes / klapmes', 'Aangifte gedaan door collega Jesse', 1610117681),
(191, '828d19703870ebfefbed6939b5d36527f21f175d', '', 'Word verdacht van het verkopen van Wiet', '', 1610141303),
(192, 'b9f6f32ed2e3067f2945df5c0a858a935078756c', '', 'Word verdacht van het verkopen van Wiet', '', 1610141350),
(195, 'e19631f09bc522ffeb2a6a5e187298c68b461d05', '', 'Mogelijk betrokken bij een gewapende overval op de LifeInvader', '', 1610193736),
(196, '2f40c8206c52f0cd1a67e377666a340db9f7a1b5', '', 'Poging tot doodslag Agente, vluchten voor politie onder schot, Spookrijden met meer dan 50 km te hard', 'Mag nog even gaan zitten voor heel wat weken', 1610224630),
(197, '9192159d0659e24363941e4a5989f6de767a24d0', '', 'Carthief+ niet meewerken met arrestatie', '60 weken voorwaardelijke straf', 1610301249),
(199, '46631935188e9bbdae37832caa3bd61f726a88a3', '', 'Meneer rijdt meer dan 100 km/h te hard door de stad, heeft geen rijbewijs. Bij controle vlucht meneer in zijn groene Mercedes-Benz AMG GTR.', '', 1610402007),
(200, '2db1c2ab7e16613ea1a3daa05d27997cb9a8d860', '', 'Persoon rijdt in een rode Audi A6 met kenteken JVZ 499 en vraagt op Blokkenpark mensen of hij een wapen (mes) kan kopen', '', 1610469163),
(201, '813e3d3bcc767afc14086f728359b92841a7365f', '', 'Meneer maakt op 13/01 rond 12:25 uur een 112-melding met: \'Kom me wiet maar halen\'', 'Persoon mogelijk in bezit van drugs (wiet)', 1610537761),
(202, '4d8985e09ecc3d7f8b4a30e160083153f4fd49e4', '', 'Betrokken bij gijzeling', '', 1610568670),
(204, '13fca1db700f16b40d9ce296831de0469a4beecd', '', 'heb me even laten gaan ', '', 1611663786),
(205, '9ca81bb8024bc476ebce033955d1501e522800c4', '', 'Test', 'test', 1611677509);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `reports`
--

CREATE TABLE `reports` (
  `id` bigint(20) NOT NULL,
  `user` bigint(20) NOT NULL,
  `incident` mediumtext NOT NULL,
  `cad` varchar(255) NOT NULL,
  `located` mediumtext NOT NULL,
  `otherUnits` mediumtext NOT NULL,
  `arrested` mediumtext NOT NULL,
  `person` mediumtext NOT NULL,
  `arrestedFor` mediumtext NOT NULL,
  `foundItems` mediumtext NOT NULL,
  `whatHappened` longtext NOT NULL,
  `dateline` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `reports`
--

INSERT INTO `reports` (`id`, `user`, `incident`, `cad`, `located`, `otherUnits`, `arrested`, `person`, `arrestedFor`, `foundItems`, `whatHappened`, `dateline`) VALUES
(8, 234, 'Het stelen van een voertuig en vluchten van de politie', '87312101124', 'Ten noorden van het politiebureau, vlakbij de Toetanchamon supermarkt', '', 'Ja', '6e8f42511bda8fe195b8e40f0c1486ce0d4b3552', 'Het stelen van een voertuig en vluchten van de politie', 'Niks', '<p>Persoon na uitgebreid verhoor vrijgelaten wegens gebrek aan bewijs. Persoon heeft sowieso gereden maar wij konden dit niet 100% bewijzen omdat niemand hem uiteindelijk heeft zien uitstappen.</p>', 1607094101),
(9, 234, 'Scout bij overval waarbij 3 agenten om het leven kwamen', '34413754758', 'Overval Yellow Yack', '', 'Ja', '7559dc591b5ab69a232b9fda6277223c6125e899', 'Scout bij overval waarbij 3 agenten om het leven kwamen', 'Geen', '<p>Meneer is aangehouden als medeplichtige bij een gewapende overval waarbij drie agenten om het leven zijn gekomen. Hij heeft zijn boetes gehad en een gevangenisstraf voor de duur van 30 weken.</p>', 1607095192),
(10, 234, 'Hij kwam op het bureau vrijwillig 1200 gram wiet inleveren.', '2581508413', 'Politiebureau Maasland', '', 'Nee', '813e3d3bcc767afc14086f728359b92841a7365f', 'Hij kwam op het bureau vrijwillig 1200 gram wiet inleveren.', '1200 gram wiet en ongeveer 40 wiet zaadjes', '<p>Meneer kwam vrijwillig een grote hoeveelheid drugs inleveren, volgens eigen zeggen was het niet van hem zelf. Meneer is werkzaam bij de ANWB en heeft netjes alles ingeleverd.</p>', 1607095275),
(11, 234, 'Grootschalig drugsbezit', '37264224572', 'Onbekend', 'Joren (HH-05)', 'Ja', '0391cdb80f75d3114c8046da4d6750b2a8625d45', 'Grootschalig drugsbezit', '214 wiet, 150 zakjes wiet, 45 zaadjes, 31 kunstmest, 148 bronwater', '<p>Aangehouden door handhaver Joren (HH-05) voor grootschalig drugs bezit. Tevens moet de illegale claxon van zijn donker-rode Audi SQ5 nog verwijderd worden. Audi met kenteken SWD 566.</p>', 1607095633),
(12, 234, 'Grootschalig drugsbezit', '76680296323', 'Onbekend.', 'Aangehouden door handhaver HH-05.', 'Ja', '4b81f3f9d18c328e220697b4766c5e069ce8fe08', 'Grootschalig drugsbezit', '180 zakjes wiet, 20 wietzaadjes, 60 kunstmest, 60 bronwater', '<p>Meneer is aangehouden voor grootschalig drugsbezit. Zijn voertuig stond op de stoep geparkeerd en stond niet op slot. Hij is aangehouden door de HH-05 en heeft naast de boetes een gevangenisstraf gekregen voor de duur van 30 weken.</p>', 1607096143),
(13, 234, 'Brandstichting en poging tot moord op een burger', '21428197470', '', 'Djenna en Joren', 'Ja', '739c5381e3be7f23eded2ef1fabda7c592d723fa', 'Brandstichting en poging tot moord op een burger', 'Niks', '<p>Persoon stond nog gesignaleerd en is later aangehouden door Joren en Djenna voor brandstichting en poging tot moord op een burger.</p>', 1607097386),
(14, 234, 'Roekeloos rijgedrag, (poging tot) vluchten voor de politie', '63352474461', 'Cardealer Maasland', 'Benno Lakerveld + Joren', 'Ja', '3ef9c7b359b0de52f44ec7e11449c953bdf0c2c7', 'Roekeloos rijgedrag, (poging tot) vluchten voor de politie', 'Niks', '<p>Wij zien meneer rijden met hoge snelheid door het rode licht, waarop we besluiten hem langs de kans te zetten. Vervolgens gaat hij ervandoor en probeert hij zich te verschuilen in het gebouw van de cardealer. Toen wij meneer probeerden aan te spreken probeerde hij op de motorfiets van een vriend te stappen waarop hij door mijn collega Joren is getaserd. In overleg met de advocaat heeft meneer enkel boetes gekregen, geen gevangenisstraf.</p>', 1607101485),
(15, 233, '(aanhouding)', '26424852057', 'aanhouding', 'gilles ', 'Nee', '9e9effc79a27dc9dcf2af9ac317d1a05bd02a7f3', '(aanhouding)', 'x', '<p>Idg 708 nissan skyline. door rood gereden, achterlijk rijgedrag, en te snel in de stad 20-30 tehard</p>', 1607108322),
(16, 233, 'rijgedrag, groots danig drugsbezit ', '31571904250', 'viaduct bij stripclub', 'gilles, Xander, maxim, cleamen.', 'Ja', 'c6179d5bfdd2c4d36a0ea031ffce2ca072793f1b', 'rijgedrag, groots danig drugsbezit ', '250 coke', '<p>is in achtervolging tegen iets aangereden en daarna meegenomen naar de ambulance omdat het niet goed gaat met meneer. staat van meneer kritisc. voertuig weggesleept. (helaas overleden)</p>', 1607109007),
(17, 234, 'Mogelijke betrokkenheid bij een bank overval', '92490836366', 'Brakkliggend terrein ten noorden van de oude ANWB', 'Cleamen, Maxim, Benno, Djenna, Gunther, Joren, Gillas, Nelis', 'Nee', '0bd1b5da2e327782161a672deed222a3ccd6b770', 'Mogelijke betrokkenheid bij een bank overval', 'Niks', '<p>Vrijgelaten wegens gebrek aan bewijs, wel een zeer grote verdenking tot betrokkenheid van een bankoverval op de bank op het Blokkenpark. Meneer reed in een grote vrachtwagencombinatie (zonder geldig rijbewijs) waarmee hij de doorgang voor achtervolgende politie probeerde te blokkeren.</p>', 1607112800),
(18, 234, 'Drugshandel, wapenhandel, witwassen, eigenaar van \'\'Camorra\'\'', '89552476515', 'Camorra hide-out', 'Cleamen, Camezonda, Nico Hamilton, Xander, Benno, Djenna, Gunther, Joren', 'Ja', '39f5e6582a45277d1f44ffa96ce1745af73c669a', 'Drugshandel, wapenhandel, witwassen, eigenaar van \'\'Camorra\'\'', 'Meerdere vuurwapens, drugs, zeer veel geld', '<p>Meneer Antonio Lovine is op vrijdagavond 4 december aangehouden bij een inval op de schuilplaats van de bende die zichzelf \'\'Camorra\'\' noemt. Tijdens de inval door het arrestatieteam werd deze meneer in het pand aangetroffen. Er zijn een grote hoeveelheid vuurwapens, zeer veel drugs en veel geld aangetroffen. Het pand is door de gemeente gesloten voor onbepaalde tijd.</p>', 1607117174),
(19, 234, 'Wapenbezit, grootschalig drugsbezit en witwassen', '71123819510', 'Schuilplaats van de \'\'Camorra\'\' bende', 'Cleamen, Camezonda, Nico Hamilton, Xander, Benno, Djenna, Gunther, Joren', 'Ja', '9569707b96d6415431bbacb40f8fad07c01dc542', 'Wapenbezit, grootschalig drugsbezit en witwassen', 'Meerdere vuurwapens, drugs, zeer veel geld', '<p>Meneer Stefano Peer is op vrijdagavond 4 december aangehouden bij een inval op de schuilplaats van de bende die zichzelf \'\'Camorra\'\' noemt. Tijdens de inval door het arrestatieteam werd deze meneer in het pand aangetroffen. Er zijn een grote hoeveelheid vuurwapens, zeer veel drugs en veel geld aangetroffen. Het pand is door de gemeente gesloten voor onbepaalde tijd.</p>', 1607117293),
(20, 238, 'dragen van een slag wapen ', '20854772080', 'Blokkenpark ', 'HH-05, I-182', 'Ja', '5915cd48de62bf84857b53287778a49dcd1d097c', 'dragen van een slag wapen ', 'switch blade', '<p>HH-05 laat verdachten stoppen en heeft een mes van tijdens et afstapen van de motor. Daar bij zijn ook 4 agenten ter verstrking gekomen HI-201, I-182, HH-01, HH-04</p>\r\n<p>persoon werkt niet mee&nbsp;</p>\r\n<p>20 weken gevangenis +boeten&nbsp;&nbsp;</p>', 1607181624),
(22, 238, 'na fluiten van vrouwlijke collega', '34868829652', 'BLOCKENPARK', 'HH-01', 'Ja', '42ad949641dd0401ce0f829d28551d1e04c643d2', 'na fluiten van vrouwlijke collega', '', '', 1607188130),
(23, 238, 'cop baiting (meerder malen vluchten na het beledigen van een agent)', '60028440872', 'straat naas anwb', 'I-182,HH-06,HH-05', 'Ja', '7e4eaa864f2932ba2176f3eb19671b1440f44e2b', 'cop baiting (meerder malen vluchten na het beledigen van een agent)', '', '<p>plast in broek naast de wc (psychologische problemen?)</p>', 1607189045),
(24, 238, 'gewapende overval op een bar ', '14097155705', 'dubbele garage ', 'A-42, HI-201', 'Ja', '235127453aacd075f7f0435b524e36d67c8b2c77', 'gewapende overval op een bar ', '', '<p>zijn wagen mclaren LLL 782 was gezien tijdens een ov en is kort daarna met de eigenaar er in gezien en gearresteerd door de collega\'s</p>\r\n<p>bij een vorige arrestatie heeft hij het zelfde excuus gebruikt waardoor dit nietmeer als waar wordt aangenomen&nbsp;&nbsp;</p>', 1607200637),
(25, 238, 'vluchten van politie ', '22215039921', 'blokkenpark taco shop', 'HH-05', 'Ja', '09955907399e7d7fbfb2b1a617a10b3f6efb9ba0', 'vluchten van politie ', '', '<p>&nbsp;</p>\r\n<p>&nbsp;</p>', 1607200806),
(26, 238, 'groote hoeveelheid drugs ', '26659547094', 'dubbele garage ', 'HC-241,HI-201,I-182,A-42,HH-05', 'Ja', '7d86bad05314361c6caa604d6a775a10d41e2011', 'groote hoeveelheid drugs ', 'drug ', '<p>een burger komt naar ons voor een drugs trade te melden.</p>\r\n<p>wij&nbsp; gaan over tot interventie en treffen weed+88780 zwartgeld aangetroffen&nbsp;</p>', 1607204750),
(27, 238, 'stelen van een auto', '43619560552', 'blokkenpark', 'HC-241,A-42', 'Ja', '0bd1b5da2e327782161a672deed222a3ccd6b770', 'stelen van een auto', '', '<p>stele op green zone&nbsp;</p>', 1607206887),
(29, 234, 'Vluchten van de politie + roekeloos rijgedrag', '46090628427', 'Steegje vlakbij de stripclub', 'Benno, Camezonda, Joren, Djenna', 'Ja', '7e4eaa864f2932ba2176f3eb19671b1440f44e2b', 'Vluchten van de politie + roekeloos rijgedrag', '', '<p>Meneer reed op zijn motorfiets (zonder kentekenplaat) al twee keer eerder met hoge snelheid langs. De derde keer konden wij hem na een korte maar heftige achtervolging aanhouden. Nadat hij werd klemgereden heeft hij zichzelf over gegeven. Twee bekeuringen + 20 weken celstraf opgelegd.</p>', 1607208246),
(30, 238, 'achterlijk rijgedrag ', '39111070889', 'snelweg boven pier', 'HH-05', 'Ja', 'ffe35a2f8e762893342d85acb8df819dd650b137', 'achterlijk rijgedrag ', '', '', 1607208376),
(31, 238, 'vluchten voor politie ', '23879514356', 'snelweg boven pier', 'HH-01', 'Ja', 'f6c7616bcd27698ae1cfedfbbae8c4bcc17dc6a3', 'vluchten voor politie ', '', '', 1607208437),
(33, 234, 'Vluchten voor de politie, roekeloos rijgedrag', '41255834266', '', 'Sebastiaan (geassisteerd door Benno)', 'Ja', '09955907399e7d7fbfb2b1a617a10b3f6efb9ba0', 'Vluchten voor de politie, roekeloos rijgedrag', '', '<p>Meneer is voor de tweede dag op rij aangehouden voor het vluchten van de politie. Krijgt een celstraf van 20 weken maar is het daar niet mee eens, blijkt ook te rijden zonder geldig rijbewijs.</p>\r\n<p>&nbsp;</p>', 1607260255),
(34, 234, 'Snelheden van boven de 200 km/h langs Blokkenpark', '36896095879', 'Blokkenpark', 'Benno, Cleamen, Maxim', 'Nee', 'ea1908f637d250cb99b14f3775b702860ae55f35', 'Snelheden van boven de 200 km/h langs Blokkenpark', '', '<p>Persoon niet gearresteerd, rijbewijs B is ingetrokken. Persoon werkt goed mee.</p>', 1607271150),
(35, 236, '10 wiet op zak + mishandelen burger', '61843614993', 'Stadhuis', '', 'Ja', 'efdc8c7f0e538a8486095e9d208b17b063e5aef8', '10 wiet op zak + mishandelen burger', '10 wiet', '', 1607271334),
(36, 235, 'Rijden zonder rijbewijs.', '18384670010', 'blokkenpark appartement', 'CO 220 Benno', 'Nee', '235127453aacd075f7f0435b524e36d67c8b2c77', 'Rijden zonder rijbewijs.', '', '', 1607271363),
(39, 236, 'Drugs bezit', '47669381407', 'Stadhuis', '', 'Ja', '9c18b6e2baff50fdb1a96018e7f796bcc0e03351', 'Drugs bezit', '100 wiet', '', 1607277043),
(40, 238, 'basebalbat ', '77062046201', 'bouwplaats stad ', 'HH-06', 'Ja', '7b01b6ae89d5ed03ce91e6005c3475723d10f5d6', 'basebalbat ', 'basebalbat', '<p>verklaring meneer doet aan basebal en wij hebben hem door gestuurd naar het om als hij deze terug wilt&nbsp;</p>', 1607278311),
(41, 238, 'drugbezit ', '87564195384', 'blokkenpark', 'A-41,HH-05', 'Ja', '0391cdb80f75d3114c8046da4d6750b2a8625d45', 'drugbezit ', '69 coke', '<p>meneer is gecontoleerd omdat hij al met drug feiten bekend is. Aanhouding is vlot verlopen 20 weken + boetens</p>\r\n<p>&nbsp;</p>', 1607354762),
(42, 238, 'mishandeling van een burger + vluchten voor politie ', '79409767812', 'snelweg casino', 'A-41,S-20', 'Ja', '900f6ee0a1e89d749612dd88ea8cec85b94aaa4f', 'mishandeling van een burger + vluchten voor politie ', '', '<p>persoon is voor een 2x aangehouden voor mishandeling van een burger dit keer heeft hij 35weken gekregen</p>', 1607358691),
(43, 238, 'plukken van illegale goederen ', '36665919098', 'verdachte locatie (coke pluk)', 'A-41,DE-HA-110,DE-HI-201,DE-I-182,H-DE-CO-220,HH-03,HH-07,S-20', 'Ja', '941fc25aa1d52e32ffa96241d3451f0d0edd058a', 'plukken van illegale goederen ', '141 coke zak + 150 kofferbak', '<p>Tijdens een georganiseerde inval op een verdacht locatie.</p>\r\n<p>hebben wij meneer en nog 2 andere personen aangetroffen. na controle hebben wij een zeer grote hoeveelheid drugs (coke) gevonden op meneer en in zijn wagen.</p>\r\n<p>- Wagen&nbsp;</p>\r\n<p>&nbsp; &nbsp;- Goude Mercedes&nbsp;</p>\r\n<p>&nbsp; &nbsp;- NJP 186&nbsp;</p>', 1607372056),
(44, 238, 'plukken van illegale goederen ', '65939664722', 'verdachte locatie (coke pluk)', 'A-41,DE-HA-110,DE-HI-201,DE-I-182,H-DE-CO-220,HH-03,HH-07,S-20', 'Ja', '788137788ca78cbe3e840ec980b45f659a33a70b', 'plukken van illegale goederen ', '150 coke zak + 1287 coke koffer', '<p>Tijdens een georganiseerde inval Is meneer samen met nog 2 andere personen aangetroffen op een verdachte locatie.</p>\r\n<p>na controle hebben wij een zeer grote hoeveelheid drugs (coke) gevonden op meneer en in zijn wagen.</p>\r\n<p>- Wagen&nbsp;</p>\r\n<p>&nbsp; &nbsp;- Grijze Audi</p>\r\n<p>&nbsp; &nbsp;- TJT 568&nbsp;</p>', 1607372059),
(45, 238, 'plukken van illegale goederen ', '66257415013', 'verdachte locatie (coke pluk)', 'A-41,DE-HA-110,DE-HI-201,DE-I-182,H-DE-CO-220,HH-03,HH-07,S-20', 'Ja', 'ad29c7e3feae3c421aab11abda73c2d57dc479eb', 'plukken van illegale goederen ', '150 coke zak + 150 coke koffer', '<p>Tijdens een georganiseerde inval op een verdacht locatie.</p>\r\n<p>hebben wij meneer en nog 2 andere personen aangetroffen. na controle hebben wij een zeer grote hoeveelheid gevonden op meneer en in zijn wagen.</p>\r\n<p>- Wagen&nbsp;</p>\r\n<p>&nbsp; &nbsp;- Mat Zwarte Audi</p>\r\n<p>&nbsp; &nbsp;- PND 840&nbsp;</p>', 1607372061),
(46, 238, 'poging tot doodslag op een agent ', '83067376206', 'FIB gebouw ', 'A-41,AS-15,HH-07', 'Nee', '0697ee0b55eaed41f3f41d1f81b7bd16a0921693', 'poging tot doodslag op een agent ', '', '<p>Tijdens een achtervolging meneer heeft 1 van onze mensen meerdere malen aan het rammen geweest met snelheden +-200km/h.<br /><br />Hier door hebben wij zijn vriend met een zwarte sq5 laten gaan en meneer gearresteerd.<br />Onze collega\'s zijn er met de schrik van afkomen.</p>\r\n<p>meneer heeft boetes gekregen via de meldkamer omdat meneer is uitgelogd in de cel. (het gemeente bestuur gaat hier verder met)</p>\r\n<p>cel straf krijgt meneer bij de volgende aanhouding hier wordt 60 weken voor gevraagd!</p>', 1607444085),
(47, 238, 'poging tot doodslag op een agent ', '39245485191', 'FIB gebouw ', 'A-41,AS-15,HH-07', 'Ja', 'b42bc303936bd2bad8a08221cdfad508ee785a2b', 'poging tot doodslag op een agent ', '', '<p style=\"box-sizing: border-box; margin-top: 0px; margin-bottom: 1rem;\">Tijdens een achtervolging meneer heeft 1 van onze mensen meerdere malen aan het rammen geweest met snelheden +-200km/h.<br style=\"box-sizing: border-box;\" /><br style=\"box-sizing: border-box;\" />Hier door hebben wij zijn vriend met een zwarte sq5 laten gaan en meneer gearresteerd.<br style=\"box-sizing: border-box;\" />Onze collega\'s zijn er met de schrik van afkomen.</p>\r\n<p style=\"box-sizing: border-box; margin-top: 0px; margin-bottom: 1rem;\">meneer heeft boetes gekregen via de meldkamer omdat meneer is uitgelogd in de cel. (het gemeente bestuur gaat hier verder met)</p>\r\n<p>&nbsp;</p>\r\n<p style=\"box-sizing: border-box; margin-top: 0px; margin-bottom: 1rem;\">cel straf krijgt meneer bij de volgende aanhouding hier wordt 60 weken voor gevraagd!</p>', 1607444320),
(48, 236, 'Negeren van 3 vorderingen', '67324560971', 'Politie Bureau', 'Nick', 'Ja', 'ea1908f637d250cb99b14f3775b702860ae55f35', 'Negeren van 3 vorderingen', '', '<p>Na 3 vorderingen het politie terrein weer betreden via de muur.</p>', 1607457124),
(49, 234, 'Vluchten voor de politie en illegaal wapenbezit', '83584778163', 'Vlakbij het strand / de pier', 'Djenna, Joren, Rico', 'Ja', 'b9f6f32ed2e3067f2945df5c0a858a935078756c', 'Vluchten voor de politie en illegaal wapenbezit', 'Een groot met (+/- 30 cm)', '<p>Handhaver Rico zag meneer als een idioot de bocht doorkomen vlakbij Blokkenpark. Bij het aanspreken besloot meneer er van door te gaan. Na een achtervolging, ondersteund door de politieheli (gevlogen door Benno) is meneer ter hoogte van het strand aangehouden. Tijdens het fouilleren bleek meneer een groot met (ongeveer 30 centimeter) op zak te hebben. Zijn verklaring voor het mes was dat hij daarmee boterhammen wilde gaan smeren. Mes is in beslag genomen. Meneer heeft 3 bekeuringen gekregen en een celstraf voor de duur van 30 weken.</p>', 1607511598),
(50, 234, 'Vluchten voor de politie en (waarschijnlijk) wapenbezit', '34154263526', 'Nabij Blokkenpark', 'Handhaver Rico', 'Nee', 'b9f6f32ed2e3067f2945df5c0a858a935078756c', 'Vluchten voor de politie en (waarschijnlijk) wapenbezit', '', '<p>Persoon rijdt met zeer hoge snelheid op een motorfiets langs Blokkenpark waarop wij hem staande houden. Werkt in eerste instantie goed mee, wel zie ik dat hij een wapenholster draagt, waarop ik hem vraag of hij wapens bij zich heeft. Hij zegt van niet, stapt op de motor en gaat er met hoge snelheid vandoor. Persoon niet meer aangetroffen.</p>', 1607523684),
(51, 234, 'Grote hoeveelheid drugs in zijn voertuig aangetroffen', '13671777963', 'Een woning aan de west-kust van de stad, vlakbij de kleine pier', 'Handhaver Rico', 'Nee', 'ad29c7e3feae3c421aab11abda73c2d57dc479eb', 'Grote hoeveelheid drugs in zijn voertuig aangetroffen', '760 wiet, 88 coke en zaadjes', '<p>Na een melding van de ambulance troffen wij de Audi van meneer Nugerdo aan onder water in een zwembad in de tuin van een luxe villa. Zijn auto stond niet op slot. In het voertuig trof mijn collega Rico vervolgens 760 wiet, 88 coke en 21 wietzaadjes aan. Meneer is niet aangetroffen.</p>', 1607526567),
(53, 238, 'weed plantage ', '62953971203', 'opservatorium ', '', 'Ja', '0cb72f25a1703dc974256a780d8470d7fbe13988', 'weed plantage ', 'zaadjes,kunstmest,bronwater, 710 weed', '<p>meneer had een plantage staan toen onze collega hem vond meer info bij nelis&nbsp;</p>', 1607536215),
(54, 234, 'Beheren van een wietplantage en in bezit van grote hoeveelheid drugs', '52744868852', 'In de achtertuin van een woning in het stadje Grapeseed (vlakbij auto garage)', 'Benno en Rico', 'Ja', '87cad0bc357f9d95418f5998ef7b3e9003f1d535', 'Beheren van een wietplantage en in bezit van grote hoeveelheid drugs', '430 wiet, 1400 kunstmest, 1400 bronwater en zaadjes', '<p><span style=\"color: #676a6c; font-family: \'open sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 13px; font-weight: bold; background-color: #ffffff;\">Wij reden als politie even random mee op een melding van de ambulance in het noorden van de stad (vlakbij Grape Seed airfield) toen wij meneer in de achtertuin aantroffen bij een wietplantage van 20 planten. Meneer bleek ook drugs in zijn auto te hebben liggen. Meneer is aangehouden en kreeg een straf voor de duur van 20 weken.</span></p>', 1607542961),
(55, 239, '', '38888922435', 'Dubbelle Garage', 'S-20 (Joren)', 'Nee', 'f8871d5a180f1abec1efd5decfb5a52d02e0eb8d', '', 'Honkbal kunppel', '<p>Er was een melding van mishandeling bij dubbele garage. Toen mijn collega en ik t.p. waren troffen wij een verminkt lichaam aan waar niks meer aan te redden viel (Paul Achterbuurt). Deze persoon had overigens ook een kap mes bij zich. De persoon in kwestie hielden wij staande omdat, hij in de buurt van het ongeval was. Wij hebben het I.D. bewijs gezien en het wapen wat hij bij had (de knuppel) direct ingenomen. Wij zijn voor onze veiligheid snel weg gegaan en heb later via het MEOS systeem de bekeuring uitgedeeld.</p>', 1607548230),
(56, 236, 'Vluchten voor de politie', '2236149708', 'Ergens in het noorden in de buurt van de gevangenis langs ziekenhuis snelweg', 'Henk', 'Ja', '2ad59a21e18af6fc073bc435ab232164cab0a309', 'Vluchten voor de politie', '', '<p>Na een achtervolging aangehouden. Zijn Witte Lambo Urus werd gezocht wegens drugs en dit is ook opgelost</p>', 1607592320),
(57, 236, 'Vluchten voor de politie', '71104785670', 'Dubbele garage', 'Henk Walker', 'Ja', '2ad59a21e18af6fc073bc435ab232164cab0a309', 'Vluchten voor de politie', '', '<p>We wouden hem staande houden voor te snel rijden. Uiteindelijk vluchtte hij en hebben we hem aan kunnen houden.</p>', 1607604361),
(58, 234, 'Meneer is in de boeien gezet op verdenking van scouten van een overval', '67788764712', 'Juwelier', '', 'Nee', '23a2045980896c7582cbf7c04a308eeb4601ed94', 'Meneer is in de boeien gezet op verdenking van scouten van een overval', '', '<p>Meneer kwam tijdens een overval op een juwelier meerdere keren te dichtbij waarop hij in de handboeien is gezet op verdenking van het scouten van een overval. Tijdens verhoor achteraf door commissaris Benno bleek dat hij er waarschijnlijk niks mee te maken had. Dit toch in de mutatie gezet voor in de toekomst.</p>', 1607718293),
(59, 233, 'Poging tot vluchten van politie ', '85973766525', 'grote weg richting juwelier', 'UIteindelijk wel ', 'Ja', 'b9f6f32ed2e3067f2945df5c0a858a935078756c', 'Poging tot vluchten van politie ', 'x', '<p>Persoon parkeerde auto midden op de weg en reed in een wagen die niet van hem was bedrijfsvoertuig/gestolen en probeerde daarna te vluchten had geen contact gegevens van de eigenaar van de wagen ging om een rosevelt oldtimer</p>', 1607727463),
(60, 233, 'brug naar juwelier', '30056216438', 'Viaduct naar juwelier ', 'Benno, joren djenna ', 'Ja', '3ab14b3583a41077a5b7bb9cb180d2340a7b0bb8', 'brug naar juwelier', 'x', '<p>betrokken bij wasker Inderdaad poging tot vluchten van politie</p>', 1607727688),
(61, 233, 'x', '73911467078', 'dubbele garage ', 'Djenna', 'Nee', '510f01cd0093ca8a1912e62fb65092c3caf5cea5', 'x', 'knuppel', '<p>Persoon heeft een melding gemaakt dat hij bedreigd word en heeft de persoon in kwestie van zijn motor getrapt en overgedragen aan agenten, die persoon zou een knuppel bij hebben maar de meneer karelio heeft hem afgepakt en er vandoor gereden</p>', 1607795097),
(62, 233, 'rijgedrag', '90200302881', 'Blokkenpark appartement', 'Djenna', 'Ja', 'b07dfad0ac18404eb9f559c87d238586746c2181', 'rijgedrag', 'x', '<p>Rode porsche JLG 425</p>', 1607796399),
(63, 236, 'Weigeren 3 vorderingen + verstoren openbare orde', '83453619783', 'Blokkenpark', 'Nelis', 'Ja', '451a37b492f16fc209ca078ea7bb31cfc0fdd5f9', 'Weigeren 3 vorderingen + verstoren openbare orde', '', '<p>Meneer ging met een blazer op politie wagen staan. Meerdere keren moeten vragen om eraf te gaan en 3 vorderingen gekregen waardoor het tot een achtervolging te voet eindigde en we hem hebben kunnen aanhouden.<br /><br />Indien hij aangehouden wordt deze week, krijgt hij een extra straf bovenop van 40 weken.<br /><br />Hij kreeg 40 weken voorwaardelijk na deze aanhouding.</p>', 1607804857),
(65, 236, 'Vluchten voor de politie', '64587380521', 'Vliegveld', 'Nick\r\nJoren', 'Ja', 'e4ad21001b75d68f572591dcd8ae6606a3bc79cc', 'Vluchten voor de politie', '', '<p>Meneer vluchtte voor de politie. Tijdens de achtervolging crashte hij zwaar in de buurt van het vliegveld. We hebben hem hier kunnen aanhouden en hij was medisch in orde.</p>', 1607812582),
(67, 234, 'Vluchten voor politie, grootschalig drugsbezit', '76573152084', 'Blokkenpark', 'Cleamen, Benno, Joren', 'Ja', '145c7a1fa310a2d79badcc4d94bcaa4a17d17638', 'Vluchten voor politie, grootschalig drugsbezit', '663 wiet, zaadjes, bronwater, kunstmest', '<p><span style=\"color: #676a6c; font-family: \'open sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 13px; font-weight: bold; background-color: #ffffff;\">Meneer heeft zich onttrokken aan zijn aanhouding en ging er vandoor in een luxe Mercedes-Benz. Pas toen zijn auto er mee op hield ter hoogte van Blokkenpark kon meneer worden aangehouden. Daarbij is hij ook getaserd. Tijdens zijn aanhouding schold hij agenten uit. Hij heeft bekeuringen gekregen voor belediging van een ambtenaar, negeren stopteken, grootschalig drugsbezit. Gevangenisstraf van 45 weken.</span></p>', 1607816203),
(68, 234, 'Poging tot zware mishandeling agent, vluchten voor de politie, roekeloos rijgedrag', '31649288178', 'Een zijstraat van de dubbele garage', 'Benno', 'Ja', '04067abfe7f8bd9fbdbd9cd16094aeb7ef8d7d62', 'Poging tot zware mishandeling agent, vluchten voor de politie, roekeloos rijgedrag', '', '<p>Tijdens een patrouille treffen wij meneer aan bij het gebouw van de ANWB terwijl hij met zijn voertuig meerdere donuts aan het maken is. Als ik hem wil aanspreken probeert hij mij met zijn auto aan te rijden, waarop ik net op tijd kan weg springen. Meneer gaat er vandoor en de achtervolging wordt ingezet, na 2 succevolle PIT\'s stapt hij uit de auto en gaat hij er rennend vandoor, waarna hij getaserd wordt. Meneer is verbaal zeer aanwezig en doet heel bijdehand, na onderhandelingen met zijn advocaat, de heer Thimo Hopmans, wil zelfs zijn advocaat hem niet verder helpen.&nbsp;<br /><br />Nadat hij mij nog twee &aacute; drie goeie rake klappen heeft gegeven in de politiecel kreeg meneer 3 boetes en een gevangenisstraf voor de duur van 70 weken.<br /><br /><br /></p>', 1607877651),
(69, 239, 'Verkopen illegaal waar', '34132339056', 'Vlakbij PB in Paleto Bay', 'Henk Walker & Piet Grasman', 'Ja', '87cad0bc357f9d95418f5998ef7b3e9003f1d535', 'Verkopen illegaal waar', '38k (zwart)geld en 8 Wiet', '', 1607886129),
(70, 235, 'Grootschalig drugs bezit', '76948822659', 'Boven de Kitsune supermarkt', '[HH-03] Henk Walker', 'Ja', 'e4ad21001b75d68f572591dcd8ae6606a3bc79cc', 'Grootschalig drugs bezit', '', '<p>Hij reed in een rs6 met een groen parsecelent.</p>', 1607886567),
(71, 229, '', '43697518886', '', '', 'Ja', '0', '', '', '', 1607888062),
(72, 229, '', '43697518886', '', '', 'Ja', '0', '', '', '', 1607888074),
(73, 229, '', '17436697466', '', '', 'Ja', '0', '', '', '', 1607888079),
(74, 236, 'Vluchten voor de politie', '46110826388', 'In de buurt van de bar Tequi-la-la', 'Nick\r\nJoren', 'Ja', 'cfd4f826a415fa97105b5d8231e31473beb809d4', 'Vluchten voor de politie', '54 opium', '<p>Na achtervolging klem gereden langs 3 kanten. was zeer respectloos. Indentiteit hebben we kunnen achterhalen via vingerafdruk.</p>', 1607980560),
(75, 235, 'Mishandelen van een politie agent en vluchten voor politie', '17895223180', 'Bij de Kitsune super', 'Joren', 'Ja', '2d090405502086b0e9e0cff7fc21dc5ed92411e9', 'Mishandelen van een politie agent en vluchten voor politie', '/', '', 1607982838),
(76, 240, 'Op verhoor wegens medeplichtig aan bankoverval.', '19607310287', 'Cardealer', 'HH-10 is hierbij betrokken.', 'Nee', 'c69e8f8a1e3528caf3ddfc825db895b611a01ca8', 'Op verhoor wegens medeplichtig aan bankoverval.', 'Heel veel koffie', '<p>Meneer is op verhoor gekomen bij de Politie, wegens het medeplichtig zijn aan een overval.<br />Meneer is aangehouden met een grijs/zilvere Skyline GT-R.<br /><br />Meneer geeft aan dat het voertuig gestolen is, echter geen aangifte van gedaan.<br />Dit omdat er volgens meneer niemand beschikbaar was voor de aangifte.<br /><br />Meneer geeft aan met een handhaver te hebben gepraat, echter heeft hij geen naam.<br />Wel een telefoonnummer, die valt is.<br />Aangegeven telefoonnummer: 06-5547<br /><br /><br />Meneer is vrijgelaten wegens te weinig bewijs.</p>', 1607989583),
(77, 234, 'Witwassen, kleine hoeveelheid drugs', '89346270207', 'Wiet verkoop locatie in het noorden van de stad', '', 'Ja', 'f8871d5a180f1abec1efd5decfb5a52d02e0eb8d', 'Witwassen, kleine hoeveelheid drugs', '5600 zwartgeld, 3 zakjes wiet, zaadjes', '<p>Meneer werd aangetroffen op de wiet verkoop locatie met 5600 zwartgeld en wat zakjes wiet op zak. Na een uitgebreid verhoor, in het bijzijn van twee advocaten, verklaard de meneer dat het geld en de wiet niet van hem zijn en hij deze heeft gekregen van een ander persoon. Het geld en de drugs zijn in beslag genomen en meneer heeft een bekeuring gekregen voor een kleine hoeveelheid drugs + een geheel VOORWAARDELIJKE celstraf voor de duur van 15 weken.<br /><br />Volgende keer gepakt met drugs? Dan 15 weken er bovenop!!<br /><br /><br /></p>', 1608050859),
(78, 234, 'Verkopen van een drugs locatie', '35035755669', 'Nieuwe locatie \'\'coke pluk\'\'', 'Gunther', 'Nee', 'cfd4f826a415fa97105b5d8231e31473beb809d4', 'Verkopen van een drugs locatie', '', '<p>Persoon heeft via Twitter geadverteerd dat hij voor geld de nieuwe \'\'coke pluk\'\' locatie verkoopt. Gunther heeft contact met meneer opgenomen waarna hij voor 20.000 euro inderdaad een locatie aan de politie heeft verkocht. Meneer mag zich op een later moment nog melden op het politiebureau voor een verhoor. Staat vanaf nu gesignaleerd.</p>', 1608063328),
(79, 240, 'Het besturen van een gestolen voertuig', '43580654168', 'Cardealer', 'HI-201', 'Nee', '9e6a4228d141ad85da08fa6fde1d1293bcd9c2e1', 'Het besturen van een gestolen voertuig', 'Niks aangetroffen.', '<p>Meneer is staandegehouden bij de cardealer.<br />Hier heeft meneer zijn rijbewijs laten zien. Deze was helemaal in orde.<br /><br />Voertuig stond niet op meneer zijn naam, even de eigenaar gebeld.<br />Meneer geeft aan dat het voertuig gestolen is.<br /><br />Mijn collega heeft de eigenaar van het voertuig gevraagd of meneer aangifte wilde doen.<br />Dit was niet het geval, hierdoor een voorwaardelijke celstraf van 30 weken gegeven.<br />Een bekeuring voor het rijden in een gestolen voertuig.<br /><br /><br /></p>', 1608070730),
(80, 235, 'medeplichtig aan moord op agent en poging op moord van een agent', '83075044412', 'oud politie bureau', 'Djenna en Joren', 'Ja', 'cfd4f826a415fa97105b5d8231e31473beb809d4', 'medeplichtig aan moord op agent en poging op moord van een agent', 'machete', '<p>Hij reed in een grijze a6 en hij hielp mee om onze collega te vermoorden.</p>\r\n<p>Later probeerde hij Djenna neer te steken.</p>', 1608122932),
(81, 234, 'Illegaal wapenbezit', '37173405909', 'Onbekend', 'Joren', 'Ja', 'c6179d5bfdd2c4d36a0ea031ffce2ca072793f1b', 'Illegaal wapenbezit', 'Switchblade', '<p>Meer info onbekend. Surveillant Joren heeft hem aangehouden.</p>', 1608131231),
(82, 240, 'Vluchten van Politie, Kleinschalig drugsbezit', '55058102510', 'Coke Pluk', 'HI-201', 'Ja', '50259a4ea751094fb11ac6a2cbc0fde548ac5fde', 'Vluchten van Politie, Kleinschalig drugsbezit', '27 coke + 77 gemiddelde zaadjes', '<p>Meneer is aangetroffen na een melding van een hele drukke bezochte locatie.<br />Meneer is gevlucht en daarna gefouilleerd.<br />Hier is 27 coke aangetroffen, in zijn auto zaten 77 gemiddelde zaadjes.</p>', 1608131526),
(83, 240, 'Vluchten van Politie, stond nog gezocht voor drugsbezit', '62449861690', 'Dubbele garage', 'HI-201 A-41', 'Ja', 'f1116d96ca083780c1751dbfd5f1d8d363d5c869', 'Vluchten van Politie, stond nog gezocht voor drugsbezit', '-', '<p>Meneer is na 4x achtervolging met A-41 nogmaals gevlucht.<br />Na een wilde achtervolging is meneer in de boom beland, waarna meneer is gaan rennen.<br />Hier is meneer getaserd, en aangehouden.<br />Meneer had geen rijbewijs.<br /><br />Tijdens verhoor was meneer vervelend, en wilde gebruik maken van een advocaat zonder papieren.<br /><br />Gegeven straf: 45 weken en 3 bekeuringen. ( Rijden zonder geldig rijbewijs - Grote hoeveelheid drugs - 50 km/h te hard. )</p>', 1608133195),
(84, 239, 'medeplichtig zijn aan een OV', '6734422699', 'Grote bank op het dak', '-', 'Ja', '7559dc591b5ab69a232b9fda6277223c6125e899', 'medeplichtig zijn aan een OV', 'Honkbal kunppel, 14 coke en 16k zwartgeld', '<p>Meneer lag op het dak en was medeplichtig aan de ov die gaande was door informatie door te spelen naar de overvallers. De overvallers hebben 8 agenten geliquideerd.</p>', 1608143886),
(85, 236, 'Mishandelen agent', '28556274011', 'Kledingwinkel zuiden van blokkenpark', 'Henk (transport)', 'Ja', 'ff85a3989e3f211247e598ffc005c847eeab9ca5', 'Mishandelen agent', '', '<p>Na staandehouding agent proberen neer te slaan</p>', 1608157150),
(86, 236, 'Poging stelen politie motor', '79986358675', 'Kledingwinkel in het zuiden van BP', 'Rico (transport)\r\nHenk', 'Ja', '689ae4cd6e3e94db8cd6b5d61ee31d3f530e8396', 'Poging stelen politie motor', '', '<p>Na staandehouding probeerde hij politievoertuig te stelen.</p>', 1608157529),
(87, 236, 'Mishandelen agent', '8780160962', 'Zuiden van BP kledingwinkel', 'Henk', 'Ja', 'e5a9f7f8632e8566c2b6201b64015eb3bf1c183b', 'Mishandelen agent', '', '<p>&nbsp;</p>\r\n<p style=\"box-sizing: border-box; margin-top: 0px; margin-bottom: 1rem;\">Na staandehouding agent proberen neer te slaan</p>', 1608157726),
(88, 234, 'Aanwezig op een drugs locatie en in bezit van kleine hoeveelheid drugs', '57228201651', 'Wiet verkoop locatie', 'Drugseenheid', 'Ja', 'a42767a3a0edff57312adf6f1b45d68b92277059', 'Aanwezig op een drugs locatie en in bezit van kleine hoeveelheid drugs', '34 gram wiet', '<p>Deze meneer is aangehouden tijdens een geplande drugs-inval op de wiet verkoop locatie in het noorden van de stad, op 17-12-2020. Hij had een kleine hoeveelheid drugs bij zich. Volgens meneer zelf had hij de drugs van iemand \'\'gekregen\'\'. Na een verhoor op het bureau heeft meneer een bekeuring ontvangen voor de drugs. Hij heeft geen celstraf gekregen in verband met de kleine hoeveelheid drugs.</p>', 1608167881),
(89, 235, 'vluchten voor politie', '49781651454', 'Blokkenpark', 'Joren en Djenna', 'Ja', 'ff7534df1fe781809a6cf0f5a3f586bb41978a52', 'vluchten voor politie', '/', '<p>Hij reed op een blauwe motor.<br />Hij draagt nette kleding met een bruine vest.<br />Hij is getint.</p>', 1608225014),
(90, 235, 'vluchten voor politie', '13250306186', 'Politie bureau', 'Djenna en Joren', 'Ja', '6ed7c90d19a1cc6b895e960a2a11a6106e9c7094', 'vluchten voor politie', '/', '<p>Hij besloot om via de lift te vluchten.<br />Hij heeft een Witte g klasse.<br />Hij draagt een net pak en een bruin vest.</p>', 1608225131),
(91, 236, 'Vluchten voor politie', '38223950712', 'Winkel Nelis Nettorama (onder grote rivier in het noorden)', 'Benno\r\nJoren (transport)', 'Ja', '02b0d2f64ddeb250e39ced5c8e4cb70e3650526b', 'Vluchten voor politie', '', '<p>Meneer werd door 2 politiemotor agenten (Benno en ik) gevraagd om naar de verkeerscontrole te gaan en hij zou ook volgen om ernaar toe te gaan. Meneer besloot om dat toch niet te doen en probeerde te vluchten.</p>', 1608235179),
(92, 240, 'Gewapende overval - Zware Mishandeling op een Agent - Vluchten van Politie - Wapenbezit', '79216632298', 'Cardealer', 'HI-201 - HA-100', 'Ja', '510f01cd0093ca8a1912e62fb65092c3caf5cea5', 'Gewapende overval - Zware Mishandeling op een Agent - Vluchten van Politie - Wapenbezit', 'Mes', '<p>Meneer heeft een volgteken gekregen van een Audi A6.<br />Deze heeft meneer genegeerd, na een wilde achtervolging met veel gevaar, is meneer van een motor afgetaserd door HH-02.<br /><br />Hierna is meneer meegenomen naar het Politie Bureau, waar meneer de HH-02 meerdere keren heeft beledigd.<br />Tijdens het fouilleren is een mes aangetroffen. Deze is inbeslag genomen.<br />Hier is een advocaat geregeld.<br />Tijdens een gesprek met de advocaat heeft meneer de HI-201 zwaar mishandeld.<br /><br />Tevens stond meneer in het systeem voor 2x gewapende overval.<br />Gegeven straf: 3x boete ( Zware Mishandeling - Gewapende Overval - Het negeren van een stopteken )<br />120 weken celstraf.<br /><br /></p>\r\n<p>&nbsp;</p>', 1608235501),
(93, 239, 'Grootschalig drugs bezit', '31577415151', '', 'Benno, Maxim, Nelis, Joren en Gilles', 'Ja', '2af7ef20a2cf6d5287e282e01d9c9535f4965d3b', 'Grootschalig drugs bezit', 'Zie bijlage', '<p>Op 17-12 om 21:03 waren wij bezig met een verkeerscontrole. Hier hielden wij een g-klasse mercedes staande voor een controle. Toen mijn collega de papieren na keek keek ik (Covid Nick) in zijn kofferbak en zag daar veel drugs in liggen. Ik riep mijn collega\'s en wij rukte snel uit waardoor we de 2 verdachte hebben kunnen aanhouden. <br /><br />Aangetroffen spullen:<br /><img src=\"https://i.gyazo.com/acd0e8eff970c29f289c17d1db41143f.png\" /><br /><br /><em>Deze zijn afgehandeld.</em></p>', 1608237153),
(94, 234, 'Medeplichtig aan dodelijke steekpartij op een agent', '65008015882', 'Wiet verkoop', 'Moranos, Gerald, Stefano, Djenna, Maxim, Joren, Benno', 'Ja', 'ff7534df1fe781809a6cf0f5a3f586bb41978a52', 'Medeplichtig aan dodelijke steekpartij op een agent', '', '<p>Meneer was onderdeel van een groep van 3 personen die onze agent \"Maxim\'\', die undercover op de wiet verkoop locatie aanwezig was voor een onderzoek voor de drugseenheid, probeerde te rippen. Tijdens deze rip-actie is agent Maxim door messteken om het leven gekomen. Meneer heeft 2 boetes en een gevangenisstraf van 30 weken ontvangen.</p>', 1608240908),
(95, 234, 'Medeplichtig aan dodelijke steekpartij op een agent', '15715743721', 'Wiet verkoop', 'Moranos, Gerald, Stefano, Djenna, Maxim, Joren, Benno', 'Ja', 'f8871d5a180f1abec1efd5decfb5a52d02e0eb8d', 'Medeplichtig aan dodelijke steekpartij op een agent', '', '<p>Meneer was onderdeel van een groep van 3 personen die onze agent \"Maxim\'\', die undercover op de wiet verkoop locatie aanwezig was voor een onderzoek voor de drugseenheid, probeerde te rippen. Tijdens deze rip-actie is agent Maxim door messteken om het leven gekomen. Meneer heeft 2 boetes en een gevangenisstraf van 30 weken ontvangen.</p>', 1608240952),
(96, 234, 'Doodsteken van een agent tijdens een mislukte rip', '60565583516', 'Wiet verkoop\r\n', 'Moranos, Gerald, Stefano, Djenna, Maxim, Joren, Benno', 'Ja', '6ed7c90d19a1cc6b895e960a2a11a6106e9c7094', 'Doodsteken van een agent tijdens een mislukte rip', 'Mes', '<p>Meneer was onderdeel van een groep van 3 personen die onze agent \"Maxim\'\', die undercover op de wiet verkoop locatie aanwezig was voor een onderzoek voor de drugseenheid, probeerde te rippen. Tijdens deze rip-actie is agent Maxim door messteken om het leven gekomen. Meneer Jeff Jow was degene die de agent doodstak en het mes werd later tijdens het fouilleren ook op hem aangetroffen. Meneer heeft 3 boetes en een gevangenisstraf van 60 weken ontvangen.</p>', 1608241059),
(97, 238, 'meermaals vluchten', '72464442604', 'blokkenpark', 'HH-09,HH-10,HH-11,S-20,S-21,S-23,', 'Ja', '888ff35281db785b78f7e85d5b35cf0245839e94', 'meermaals vluchten', '', '<p>deze persoon heeft meerdere malen gevlucht van politie. Dit tegen zeer hoge snelheden en het nodige gevaar.</p>', 1608337704),
(98, 238, 'valsheid in geschriften ', '67487738717', 'HB', '', 'Ja', '5915cd48de62bf84857b53287778a49dcd1d097c', 'valsheid in geschriften ', '', '<p>persoon weigert identiteitskaart te tonen en doetr als advocaat met de nodige arogantie naar mij toe. deze persoon is hier dan ook 30weken voor naar het mooiste hotel van maasland&nbsp;</p>', 1608337990),
(99, 238, 'hinderen van politie werk en spionage ', '47675060771', 'HB', '', 'Ja', '1772c75a1b350140f4c950f131b3c6c08a9edc6b', 'hinderen van politie werk en spionage ', '', '<p>meneer vond het nodig om foto\'s en beelden van de politie te maken zonder toestemming. Toen ik meneer vroeg hier me te stoppen bedreigde hij met de dood en schold collega\'s en mezelf uit.&nbsp;</p>', 1608339031),
(100, 238, 'grootschalig drugbezit', '48928426959', 'dubbele garage', 'A-41,DE-HI-200,S-20,S-21', 'Ja', '09955907399e7d7fbfb2b1a617a10b3f6efb9ba0', 'grootschalig drugbezit', '180 bundels opium', '<p>HI-200 en ik waren metde zullu aan het vliegen toen we een verdachte Nissan titan zagen. Hij sprak ons aan door zijn rijstijl. wij hebben toen een voertuig die kant op laten komen. Toen wij meneer zagen stoppen bij de arrestant dit op een verlate plek. Dus zijn onze mensen over gaan tot controle van de personen.&nbsp; Toen is meneer gaan vluchten en hebben wij hem gearresteerd in dubbele garage met de drugs.</p>', 1608388362),
(101, 236, '100 opium opzak na controle eerder drugsbezit hebben', '57184262615', 'Zijkant blokkenpark', 'Willy\r\nJoren (transport)', 'Ja', 'e4ad21001b75d68f572591dcd8ae6606a3bc79cc', '100 opium opzak na controle eerder drugsbezit hebben', '100 opium', '<p>WIj wouden hem na staandehouding controleren op drugs omdat hij hiermee eerder al in aanraking is geweest. Zoals verwacht, is er drugs aangetroffen.</p>', 1608410060),
(102, 236, 'Bezit drugs', '18308699724', 'Zijkant blokkenpark', 'Willy\r\nJoren (transport)', 'Ja', '4388f811b6b481a3af991a0dbd18e5ec7243c9ea', 'Bezit drugs', '41 opium', '<p>Na samen te rijden met iemand dat werd aangehouden voor drugsbezit ook gecontroleerd, 41 opium aangetroffen.</p>', 1608410166),
(103, 234, 'Werd nog gezocht voor drugs in zijn auto', '86672471385', 'ANWB ', 'Benno en Maxim', 'Ja', '0cb72f25a1703dc974256a780d8470d7fbe13988', 'Werd nog gezocht voor drugs in zijn auto', '', '<p>Tim Brouwer treffen wij aan bij de ANWB op een motorfiets waarop een vriend van meneer naar ons toekomst en zegt dat meneer Brouwer geen geldig rijbewijs heeft. Bij controle blijkt hij inderaad enkel in het bezit te zijn van een autorijbewijs. Tevens wordt hij nog gezocht omdat 4 dagen geleden een grote hoeveelheid drugs in zijn auto is aangetroffen.</p>\r\n<p>Meneer is meegenomen voor verhoor waar hij na een moeizaam gesprek in ieder geval de exacte locatie van de wiet verpak heeft bevestigd. Meneer heeft een gevangenisstraf gekregen voor de duur van 15 weken voor de aangetroffen drugs in zijn auto waarvoor hij nog gezocht werd.</p>', 1608412008),
(104, 236, 'Bezit drugs', '18308699724', 'Zijkant blokkenpark', 'Willy\r\nJoren (transport)', 'Ja', '4388f811b6b481a3af991a0dbd18e5ec7243c9ea', 'Bezit drugs', '41 opium', '<p>Na samen te rijden met iemand dat werd aangehouden voor drugsbezit ook gecontroleerd, 41 opium aangetroffen.</p>', 1608413122),
(105, 236, 'Weigeren 3 vorderingen', '69840372668', 'ANWB', 'Benno\r\nNiels', 'Ja', '3ae750c19a2e00df018886bb7940b03cf736b925', 'Weigeren 3 vorderingen', '', '<p>Na betogen zonder toestemming van de burgemeester aangehouden omdat hij na 3 vorderingen het terrein niet wou verlaten.<br /><br /></p>', 1608413245),
(106, 236, '100 opium opzak na controle eerder drugsbezit hebben', '57184262615', 'Zijkant blokkenpark', 'Willy\r\nJoren (transport)', 'Ja', 'e4ad21001b75d68f572591dcd8ae6606a3bc79cc', '100 opium opzak na controle eerder drugsbezit hebben', '100 opium', '<p>WIj wouden hem na staandehouding controleren op drugs omdat hij hiermee eerder al in aanraking is geweest. Zoals verwacht, is er drugs aangetroffen.</p>', 1608413391),
(107, 236, 'Negeren van 3 vorderingen', '86274337310', 'Anwb', 'Benno\r\nWilly\r\nNiels', 'Ja', 'ff733ec40b618549532cb53a870546392a7cd65a', 'Negeren van 3 vorderingen', '', '<p>Na demonstratie zonder toestemming locatie niet willen verlaten</p>', 1608413430),
(108, 236, 'Negeren van 3 vorderingen', '53113647272', 'ANWB', 'Niels\r\nBenno\r\nWilly', 'Ja', '3af6ea2a76163f2babbc62389625de81a67f57a7', 'Negeren van 3 vorderingen', '', '<p>Na demonstratie zonder toestemming locatie niet willen verlaten</p>', 1608413492),
(109, 241, 'Mishandelen van burger', '62741308924', 'Stoep tegenover politiebureau', 'Joren', 'Ja', '451a37b492f16fc209ca078ea7bb31cfc0fdd5f9', 'Mishandelen van burger', 'niks', '<p>Meneer is gearresteerd, 20 weken celstraf met een boete.</p>', 1608415157),
(110, 234, 'Zeer grote hoeveelheid drugs en een mes', '20616670586', 'Coke verpak', 'Maxim, Joren, Tim, Benno, Gunther, Nicolaas', 'Ja', 'e19631f09bc522ffeb2a6a5e187298c68b461d05', 'Zeer grote hoeveelheid drugs en een mes', '391 opium, 589 wiet, 430 wiet bundels, 1 mes', '<p>Op 20-12 rond 14:35 waren we de coke verpak verdachte locatie weer aan het observeren. Hier troffen wij 1 verdachte aan. Wij hebben daar 20 minuten gezeten en gezien hoe de verdachte spullen aan het in en uitladen was. Op een gegeven moment besloot de verdachte er vandoor te gaan en wilde zijn voertuig op het vliegveld stallen. Dit vermoedde wij al en onze collega\'s stonden meneer daar al op te wachten. Wij gingen hier snel achteraan waardoor de verdachte in geboxed stond. <br /><br />Na wat duw en trek werk en een gewonden collega die aan gereden werd, hebben we meneer toch kunnen aanhouden. Ter plekke hebben we hem gefoullieert en in zijn auto gekeken. Daar troffen wij een gigantische hoeveelheid drugs aan wat ons er op wijst dat er op deze locatie wel meer gebeurd dan alleen rond hangen. Op het bureau wilt meneer in het verhoor niets biechten. Zelfs niet voor strafvermindering. Meneer kreeg drie boetes en een gevangenisstraf voor de duur van 60 weken.</p>', 1608480674),
(111, 234, 'Grootschalig drugsbezit en wapenbezit', '12308757779', 'Coke verpak', 'Maxim', 'Ja', 'e4ad21001b75d68f572591dcd8ae6606a3bc79cc', 'Grootschalig drugsbezit en wapenbezit', 'Veel drugs en een mes', '<p>Meneer werd na een undercover-actie van de drugseenheid aangehouden vanwege vermoelijke drugs-smokkel. Tijdens fouilleren werd inderdaad een erg grote hoeveelheid drugs aangetroffen en ook nog een mes. Na een uitgebreid gesprek met de advocaat, waarin meneer meerdere kansen heeft gehad om te praten, bleef hij zich beroepen op zijn zwijgrecht waarop hij naast de bekeuringen ook 60 weken celstraf heeft gekregen.</p>', 1608490086),
(112, 234, 'Openbare agressie / mishandeling en bedreigen van een agent', '84083951875', 'Blokkenpark', 'Rico, Willy', 'Ja', '5915cd48de62bf84857b53287778a49dcd1d097c', 'Openbare agressie / mishandeling en bedreigen van een agent', '', '<p>Meneer liep op Blokkenpark en spreekt een collega aan. Er komt een motor aangereden van een vriend van hem waarop hij de bestuurder van de motor van de motor af trapt en op zijn \'\'vriend\'\' blijft inslaan totdat hij buiten bewustzijn is. Meneer is aangehouden waarop hij zeer verbaal agressief reageerde en meerdere agenten heeft bedreigd. Na een gesprek met de advocaat heeft meneer een straf gekregen van 35 weken.</p>', 1608490272),
(113, 234, 'Bijrijder van een voertuig wat werd achtervolgd / medeplichtig', '51327934416', 'Blokkenpark', 'Nelis / VealGaming', 'Nee', 'a7634d6693aa3e798b42dd3ebb10d5531190bb8a', 'Bijrijder van een voertuig wat werd achtervolgd / medeplichtig', '', '<p>Meneer was de bijrijder van een voertuig wat er op Blokkenpark vandoor ging, bij het klemrijden van de auto gingen zowel de bestuurder als de bijrijder \'\'toevallig\'\' tegelijk de stad uit vanwege internetproblemen. De bijrijder hebben we later alsnog kunnen aanhouden, de bestuurder is helaas niet meer aangetroffen. Meneer Manfred heeft slechts 1 bekeuring ontvangen voor medeplichtigheid aan een strafbaar feit.</p>', 1608491768),
(114, 233, 'x', '60829194549', 'garage achter blokkenpark appartement', 'djenna', 'Ja', '709aed03dd705a8e24be74017a2fa6c7d1eff1d3', 'x', 'x', '<p>rijdt zonder rijbewijs rond in zijn vrachtwagen&nbsp;</p>\r\n<p>&nbsp;</p>', 1608575576),
(115, 233, 'vluchten voor politie', '38984966922', 'kruispunt richting snelweg', 'djenna camezonda xander nick', 'Ja', '33d8b278e8936a746f947a6c8b464ac83a50c7a6', 'vluchten voor politie', 'x', '<p>gevlucht in een blauwe hurucan</p>', 1608575821),
(116, 235, 'vluchten voor politie ', '26766693395', 'Blokkenpark', 'Henk', 'Ja', '33d8b278e8936a746f947a6c8b464ac83a50c7a6', 'vluchten voor politie ', '/', '<p>Hij reed in een licht blauwe lamborghini performante.<br />Hij draagt zwarte kleding een bril en een hoed.</p>', 1608577314),
(117, 234, 'Rijden zonder rijbewijs, illegaal slagwapen', '45236536241', 'Ikea', 'Xander, Benno, Joren, Henk Pietersen', 'Nee', 'e19631f09bc522ffeb2a6a5e187298c68b461d05', 'Rijden zonder rijbewijs, illegaal slagwapen', 'Honkbalknuppel', '<p>Meneer werd staande gehouden voor een verkeerscontrole ter hoogte van de Ikea. Meneer bleek te rijden zonder rijbewijs en in zijn voertuig lag een honkbalknuppel. Boete gegeven, honkbalknuppel NIET in beslag genomen ivm een erg goed verhaal.</p>', 1608578502),
(118, 234, 'Illegaal steekwapenbezit', '74565129486', 'Casino Maasland', 'Benno, Djenna, Willy, Piet Grasman', 'Ja', 'c6179d5bfdd2c4d36a0ea031ffce2ca072793f1b', 'Illegaal steekwapenbezit', 'Mes', '<p>De politie kreeg op maandagavond 21 december kort voor middernacht een melding van de eigenaar van het casino in Maasland dat er een persoon in hun casino zou zijn die een mes op zak zou hebben. Personeel van het casino heeft meneer aangehouden alszijnde \'\'burgerarrest\'\'. Meneer is meegenomen door agenten waarbij hij nog kort heeft geprobeerd agenten te steken, wat mislukt is. Boete + gevangenisstraf van 20 weken.</p>', 1608591923),
(119, 234, 'Vluchten voor politie', '59408480535', 'Cardealer Maasland', 'Djenna, Benno, Willy', 'Ja', '3e049a45da56a55da1fcff6ac7e10ae476cdd179', 'Vluchten voor politie', '', '<p>Het voertuig van meneer (een blauw/groene Golf GTI) werd aangetroffen op Blokkenpark terwijl dit voertuig nog gezocht werd voor diverse drugs feiten. Meneer ging er vandoor bij het zien van politie maar kon met behulp van de politiehelikopter korte tijd later worden aangehouden bij de cardealer. Meneer had een vrij goed verhaal en heeft het voertuig mogelijk overgekocht van een persoon. Dit kon niet 100% bewezen worden. Meneer heeft 10 weken gekregen.</p>', 1608594325),
(120, 236, 'Mishandelen gewonde agent die op de grond ligt', '48488039321', 'Blokkenpark', 'Willy', 'Ja', '3e049a45da56a55da1fcff6ac7e10ae476cdd179', 'Mishandelen gewonde agent die op de grond ligt', '', '<p>Meneer trapte op mijn collega wanneer hij al gewond op de grond lag. Na poging tot vluchten aangehouden en disrespect naar de politie.</p>', 1608596718),
(121, 235, 'vluchten voor politie', '59095526662', 'Blokkenpark', 'Joren', 'Ja', '581847ce1034fbe5fe329663f57a2bfceadf8279', 'vluchten voor politie', '/', '<p>Hij reed in een grijs/zwarte koenigsegg.</p>\r\n<p>De wagen had het kenteken :&nbsp;<span style=\"background-color: #f3f3f4; color: #676a6c; font-family: \'open sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 13px; font-weight: bold;\">IQD 783</span></p>\r\n<p>Hij had zelf een jeans jasje en een zwarte broek aan.</p>\r\n<p>&nbsp;</p>', 1608650467),
(122, 233, 'vluchten ', '74984990421', 'boven ziekenhuis', 'moranos', 'Ja', 'ad8c51f579efe2460da3414e5ed9e5e5ea84be24', 'vluchten ', 'x', '<p>voorwaardelijke straf van 60 weken onnodig vluchten voor politie</p>', 1608651289);
INSERT INTO `reports` (`id`, `user`, `incident`, `cad`, `located`, `otherUnits`, `arrested`, `person`, `arrestedFor`, `foundItems`, `whatHappened`, `dateline`) VALUES
(123, 241, 'Verbouwen van wietplanten voor het politiebureau', '7464601106', 'Tegenover politiebureau', 'nee', 'Ja', '1295fdfefd9289bdd2d0b004ecf154befaafedb6', 'Verbouwen van wietplanten voor het politiebureau', '1 perfect zaadje, 28 bronwater en 28 kunstmest', '<p>Meneer was planten aan het plaatsen voor het politiebureau, zijn straf wa een boete en 10 weken celstraf</p>', 1608660793),
(124, 239, 'Achterlijk rijgedrag en vluchten voor politie', '69027906386', 'Snelweg ten hoogte van de gevangenis', 'Djenna, Joren, Hans, Nelis, Maxim, Melvin en Xander', 'Ja', '13b62c8968746d04253c6f7649b019ba259017a1', 'Achterlijk rijgedrag en vluchten voor politie', '1000 Opium', '<p>De verdachte in de gaten gehouden op een drugs locatie (opium pluk). Daar reed meneer weg en even later hielden we hem staande langs de weg. Voordat we contact hadden besloot meneer te vluchten. Na verschillende inbox acties om meneer stil langs de weg te krijgen, stond het voertuig stil. We hebben daar meneer overmeesterd en de buit aangetroffen. 1000 Opium. Na verhoor heeft meneer gebiecht dat hij hier Opium fabriceerde. Dit inruil voor strafvermindering. <br /><br />De verdachte: Pete Hoekstra</p>', 1608668187),
(125, 239, 'x', '42024489886', 'Blokkenpark', 'Djenna', 'Nee', '888ff35281db785b78f7e85d5b35cf0245839e94', 'x', 'x', '<p>Meneer heeft mogelijk een slachtwapen op zak, 2 burgers hebben gezien dat hij iemand zijn nek eraf heeft gesneden. getuige: Jeroen Mem (ambulance Baas) &amp; Thijs Mem (OM Baas)</p>', 1608728506),
(126, 239, 'x', '29380474278', 'x', 'x', 'Nee', '9c18b6e2baff50fdb1a96018e7f796bcc0e03351', 'x', 'x', '<p>Meneer zijn voertuig (Nissan Titan met Dollar velgen) kenteken: RDZ 924&nbsp; &nbsp; is vaker gezien bij onlangs opgerolde drugs locaties, en zien wij vaker in beeld bij het zoeken van informatie bij locaties. Al met al denken wij dat deze meneer veel bezig is met drugs. - Jordy Meyer</p>', 1608730020),
(127, 241, 'Grootschalig drugsbezit', '37875814742', 'Koper verkoop (in de haven)', 'Henk Walker (Drukkemen)', 'Ja', '709aed03dd705a8e24be74017a2fa6c7d1eff1d3', 'Grootschalig drugsbezit', 'wiet en zakjes', '<p>Meneer is na een melding van een ander persoon aangehouden voor het grootschalig drugsbezit. (621 wiet en 121 zakjes wiet)</p>', 1608751750),
(128, 234, 'Illegaal wapenbezit en vluchten voor politie', '27479703886', 'Blokkenpark Appartement', 'Nicolaas, Benno', 'Nee', '960dfef0120d1adb68e9c3b46443d6be5ca8b8cb', 'Illegaal wapenbezit en vluchten voor politie', 'Mes en wat opium', '<p>Jurro is Mijnwerker zag meneer lopen met een mes, heeft melding gemaakt waarop meneer door collega\'s rijdend werd aangetroffen. Na een korte achtervolging sprong hij ter hoogte van de Blokkenpark appartementen uit zijn auto en ging hij gauw het appartement in. Toen meneer weer naar buiten kwam hebben we een gesprek met hem gehad waarin hij aangaf dat hij geen mes had. Meneer gaf vrijwillig toestemming tot huiszoeking waar wij inderdaad toch een mes hebben aangetroffen. Meneer is in zijn appartement aangehouden.<br /><br />LET OP: Toen we het appartement uit wilden gaan moest meneer reloggen ivm een onzichtbaarheids-bug. Nadat hij terug is ingelogd heeft hij in zijn appartement snel /chardel gedaan en een andere naam en uiterlijk gemaakt waardoor hij uiteindelijk niet meer is aangetroffen. Meneer staag nog gesignaleerd en zal op ene later moment nog een straf krijgen voor de duur van 50 weken. Zijn nieuwe naam is Piet Spetter.</p>', 1608753096),
(129, 241, 'poging tot moord op agent, en tweemaal vluchten voor politie', '17418103457', 'dubbele garage', 'Henk Walker (Drukkemen)', 'Ja', '1295fdfefd9289bdd2d0b004ecf154befaafedb6', 'poging tot moord op agent, en tweemaal vluchten voor politie', 'niks', '', 1608753784),
(130, 234, 'Vluchten voor de politie en illegaal wapenbezit', '91890875232', 'Achter Blokkenpark bank', 'Benno, Djenna, Joren, Hans', 'Ja', '888ff35281db785b78f7e85d5b35cf0245839e94', 'Vluchten voor de politie en illegaal wapenbezit', 'Mes', '<p>Tijdens reguliere dienst zag ik, Benno, een meneer lopen die vrijwel exact voldeed aan het signalement van een meneer die wij nog zochten. Ik besloot hem te controleren waarop meneer er te voet vandoor ging. Hij vluchtte via de trappen de blokkenpark bank op waarna hij ook weer helemaal naar beneden is geklommen. Eenmaal beneden probeerde hij alsnog te ontkomen waarop meneer is aangehouden. Hierbij is een taser gebruikt.</p>\r\n<p>Uiteindelijk bleek het niet de meneer te zijn die we nog zochten maar omdat hij wel een mes had en ook wilde vluchten mocht hij alsnog mee. Door een foutje kreeg meneer slechts 6 weken celstraf ipv 20/30.</p>', 1608772409),
(131, 241, 'Een slagwapen opzak hebben', '44240510966', 'Blokkenpark', 'Joren', 'Ja', '7b01b6ae89d5ed03ce91e6005c3475723d10f5d6', 'Een slagwapen opzak hebben', 'Honkbal knuppel', '<p>We kregen 2 meldingen dat er iemand op Blokkenpark een knuppel in zijn hand had, hij heeft hiervoor een boete en een 20 weken celstraf voor gekregen.</p>', 1608816264),
(132, 241, 'Grote wietplantage met andere mensen', '55235421224', 'Onder een brug langs de snelweg', 'nee', 'Ja', '7e4eaa864f2932ba2176f3eb19671b1440f44e2b', 'Grote wietplantage met andere mensen', 'Zaadjes, kunstmest en bronwater', '<p>Meneer was met vier andere een plantage aan het beheren. Deze meneer is 1 van de 2 die ik heb aangehouden. 35 weken celstraf.</p>', 1608842355),
(133, 241, 'Grote wietplantage met andere mensen', '33732438804', 'Onder een brug langs de snelweg', 'nee', 'Ja', 'ca614797429a951519572287ec6920ddbbdc1d1e', 'Grote wietplantage met andere mensen', 'Zaadjes, kunstmest en bronwater', '<p>Meneer was een plantage aan het beheren met 3 andere mensen, deze meneer is hiervoor aangehouden. 35 weken celstraf</p>', 1608842455),
(134, 241, 'Een slagwapen opzak hebben, mishandelen van agent', '92527638160', 'Parkeerplaats politiebureau', 'nee', 'Ja', 'c6179d5bfdd2c4d36a0ea031ffce2ca072793f1b', 'Een slagwapen opzak hebben, mishandelen van agent', 'Knuckleduster', '<p>Meneer stond mij op te wachten op de parkeerplaats bij het bureau, hij sloeg mij 3 maal met een boksbeugel, met behulp van een taser heb ik hem aangehouden. 60 weken + 3 boetes</p>', 1608842978),
(135, 234, 'Verdacht van wapenbezit (mes)', '61307808666', 'Blokkenpark', 'Joren en Benno', 'Nee', '6ed7c90d19a1cc6b895e960a2a11a6106e9c7094', 'Verdacht van wapenbezit (mes)', '', '<p>Tijdens onze dienst krijgen wij een 112-melding dat er twee mannen in een grijze Porsche zouden rijden in de omgeving van Blokkenpark met een mes. Na enkele minuten treffen we het voertuig aan en zijn beide personen gefouilleerd op basis van de Wet Wapens en Munitie. Geen mes aangetroffen.&nbsp;</p>', 1608845569),
(136, 234, 'Wapenbezit (mes)', '19251871097', 'Blokkenpark', 'Joren', 'Ja', 'b81a50ccd90d699d26af83b965c2f6af832588b2', 'Wapenbezit (mes)', 'Mes', '<p>Tijdens onze dienst kregen we een 112-melding dat er op Blokkenpark iemand zou lopen met een mes. Omdat meneer de Bolle veel matchende uiterlijke kenmerken had werd besloten meneer te fouilleren op basis van de melding. Meneer verleende de volle medewerking en ging vrijwillig mee naar het bureau. Boete gekregen en een celstraf voor 20 weken voor verboden wapenbezit (mes).</p>', 1608845712),
(137, 239, 'Grootschalig drugsbezit', '73815465021', 'Appartementen dorpje noorden', 'Djenna, Joren & Rico', 'Ja', 'c6179d5bfdd2c4d36a0ea031ffce2ca072793f1b', 'Grootschalig drugsbezit', '800 Opium', '<p>Drugseenheid info (Opium pluk info)</p>', 1608943863),
(138, 235, 'Hinderen val politie werk en mishandelen van een politie agent', '57353451149', 'politie bureau', 'Nick, Joren, Willy en BÃ©an', 'Ja', '19ba5f65c80cc5f55fb4d1c8f539e81106b8e7d1', 'Hinderen val politie werk en mishandelen van een politie agent', '/', '<p>Hij droeg een roze jas en hij had een gele helm en eenmasker van een varken aan.<br />Hij reed in een zwarte mercedes g65.</p>', 1608994758),
(139, 235, 'Grootschalig drugs bezit', '8357107849', 'In de buurt van opium verpak.', 'Nick, Willy en joren', 'Ja', '739c5381e3be7f23eded2ef1fabda7c592d723fa', 'Grootschalig drugs bezit', '120 bundels Opium', '<p>Hij reed in een roze titan met roze neon onder aan.<br />hij droeg een witte hoedi en een blauw mondmasker.</p>', 1608998896),
(140, 234, 'Illegaal steekwapenbezit', '20864403263', 'Tussen Blokkenpark en de dubbele garage', 'Benno, Rico', 'Ja', 'f8871d5a180f1abec1efd5decfb5a52d02e0eb8d', 'Illegaal steekwapenbezit', 'Mes', '<p>Meneer zegt te werken bij de slager in het noorden van de stad en hij was onderweg naar zijn werk. Een \'\'vriend\'\' van hem reed met hem mee. Deze zogenaamde vriend spreekt een agent aan dat meneer Lente in het bezit zou zijn van cocaine, waarop meneer is gefouilleerd op basis van de Opiumwet. Er werd geen drugs aangetroffen maar wel een flink vleesmes van ongeveer 30 centimeter. Volgens meneer Zina Lente had hij dit mes mee om te gaan werken bij de slager. Het mes is uiteraard in beslag genomen voor verder onderzoek. Opvallend detail was ook nog dat meneer, op zijn ondergoed na, g&eacute;&eacute;n kleding aan had. Boete + gevangenisstraf van 15 weken.</p>', 1609025072),
(141, 239, 'Mishandelen van agent, Verhinderen politie werk, Verstoren openbare orde', '64717433032', 'De weg tussen Bp en dubbelgarage in', 'Benno, Willy, Djenna, Rico en Joren', 'Ja', '6ed7c90d19a1cc6b895e960a2a11a6106e9c7094', 'Mishandelen van agent, Verhinderen politie werk, Verstoren openbare orde', '-', '', 1609025246),
(142, 239, 'Mishandelen politie agent, verstoren openbare orde, verhinderen politie werk', '30920552421', 'De weg tussen BP en dubbele garage', 'Benno, Djenna, Joren, Rico en Willy', 'Ja', 'cfd4f826a415fa97105b5d8231e31473beb809d4', 'Mishandelen politie agent, verstoren openbare orde, verhinderen politie werk', 'x', '<p>Robby Williams</p>', 1609025437),
(143, 239, 'Een onderzoek wat tegen hem liep over drugs.', '74432523540', 'Blokkenpark', 'Rico', 'Ja', '9c18b6e2baff50fdb1a96018e7f796bcc0e03351', 'Een onderzoek wat tegen hem liep over drugs.', '1009 wiet zakken en 2459 Opium', '<p>Wij hebben Jordy Meyer in de ochtend van 27-12 aangehouden bij bp. We hebben hem de situatie uitgelegd en daarna zijn auto overhoop gehaald en meneer gefoullieerd. Hier troffen wij een gigantische hoeveelheid drugs aan in zijn rode Nissan Titan met de opvallende Dollar velgen. (kenteken:&nbsp;<br /><br />-1009 Wiet zakken<br />-2459 Opium<br /><br />Beeldmateriaal:<br /><img src=\"https://steamuserimages-a.akamaihd.net/ugc/1654475863318299216/7ADF06ACB4F523D83987A684BD12F2E32B12CCEB/\" /><br /><img src=\"https://steamuserimages-a.akamaihd.net/ugc/1654475863318295488/A9E199713C2A64DA47E48322D8ACB0355148BD89/\" /><br /><br />Voor nu is de zaak afgerond.</p>', 1609065744),
(144, 236, 'Stelen van een voertuig en verkopen', '85684165341', 'Helemaal in het noorden, impound 6', 'Benno\r\nMaxim\r\nJoren\r\nDjenna', 'Ja', '1295fdfefd9289bdd2d0b004ecf154befaafedb6', 'Stelen van een voertuig en verkopen', '18,5 k zwart (goedgekeurd door belasting)', '<p>Wij kregen een melding van een voertuig dat gestolen werd. Al snel zag ik meneer wegrijden in een oranje voertuig. Achtervolging begon bij de snelweg van ziekenhuis en ging tot waar hij aangehouden is. Tijdens de achtervolging heeft meneer zeer slordig gereden. Hij heeft daarnaast ook nog zo goed als bekend.<br /><br />Straf: Bijbehorende bekeuringen, rijbewijs ingevorderd, 20 weken celstraf.</p>', 1609072823),
(145, 233, 'drugsbezit ', '81147468753', 'hangar sandy ', 'Djenna joren bean', 'Ja', '9c18b6e2baff50fdb1a96018e7f796bcc0e03351', 'drugsbezit ', '150 opium', '<p>meerdere malen in aanraking geweest bij de politie voor drugs bezit&nbsp;</p>\r\n<p>&nbsp;</p>', 1609080802),
(146, 233, 'Achterlijk rijgedrag en poging tot vluchten van politie', '40698088718', 'viaduct bij ziekenhuis', 'joren', 'Ja', '3e049a45da56a55da1fcff6ac7e10ae476cdd179', 'Achterlijk rijgedrag en poging tot vluchten van politie', 'x', '<p>poging tot vluchten van politie is naar het bureau afgevoerd aangezien meerdere vlucht poingen gedaan heeft</p>', 1609085864),
(147, 233, 'x', '74624721884', 'tequilla wagen gespot', 'benno gilles joren', 'Nee', 'ad8c51f579efe2460da3414e5ed9e5e5ea84be24', 'x', 'x', '<p>wagen aangetroffen bij tequilla overval niet gestolen opgegeven&nbsp; kenteken VIM 793</p>', 1609096096),
(148, 234, 'Dood door schuld', '82596718382', 'Politiebureau', 'Benno', 'Nee', 'd67b72bd65e501e15f038ce7b20a3bf2e0de8847', 'Dood door schuld', '', '<p>Meneer komt zich melden op het politiebureau dat hij iemand heeft doodgereden op Blokkenpark. De ambulance heeft echter geen melding gekregen. Meneer vermoedelijk onder invloed van alcohol en/of drugs. Ambulance naar het politiebureau laten komen en meneer is meegenomen naar het ziekenhuis voor verder onderzoek. Van een aanrijding op Blokkenpark is g&eacute;&eacute;n bewijs meer gevonden.</p>', 1609096326),
(149, 234, 'Vluchten voor de politie, achterlijk rijgedag', '54941621703', 'Rechter snelweg thv casino', 'Benno, Cleamen, Joren, Djenna, Nelis', 'Ja', 'bb41e9f53b1edce5cdcba675e7da7c71b1adb95f', 'Vluchten voor de politie, achterlijk rijgedag', '', '<p>Tijdens de dienst kwam er een 112-melding van een mogelijke gijzeling met een vuurwapen op het vliegveldje in het noorden van de stad. Eenmaal aangekomen reden er meerdere voertuigen, waarom Lamborghini\'s en Bugatti\'s met zeer hoge snelheid weg. Nadat meneer Henk Jan een zeer zwaar ongeval kreeg waarbij hij meerdere keren over de kop sloeg, kon hij wonder boven wonder gewoon verder rijden. Hierbij reed hij over meerdere bergen met zijn Lamborghini. Omdat er per toeval ook een politiehelikopter boven de achtervolging vloog, kon meneer in een steegje nabij de Tequila-la toch worden aangetroffen. Hierbij probeerde hij wederom te vluchten en belandde zijn Lamborghini op de kop. Ook dit was voor meneer geen enkel probleem en weer reed hij weg van de politie, terwijl er nota bene 2 vuurwapens op hem gericht waren.<br /><br />Vanwege dit alles ontving meneer drie boetes en de maximale gevangenisstraf van 120 weken.<br /><br /><br /></p>', 1609101149),
(150, 234, 'Vuurwapenbezit', '46268628565', 'Vliegveld', 'Djenna, Nico', 'Nee', '6e8f42511bda8fe195b8e40f0c1486ce0d4b3552', 'Vuurwapenbezit', 'Heavy Pistol', '<p>De politie kreeg op 27 december rond 23:30 uur meerdere schotmeldingen vanaf het grote vliegveld in de stad. Toevallig waren we redelijk in de buurt en bij aankomst werd er direct met vuurwapens op ons geschoten waarop de noodknop is ingedrukt, wat betekend dat alle politie die op dat moment in dienst is op deze melding zal reageren. De man met het vuurwapen (Jax Hammer) kon worden uitgeschakeld en een andere persoon kwam met een machete op een collega afgerend. Uiteindelijk kon ook deze meneer worden uitgeschakeld.<br /><br />OOC: Staff is ingezet ivm red zone. Volgens meneer Robin Fox heeft de politie in dit geval juist gehandeld.</p>', 1609111910),
(151, 234, 'Illegaal steekwapenbezit', '11940736342', 'Vliegveld', 'Djenna, Nico', 'Nee', 'c6179d5bfdd2c4d36a0ea031ffce2ca072793f1b', 'Illegaal steekwapenbezit', 'Machete', '<p>De politie kreeg op 27 december rond 23:30 uur meerdere schotmeldingen vanaf het grote vliegveld in de stad. Toevallig waren we redelijk in de buurt en bij aankomst werd er direct met vuurwapens op ons geschoten waarop de noodknop is ingedrukt, wat betekend dat alle politie die op dat moment in dienst is op deze melding zal reageren. De man met het vuurwapen kon worden uitgeschakeld en een andere persoon (meneer Tarzan Eeteenappel dus) kwam met een machete op een collega afgerend. Uiteindelijk kon ook deze meneer worden uitgeschakeld.<br /><br />OOC: Staff is ingezet ivm red zone. Volgens meneer Robin Fox heeft de politie in dit geval juist gehandeld.</p>', 1609111982),
(152, 234, 'Vluchten voor de politie, achterlijk rijgedag, rijden in gestolen voertuig', '81515616964', 'Linker snelweg richting het noorden, nog voor de militaire basis', 'Djenna, Nico, Benno, Rico', 'Ja', 'e19631f09bc522ffeb2a6a5e187298c68b461d05', 'Vluchten voor de politie, achterlijk rijgedag, rijden in gestolen voertuig', 'Knuppel', '<p>Naam: Stomme Beer 20-08-2000<br /><br />Op zondagavond 27 december net voor middernacht kreeg de politie een melding van een actieve \'\'carthief\'\'. Op de linker snelweg richting het noorden kon meneer vrij eenvoudig worden aangehouden nadat hij met vrij hoge snelheid op een hersenloze reed en crashte. Nadat commissaris Benno een vuurwapen op de gecrashte auto richtte stapte meneer meteen uit met zijn handen omhoog. Hij heeft medische assistentie gekregen van de ambulancedienst. Tijdens het fouilleren bleek hij een knuppel op zak te hebben. Hierbij had hij het inmiddels standaard verhaaltje dat hij zojuist van de honkbaltraining af kwam. Zijn knuppel is in beslag genomen en naast de boetes kreeg meneer een celstraf voor de duur van 30 weken.&nbsp;</p>', 1609112148),
(153, 242, 'meneer werd gefouilleerd en troffen opium aan ', '42638527812', 'Opium Pluk', 'Nico Speculaas', 'Ja', 'f52fcdbeb66345c9c4a39aeea757fcf5b510980c', 'meneer werd gefouilleerd en troffen opium aan ', '146 opium', '<p>schoten bij opium pluk en deze meneer aangetroffen met grote hoeveelheid opium. meneer een boete gegeven en 20 weken celstraf.</p>', 1609193957),
(154, 234, 'Stelen van een voertuig, vluchten voor politie, rijden zonder rijbewijs', '51801229028', 'Rechter snelweg richting het noorden', 'Djenna, Benno, Rico', 'Ja', '709aed03dd705a8e24be74017a2fa6c7d1eff1d3', 'Stelen van een voertuig, vluchten voor politie, rijden zonder rijbewijs', '', '<p>Meneer is aangehouden na een carthief, reageerde niet op 4 waarschuwingsschoten. Uiteindelijk getaserd. Geen medische assistentie want er was geen ambu. Meneer bleek ook geen rijbewijs te hebben. Drie boetes + 30 weken straf gekregen. Naam: Johan Knakker (27-09-2000)</p>', 1609196733),
(155, 243, 'Drugsbezit & plantage op verboden terrein', '794964023', 'Carthief', 'Benno, Nico, Piet', 'Ja', '04dd4d1b9428857183ee8174064602bd1d9c88c5', 'Drugsbezit & plantage op verboden terrein', '3000 ZWARTgeld, 234 wiet, 12 slechte zaadjes', '<p>Helikopter vloog rond de haven en kon met warmte beelden zien dat er personen stonden op de carthief locatie, verboden terrein. Ambulance was blijkbaar al ter plaatsen. Op de camera beelden kon Nick zien dat de overige personen (dus geen ambu) een masker droegen. Piet en Djenna reden naar de locatie en de 2 mannen werden gefouilleerd. Hier is dus het grote hoeveelheid drugs bij beide aangetroffen. Iets verderop waren ook een stuk of 10 wiet planten geplaatst. Bas Woods is aangehouden en meegenomen naar het bureau. Hij is beboet voor de drugs en 15 weken de gevangenis in gestuurd. De persoon die bij Bas Woods stond is op de vlucht gegaan, en bij zijn poging tot vluchten is hij verdronken.&nbsp;</p>', 1609200562),
(156, 239, 'Vluchten van politie en uit eindelijk grootschalig drugs bezit en intentie op het verkopen van drugs', '33792303210', 'Weg bij het kerkhof', 'Joren, Djenna, Nelis en Gilles', 'Ja', '772ce9b768a2ca40b15d1308794de1235d146e8d', 'Vluchten van politie en uit eindelijk grootschalig drugs bezit en intentie op het verkopen van drugs', '2150 Weed bundels & grote hoeveelheid contant geld', '<p>Collega\'s hoorde ontploffing bij d film studio en wij zagen dit voertuig daar weg rijden. Collega\'s gaven stop teken maar meneer negeerde dit volop. En reed erg roekeloos. Toen het voertuig total loss was hebben we meneer aangehouden en meegenomen naar het bureau. Voordat hij in het voertuig is gezet hebben we hem gefoullieerd en een extreem grote hoeveelheid contante geld aangetroffen in zijn tas. Daarna hebben wij het voertuig gecontrolleerd en 2150 bundels wiet aangetroffen.&nbsp;<br /><br /><br /></p>', 1609274792),
(157, 243, 'Carthief, vluchten voor politie, 11-voudig moord, bedreiging ambtenaar in functie, eventuele wapenbezit, ', '8944389160', 'Achterkant ziekenhuis', 'Benno, Gunther, Joren, Rico was in gedachte', 'Ja', '2c425779392935e6aa8266eeebe3586eafade47b', 'Carthief, vluchten voor politie, 11-voudig moord, bedreiging ambtenaar in functie, eventuele wapenbezit, ', '/', '<p>De politie kreeg een carthief melding. In het gestolen voertuig reed de heer Aardappelboom. Wij wilden hem staande houden en hij probeerde toen te vluchten. Hij werd uiteindelijk gearresteerd en meegenomen naar het bureau. Hier vertelde de meneer dat hij maar liefst 250 duizend euro op het hoofd van Liesbeth gezet heeft. Ook heeft hij verteld dat hij 11 mensen vermoord heeft. Voor de rest zijn er heren op het bureau gekomen met bodycam beelden waarop de heer Aardappelboom een wapen vast hield.&nbsp;</p>\r\n<p><img src=\"https://steamuserimages-a.akamaihd.net/ugc/1655601990421707956/8D8264B1F94CF0CD6757B76427BC0AA761D550C3/\" /></p>\r\n<p>&nbsp;</p>', 1609281198),
(158, 239, 'voor illegaal wapen bezit', '70776189824', 'YellowJack', 'Djenna, joren, Bean', 'Ja', 'f1116d96ca083780c1751dbfd5f1d8d363d5c869', 'voor illegaal wapen bezit', 'Een mes', '<p>De verdachte was de gijzelaar. Nadat we hem bevrijd hebben uit de bar die werd overvallen troffen we een mes aan.</p>', 1609331352),
(159, 239, '-', '42335102972', 'Offroad weg bij Mount Chiliad', 'Joren en Maxim', 'Nee', '95df390a126027784095194098f6662d0116873e', '-', '-', '<p>We kregen een melding van een wietplantage, toen we later t.p. kwamen troffen we 2 voertuigen aan. &Eacute;en voertuig reed weg met 3 personen erin. Deze zij achtervolgt en meerdere malen verzocht om te stoppen. Toen zijn er een aantal pitacties gemaakt en zijn ze van het berg weggetje gevallen. Toen wij hier beneden kwamen waren alle 3 de verdachten spoorloos. In het voertuig troffen wij wel een grote hoeveelheid drugs aan.&nbsp;<br /><br />Kenteken van de Nissan Titan (grijs van kleur): RQT 663<br />Hoofd verdachte (waarschijnlijke bestuurder &amp; eigenaar voertuig): Rommie Ringstaart&nbsp;<br /><br />Afbeelding van het voertuig:<br /><br /><img src=\"https://steamuserimages-a.akamaihd.net/ugc/1654476178435088445/D1790B3ABBFEB283ED80C00245E318F11A14DC41/\" /><br /><br />Aangetroffen middelen:<br /><br /><img src=\"https://steamuserimages-a.akamaihd.net/ugc/1654476178435088204/B001852D4728763C0F512EF65014189F721B5D4A/\" /><br /><br /></p>', 1609338416),
(160, 244, 'Stelen van een voertuig ', '8150375267', 'Olie verwerk', 'Collega Maxim (op de motor)', 'Ja', '9e6a4228d141ad85da08fa6fde1d1293bcd9c2e1', 'Stelen van een voertuig ', '15500 euro zwartgeld', '<p>heeft 55 weken celstraf gekregen + de nodige boetes&nbsp;</p>\r\n<p>&nbsp;</p>', 1609343253),
(161, 244, 'poging tot moord , op agent roekeloos rijgedrag , vluchten van de politie...', '21358136606', 'zand weg naast olie verwerk ', 'Collega Maxim (op de motor)', 'Ja', '94c943213ef3250749780cea3b91b2abc4962c04', 'poging tot moord , op agent roekeloos rijgedrag , vluchten van de politie...', 'niets aangetroffen', '<p>heeft 70 weken gekregen</p>', 1609343575),
(162, 241, 'Carthief, vluchten voor politie,drugsbezit', '70732449735', 'In de woestijn', 'Gunther', 'Ja', '3e049a45da56a55da1fcff6ac7e10ae476cdd179', 'Carthief, vluchten voor politie,drugsbezit', '88 opium en 10 coke', '<p>Meneer deed een carthief</p>', 1609355341),
(163, 241, 'Carthief, vluchten voor politie,drugsbezit', '38484385903', 'Rechts van de map, carthief locatie', 'BeÃ¡n', 'Ja', '13b62c8968746d04253c6f7649b019ba259017a1', 'Carthief, vluchten voor politie,drugsbezit', '3 zakjes wiet', '', 1609357172),
(164, 238, 'plukken van illegale goederen ', '33829176592', 'opium pluk', 'veel te veel10 mensen ', 'Ja', '296f66e26b2904b4b339198f8bcf9aec751bc056', 'plukken van illegale goederen ', '315opium', '<p>meneer is opgepakt bij opium pluck naast de vuurtoren n/o van maasland.<br /><br />De drugs eenheid heeft een inval op deze locatie gedaan. Daar bij is de verdachte aan getroffen met een grote hoeveelheid opium.</p>\r\n<p>en heeft hij 40 weken cel gekregen.</p>', 1609358702),
(165, 234, 'Vluchten van de politie + roekeloos rijgedrag', '38824316603', 'Op de snelweg nabij het ziekenhuis', 'Benno en Piet', 'Ja', 'ca614797429a951519572287ec6920ddbbdc1d1e', 'Vluchten van de politie + roekeloos rijgedrag', '', '<p>Op 31 december omstreeks 01:10 uur zagen wij een persoon rijden in een witte Volvo. Toen wij meneer wilde controleren voor een routine controle besloot de bestuurder er vandoor te gaan. Helaas was hij niet opgewassen tegen de nieuwe Audi RS6 en Mercedes A45 AMG van de politie waarop hij is klemgereden toen hij nota bene al spookrijdend een snelweg op wilde rijden, om aan de politie te ontkomen. Meneer had gewoon een rijbewijs en ook geen illegale goederen bij zich. Zijn rijbewijs is ingevorderd, en naast drie bekeuringen kreeg hij ook een gevangenisstraf voor de duur van 20 weken. Naam: Koos Boomsmaa</p>', 1609374233),
(166, 234, 'Rijden zonder rijbewijs en vluchten voor de politie', '23807329272', 'Blokkenpark', 'Benno', 'Ja', 'f1116d96ca083780c1751dbfd5f1d8d363d5c869', 'Rijden zonder rijbewijs en vluchten voor de politie', '', '<p>Meneer werd aangetroffen bij het Blokkenpark op een motorfiets. Toen ik zijn motorrijbewijs wilde controleren ging meneer ervandoor. Na een korte achtervolging ben ik meneer kwijtgeraakt maar na een paar minuten zag ik hem weer op het Blokkenpark. Zelfs met een taser op hem gericht dacht hij nog weg te kunnen lopen. Meneer is aangehouden. Naam: Jesse Denge</p>', 1609408051),
(167, 233, 'Poging tot vluchten van politie ', '56864668493', 'blokkenpark', 'Joren benno djenna', 'Ja', 'ff9a7e870bd2bcebef05fc09ef7eee8958560cae', 'Poging tot vluchten van politie ', 'x', '<p>persoon is aangehouden voor vluchten van politie op een gestolen motor, en is ook bestraft op het \'\'betrapt op gijzeling van opsporing\'\'</p>', 1609432951),
(168, 234, 'Medeplichtig aan carthief', '14188340310', 'Carthief inlever punt', 'Cleamen, Dako, Benno', 'Ja', 'f1116d96ca083780c1751dbfd5f1d8d363d5c869', 'Medeplichtig aan carthief', '', '<p>Meneer was handlanger van een persoon die een carthief deed. Na overleg met advocaat kreeg hij 2 boetes en een celstraf van 10 weken. Naam: Jesse Denge</p>', 1609515644),
(169, 234, 'Illegaal slagwapen bezit', '34792725742', 'Nabij casino', '', 'Ja', '6ed7c90d19a1cc6b895e960a2a11a6106e9c7094', 'Illegaal slagwapen bezit', 'Knuppel', '<p>Meneer was bijrijder van een motor die ervandoor ging. Tijdens de achtervolging reed de motor vol in op een politieauto waardoor de twee opzittenden konden worden aangehouden. De bestuurder van de motor had een mes bij zich, de bijrijder (meneer Jan Biertje dus) had een knuppel op zak. Celstraf 15 weken.</p>', 1609541183),
(170, 244, 'stelen van een (npc) voertuig', '24031020531', 'Brandweerpand bij de inpoundgarage ', 'Benno,xander,piet,nick,willy', 'Ja', '3390d1200277381480aa58e3c1ad09ce6ba01992', 'stelen van een (npc) voertuig', 'neen', '<p>man is aangehouden voor stelen van een voertuig en heeft een celstraf gekregen van 15 weken</p>', 1609541351),
(171, 239, 'x', '8020532042', 'Blokkenpark', 'Willy en Maxim', 'Nee', '8fd63629709e96359b1449f7ffcb18b0061d6de8', 'x', 'Wilde niet meewerken', '<p>De blonde meneer op het beeldmateriaal:<br />https://youtu.be/iAzfx_VGURM</p>', 1609601408),
(172, 239, 'illegaal wapen bezit', '31515430231', 'Blokkenpark', 'willy en maxim', 'Ja', '25189e32fe9aab1b598c016aa6819453d796f49e', 'illegaal wapen bezit', 'x', '<p>In het beeldmateriaal zien we hoe we een melding kregen over deze mevrouw die een wapen zou bezitten. Deze mevrouw word afgefoullieert door een blonde persoon (<span style=\"color: #676a6c; font-family: \'open sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 13px; font-weight: bold; background-color: #ffffff;\">Ezio Auditore Da Firenze) </span>en die werd weer afgefoullieert door een andere persoon (sako van der wal). Hier troffen we een pistol aan.</p>', 1609601656),
(173, 238, 'wapen bezit en vluchten voor politie', '42190229774', 'bp', 'maxim en nico', 'Ja', 'd6b954dc390eb684e1c62a44ccc117a4f73a6de1', 'wapen bezit en vluchten voor politie', 'VINTAGE PISTOL', '<p>Na een melding over een vrouw met paars haar (Elisabeth Fox) met een wapen zijn wij naar BP gegaan met 2 voertuigen en 3 man. Tijdens het wachten was meneer zich zeer zenuwachtig aan het gedragen. Tijdens de controle van deze persoon heeft hij het op een lopen gezet. Na een korte achtervolging hebben wij meneer alsnog kunnen controleren.&nbsp;</p>\r\n<p>Videobewijs</p>\r\n<p>https://youtu.be/iAzfx_VGURM</p>', 1609601765),
(174, 244, 'vuur maken voor het politiebureau', '31850113607', 'Naast politiebureau', 'Piet', 'Ja', 'a25f8740cffbc3fe7af77cc6c576b14c86a57ab0', 'vuur maken voor het politiebureau', 'niets', '<p>Deze man is gearresteerd en heeft 25 weken gekregen&nbsp;</p>', 1609603247),
(175, 244, 'Vrouw aantasten poging tot doodslag op agent...', '9463500259', 'Politiebureau', 'Djenna', 'Ja', '543a32bd0aa7e3ec12bcd4824a1906332cc20a6a', 'Vrouw aantasten poging tot doodslag op agent...', 'neen', '<p>Meneer heeft 15 weken gekregen door onze collega djenna aan te tasten en haar wapen aan te raken wat een poging tot doodslag is (moest het wapen geladen zijn)</p>\r\n<p>&nbsp;</p>', 1609604476),
(176, 241, 'Poging tot moord op burger (ruim 20 maal).', '7497209332', 'Parkeergarage boven cardealer waar het midnight event was', 'nee', 'Ja', '510f01cd0093ca8a1912e62fb65092c3caf5cea5', 'Poging tot moord op burger (ruim 20 maal).', 'niks', '<p>Poging tot moord op burger (ruim 20 maal). Hij reed tijdens het event ruim 20 mensen aan met zijn roze Mercedes g klasse. De lokale beveiliging van het event had hem te pakken gekregen, waarna hij is meegenomen door de politie, en een celstraf heeft ontvangen van 80 weken.</p>', 1609615797),
(177, 235, 'medeplichtig zijn aan een strafbaar feit', '18268058676', 'snelweg bij de gevangenis', 'Nick en Piet', 'Ja', 'd0f0cfad363f5a2a56ae9dbd9dfa7cf2579f963c', 'medeplichtig zijn aan een strafbaar feit', '20 wiet', '<p>Hij was zwart gekleed en hij nam vrijwillig afstand van de 20 gram wiet.</p>', 1609629315),
(178, 235, 'medeplichtig zijn aan een strafbaar feit', '73694697269', 'snelweg bij de gevangenis', 'Piet', 'Ja', 'f9a9f709ad19a1a4dc75a23195399057e326d9d4', 'medeplichtig zijn aan een strafbaar feit', '/', '<p>Hij droeg een bruine jas.<br />Hij had zwart haar.</p>\r\n<p>&nbsp;</p>', 1609629396),
(179, 233, 'Niet luisteren naar vorderingen', '7270537501', 'oud politie bureau', 'dako benno', 'Ja', 'c6179d5bfdd2c4d36a0ea031ffce2ca072793f1b', 'Niet luisteren naar vorderingen', 'knuppel', '<p>aangetroffen met een illegaal slagwapens</p>\r\n<p>&nbsp;</p>', 1609681206),
(180, 241, '150 wiet opzak', '49010307445', 'Impound links in de stad', 'Gillas', 'Ja', '66b18c91f3131503fa592866636a4487edad504b', '150 wiet opzak', '150 wiet', '<p>Meneer had 150 wiet uit een auto gepakt. Hier is hij voor gearresteerd. Meneer heeft 25 weken gekregen&nbsp;</p>', 1609686328),
(181, 235, 'vluchten voor politie', '42800041908', 'snelweg juist voorbij het casino', 'Dako, Joren en Willy', 'Ja', 'ea1908f637d250cb99b14f3775b702860ae55f35', 'vluchten voor politie', '/', '<p>Hij draagt een net pak met een bruine vest.</p>\r\n<p>Hij is kaal en heeft een grijze baard.</p>', 1609697956),
(182, 241, 'Carthief, vluchten voor politie', '61913011096', 'Ergens in de woestijn', 'Willy, Maxim en Joren', 'Ja', '888754c309cc5f26aaf176e8cf7e2674d141af8c', 'Carthief, vluchten voor politie', 'niks', '', 1609703192),
(183, 238, 'achterlijk rijgedrag en vluchten', '83736223181', 'bp', 'Maxim en Joren ', 'Ja', 'd6b954dc390eb684e1c62a44ccc117a4f73a6de1', 'achterlijk rijgedrag en vluchten', '', '', 1609704066),
(184, 241, 'Carthief, vluchten voor politie', '23235703369', 'Snelweg rechts van de map', 'Joren, Willy, Maxim', 'Ja', 'c6179d5bfdd2c4d36a0ea031ffce2ca072793f1b', 'Carthief, vluchten voor politie', 'niks', '<p>Meneer deed een carthief, waarna hij vluchtte in een lichtblauwe SVJ van een vriend van hem.</p>', 1609707402),
(185, 234, 'Mogelijke ontvoering', '69287601121', 'Vlakbij politiebureau nabij het strand', 'Gunther, Maxim, Benno', 'Ja', '634aba4078317754f58bb076eed3ae328b0e03c2', 'Mogelijke ontvoering', '10 gram coke', '<p>Wij krijgen tijdens de dienst een 112 melding van een mogelijk ontvoering, meneer geeft aan in een rode Jeep Trackhawk ontvoerd te zijn. Wij treffen de rode Jeep aan waarop personen worden gecontroleerd. <br /><br />De bestuurder verklaart van niks te weten en blijkt 10 gram coke op zak te hebben. Tevens heeft hij geen rijbewijs. Hij is aangehouden voor mogelijke ontvoering, bezit van harddrugs en het rijden zonder rijbewijs. De bijrijder en tevens melder, meneer Gazza LLoris, is meegenomen ter verhoor.&nbsp;</p>', 1609707800),
(186, 241, 'Zware mishandeling van burger, vluchten voor politie', '52227735314', 'een kip locatie vlakbij politiebureau.', 'BeÃ¡n', 'Ja', '902ca59b50336cb0a11f384b50377c39615b9aaa', 'Zware mishandeling van burger, vluchten voor politie', 'niks', '', 1609766895),
(187, 241, 'rijden zonder rijbewijs, vluchten voor politie', '12964175671', 'Rijschool', 'nee', 'Ja', '4b81f3f9d18c328e220697b4766c5e069ce8fe08', 'rijden zonder rijbewijs, vluchten voor politie', 'niks', '<p>de straf was 30 weken met 3 boetes</p>', 1609769114),
(188, 233, 'x', '24752039767', 'blokkenpark', 'joren nelis bean ', 'Nee', '2814e1b2911981a5b679fc6fb6ca3a3684e02222', 'x', 'x', '<p>Word gezocht vluchten van politie Werkt bij de taxi</p>', 1609775531),
(189, 233, 'vluchten voor politie', '24673292229', 'Taxi ', 'Joren', 'Ja', '2814e1b2911981a5b679fc6fb6ca3a3684e02222', 'vluchten voor politie', 'kunstmest en bronwater', '<p>HIj is aangehouden en we gaan een gesprek aan met de baas,&nbsp;</p>', 1609776386),
(190, 244, 'meerdere malen vluchten voor de politie ', '63924284602', 'Taxi Terrein', 'Cleamen , Nelis , Bean en ikzelf', 'Ja', '2814e1b2911981a5b679fc6fb6ca3a3684e02222', 'meerdere malen vluchten voor de politie ', 'niets', '<p>deze man is meerdere malen gevlucht en heeft 35 weken gekregen</p>', 1609777710),
(191, 241, 'Carthief, vluchten voor politie', '2032581795', 'Snelweg recht op de map', 'Gillas', 'Ja', '8b1fd825b120a9218068c5033d3ee656c82976a4', 'Carthief, vluchten voor politie', 'niks', '<p>carthief</p>', 1609783897),
(192, 234, 'Vluchten voor de politie + stelen van een voertuig (carthief)', '85323891893', 'Langs het water vlakbij het politiebureau', 'Benno', 'Ja', '13b62c8968746d04253c6f7649b019ba259017a1', 'Vluchten voor de politie + stelen van een voertuig (carthief)', '', '<p>Tijdens de dienst was Benno alleen aangezien de andere 5 collega\'s actief waren bij een overval. Er kwam een melding van een zogenaamde carthief. Het voertuig kwam langs het politiebureau gereden waarop de achtervolging werd ingezet. De verdachte probeerde zich via meerdere kleine straatjes en steegjes aan het zicht van Benno te onttrekken maar dit had helaas geen gewenst resultaat. Meneer werd klemgereden en aangehouden. Hij kreeg 2 bekeuringen en een celstraf van 20 weken. Naam: Tinus Bouwvakker (10-10-2020)</p>', 1609786145),
(193, 239, 'na incident kwam zijn naam naar voren en in het systeem stond hij genoteerd voor medeplichtig bij voervallen.', '92000267898', 'Blokkenpark', 'Nelis', 'Ja', '235127453aacd075f7f0435b524e36d67c8b2c77', 'na incident kwam zijn naam naar voren en in het systeem stond hij genoteerd voor medeplichtig bij voervallen.', 'niets', '', 1609787896),
(194, 244, '', '42622910090', 'Brug voor de gevangenis (snelweg)', 'Gilles', 'Ja', '3f1f279e7b990b9b6b3e641bc4d89dd883cf11ad', '', 'nee', '', 1609788148),
(195, 241, 'Mishandelen van agent, niet luisteren naar vorderingen', '46815649234', 'Politiebureau (buiten de hekken)', 'Joren', 'Ja', 'a25f8740cffbc3fe7af77cc6c576b14c86a57ab0', 'Mishandelen van agent, niet luisteren naar vorderingen', 'niks', '', 1609791958),
(196, 244, 'Carthief ', '92412831249', 'Aan het politiebureau', 'Nelis , Benno en ikzelf', 'Ja', '0cb72f25a1703dc974256a780d8470d7fbe13988', 'Carthief ', 'kleine 12.000 euro zwartgeld ', '<p>Deze persoon is naar de cel gestuurd voor het stelen van een voertuig (carthief) hij stopte gaf zelf aan dat hij fout zat etc en heeft daarom 15 weken gekregen.</p>', 1609861595),
(197, 233, 'x', '34878919031', 'appartement blokkenpark', 'joren', 'Nee', '9851f19e2266b8cccaa3067b65d67266ee2b57ec', 'x', '29400 euro', '<p>persoon rood meerdere malen door rood en heeft een masker op in de wagen en een hoop geld bij</p>', 1609862229),
(198, 244, 'Ca', '4468005063', 'Sandy shores dicht bij coke pluk ', 'Nelis', 'Ja', '7bdbf0ae6bbe4727ed3ddcb5960542eaf43015aa', 'Ca', '', '', 1609864067),
(199, 244, 'Hij wilde een man neersteken ', '75038914906', 'Achter Blokkenpark', 'Djenna', 'Ja', 'b07dfad0ac18404eb9f559c87d238586746c2181', 'Hij wilde een man neersteken ', '1 Machete', '<p>hij heeft 45 weken gekregen voor poging tot doodslag op een burger en het in bezit zijn van een illegaal slagwapen&nbsp;</p>', 1609865632),
(200, 244, 'Carthief', '56124751563', 'Kleding winkel onder de legerbasis', 'Nick , Djenna en ikzelf ', 'Ja', '6e8f42511bda8fe195b8e40f0c1486ce0d4b3552', 'Carthief', 'X', '<p>Deze man heeft 20 weken gekregen...</p>\r\n<p>&nbsp;</p>', 1609869423),
(201, 241, 'Carthief, vluchten voor politie', '21925035419', 'Snelweg bij politiebureau', 'Xander, Gillas', 'Ja', '13b62c8968746d04253c6f7649b019ba259017a1', 'Carthief, vluchten voor politie', '90 wiet, zaadjes', '', 1609871667),
(202, 236, 'Medeplichtig carthief', '77767282588', 'Snelweg in de buurt van PB', 'Niels', 'Ja', 'c6179d5bfdd2c4d36a0ea031ffce2ca072793f1b', 'Medeplichtig carthief', '', '<p>Meneer hielp de verdachte die een voertuig had gestolen te vluchten en liet hem instappen en reed weg.<br /><br /><br /></p>', 1609871689),
(203, 239, 'Verwerken van cocaÃ¯ne', '46820876086', 'Coke verwerk locatie', 'Djenna, Joren en Maxim', 'Ja', 'd6b954dc390eb684e1c62a44ccc117a4f73a6de1', 'Verwerken van cocaÃ¯ne', 'Veel cocaÃ¯ne', '<p>Sako vanderwal</p>\r\n<p>&nbsp;</p>', 1609878905),
(204, 244, 'Carthief ', '28589675837', 'In de buurt van midnight ', 'Djenna', 'Ja', 'f8b159522c0c1933dad3982c2e0c9066ea62eb1c', 'Carthief ', 'X', '<p>deze man heeft 15 weken gekregen&nbsp;</p>\r\n<p>&nbsp;</p>', 1609880937),
(205, 238, 'vluchten en medeplichtig aan staf...', '25796417120', 'bp', 'Benno,Xander,Piet', 'Ja', 'bf2a6eb419e03d75b2e6f41600d07ff47f451e63', 'vluchten en medeplichtig aan staf...', '', '<p>Meneer heeft een verdachte helpen vluchten met een Mercedes E63 zwart.</p>\r\n<p>Na een korte achter volgging is meneer aangehouden na dat hij tegen een paal was gereden.</p>', 1609888326),
(206, 236, 'Voerdoen als advocaat + weigeren 3 vorderingen + hinderen politie', '3124924980', 'PB', 'Benno\r\nWilly\r\nDjenna', 'Ja', 'f52f861645ad5d16a29c2511268e0df6c5ba5183', 'Voerdoen als advocaat + weigeren 3 vorderingen + hinderen politie', '', '<p>Meneer dacht grappig te zijn en zich voor te doen als een advocaat. Na 3 vorderingen met de vraag het PB te verlaten blijven weigeren. Na aanhouding bekendde hij dat hij geen advocaat was.</p>', 1609888489),
(207, 244, 'Carthief ', '63217525722', 'Olie verwerk ', 'Djenna', 'Ja', '95df390a126027784095194098f6662d0116873e', 'Carthief ', '16500 zwartgeld', '<p>meneer heeft 15 weken gegeven&nbsp;</p>\r\n<p>&nbsp;</p>', 1609939779),
(208, 234, 'Verstoren van de openbare orde, belediging ambtenaar in functie en betreden van onbevoegd terrein', '78476758429', 'Politiebureau Maasland', 'Benno', 'Ja', '3ab14b3583a41077a5b7bb9cb180d2340a7b0bb8', 'Verstoren van de openbare orde, belediging ambtenaar in functie en betreden van onbevoegd terrein', '', '<p>Tijdens de middagdienst op 6 januari 2021 werd de rust ineens bruut verstoord toen er een mannetje of 5/6 het politiebureau kwam binnenstormen terwijl wij bezig waren met de afhandeling van een aanhouding. Tijdens deze bestorming werd onze collega Joren neergestoken door een nog onbekend persoon. Alle personen vluchtten verschillende kanten op, maar meneer Dilano Theedoek kon worden aangehouden. Hij kreeg bekeuringen voor het verstoren van de openbare orde, beledigen van een ambtenaar in functie en betreden van onbevoegd terrein. 3 boetes + 5 weken celstraf.</p>', 1609940270),
(209, 241, 'Niet luisteren naar vorderingen (tweemaal 3 vorderingen). Zware mishandeling van agent (tweemaal).', '90870582641', 'onder in de stad.', 'Ryan', 'Ja', 'e8fd7201a8d4b13a9181acd481e0545555eff468', 'Niet luisteren naar vorderingen (tweemaal 3 vorderingen). Zware mishandeling van agent (tweemaal).', 'niks', '<p>Meneer was verdacht van een ontvoering. Wij wilden hem fouilleren, en meneer wertke niet mee. Na 3 vorderingen hebben we hem aangehouden en meegenomen. Op het bureau werkte hij niet mee met zijn identificatie bewijs te tonen. We hebben een vingerscan gemaakt, en ik ging hem de boetes geven. Hij ging mij toen aanvallen. Uiteindelijk heb ik hem met mijn taser naar de grond gewerkt. Ik ging overleggen wat de celstraf ging zijn, en dat was 35 weken. Ik ging zijn celstraf geven, maar omdat hij niet naar de tralies kwam, moest ik nogmaals naarbinnen. Hier ging hij mij weer aanvallen, maar ik had hem optijd in de cel gestuurd.</p>', 1609943557),
(210, 235, 'Grootschalig drugs bezit', '44579000172', 'Snelweg bij casino', 'Ryanbier Nelis en Jesse', 'Ja', '9dd46817cc77e17888de05626823b7170c400f9c', 'Grootschalig drugs bezit', '60 zakken coke', '<p>Hij rijd in een donker blauwe audi rs6.<br />Hij draagt zwarte kleding.</p>', 1609949210),
(211, 234, 'Besturen van een gestolen voertuig', '50835022002', 'Inleverpunt carthief', 'Joren, Benno', 'Ja', '2814e1b2911981a5b679fc6fb6ca3a3684e02222', 'Besturen van een gestolen voertuig', '15.500 zwartgeld', '<p>Meneer dacht dat het slim was om een carthief te starten, werd aangehouden en accepteerde meteen de volle straf. Boete + 20 weken celstraf.</p>', 1609949375),
(212, 239, 'vluchten van politie zonder reden', '75901535316', 'ergens langs de snelweg', 'jesse en joren', 'Ja', '3390d1200277381480aa58e3c1ad09ce6ba01992', 'vluchten van politie zonder reden', 'niets', '', 1609951140),
(213, 241, 'vluchten voor politie, beledigen van ambtenaar in functie', '2051990146', 'Vlakbij Taxi', 'Rico (piet grasman)', 'Ja', '9e6a4228d141ad85da08fa6fde1d1293bcd9c2e1', 'vluchten voor politie, beledigen van ambtenaar in functie', 'niks', '', 1609951726),
(214, 235, 'vluchten voor politie en achterlijk rijgedrag', '2903269055', 'Blokkenpark', 'Joren', 'Ja', 'b6b17fdd0413cbc30f09ee02e23545b3dfe1be8b', 'vluchten voor politie en achterlijk rijgedrag', '/', '<p>Hij draagt grijze kleren.</p>\r\n<p>Hij is kaal</p>', 1609955199),
(215, 244, '', '20550009162', 'X', 'Djenna', 'Nee', '2ad59a21e18af6fc073bc435ab232164cab0a309', '', '', '<p>meneer de advocaat vlucht voor de politie ik heb zen rijbewijs ingenomen als je hem ziet = aanhouden voor vluchten van de politie</p>', 1610014400),
(216, 244, 'Carthief ', '39685011617', 'middle of nowhere', 'Djenna', 'Ja', '9851f19e2266b8cccaa3067b65d67266ee2b57ec', 'Carthief ', 'X', '<p>meneer heeft 15 weken celstraf gekregen.</p>\r\n<p>&nbsp;</p>', 1610016900),
(217, 241, 'Roekeloos rijgedrag (artikel 5). Rijden zonder rijbewijs.', '83974961232', 'Blokkenpark', 'Joren', 'Ja', '85adc44937ced8eca311d9da8a93d7d756e30a1b', 'Roekeloos rijgedrag (artikel 5). Rijden zonder rijbewijs.', 'niks', '<p>Meneer kwam met een hoge snelheid aanrijden op blokkenpark, aan de verkeerde kant van d weg. Daar ging hij op de stoep rijden, en hebben we hem staande gehouden. Zelf gaf hij al toe dat onze collega Djenna recentelijk zijn motor rijbewijs had ingetrokken. We hebben dus besloten om meneer aan te houden en mee naar het bureau te nemen. Hij kreeg hier de volgende boetes:</p>\r\n<p>- Achterlijk rijgedrag (Artikel 5)</p>\r\n<p>- Spookrijden</p>\r\n<p>- Rijden zonder geldig rijbewijs.</p>\r\n<p>&nbsp;</p>\r\n<p>Ook kreeg deze meneer een celstraf van 9 weken, omdat hij wel goed mee werkte.</p>', 1610028496),
(218, 241, 'Carthief, vluchten voor politie', '35020833561', 'Paleto Bay', 'Joren, Djenna, Gillas', 'Ja', '2814e1b2911981a5b679fc6fb6ca3a3684e02222', 'Carthief, vluchten voor politie', 'Zwartgeld', '<p>Carthief</p>', 1610030570),
(219, 241, 'Vluchten voor politie (tweemaal) Roekeloos rijgedrag, kleine hoeveelheid drugs, rijden zonder rijbewijs', '35418044216', 'Vlakbij de cardealer', 'Ryan', 'Ja', 'f52f861645ad5d16a29c2511268e0df6c5ba5183', 'Vluchten voor politie (tweemaal) Roekeloos rijgedrag, kleine hoeveelheid drugs, rijden zonder rijbewijs', '10 coke', '<p>Meneer reed te hard door de stad, we gingen hem achterna en hij vluchtte. Hij crashte tegen een vangrail. Later bleek dat onze Cleamen hem ook al had achtervolgt, maar dat hij was weggekomen. Ook reed hij zonder motorrijbewijs.</p>', 1610045789),
(220, 241, 'Carthief, vluchten voor politie', '80790794479', 'Begin linkerkant van snelweg', 'Ryan', 'Ja', 'b1245068e4f41a22b11b4b727257292313754bdc', 'Carthief, vluchten voor politie', 'niks', '', 1610045903),
(221, 241, 'Carthief, vluchten voor politie', '85946792317', 'Vlakbij de impound, als je van de haven af komt', 'Rico en Benno', 'Ja', '0bab117c64fb5d45041156e97b4e07f66e42625b', 'Carthief, vluchten voor politie', 'Niks', '<p>We kregen een melding van een carthief, daar hebben wij zo snel mogelijk op gereageerd. Toen meneer het havengebied had verlaten, kwam ik hem al tegen. Het ging om een Honda Civic Type-R. Ik gaf meneer een stopteken, dat negeerde hij. Na een kortdurende achtervolging reed hij tegen een houten paal aan, waarna hij een aantal keer ronddraaide en in de vamgrail terecht kwam. Hier hebben wij de meneer ingeboxt en met getrokken wapens tegen hem gezegd dat hij moest uitstappen. Hij kreeg een 20 weken celstraf.</p>', 1610098934),
(222, 234, 'Grote hoeveelheid drugs in zijn voertuig aangetroffen', '54903101942', 'Brug ter hoogte van oude ANWB', 'Benno', 'Ja', 'c6179d5bfdd2c4d36a0ea031ffce2ca072793f1b', 'Grote hoeveelheid drugs in zijn voertuig aangetroffen', '120 zakken coke', '<p>Ik zag meneer rijden in zijn zwarte Mercedes AMG ter hoogte van het Blokkenpark met volledig geblindeerde ruiten. Stopteken gegeven, en bij het controleren van zijn rijbewijs bleek meneer nog gezocht te worden ivm een vuurwapenmelding. Daarop meneer gaan fouilleren. Hij had niks op zak, maar in zijn voertuig trof ik 120 zakken cocaine aan. Alle zakken zijn in beslag genomen.</p>', 1610103527),
(223, 233, 'NVT', '44665445897', 'NVT (Politie Bureau)', '|Benno| |CleamenCeau|', 'Nee', '813e3d3bcc767afc14086f728359b92841a7365f', 'NVT', 'veel wietzaadjes', '<p>Piet Grasman:&nbsp;<br /><br />Voormalige collega van de politie is ontslagen wegens het doorgeven van informatie vanuit politie naar de onderwereld. De persoon is op gesprek geweest met |Benno| |Cleamen| en heeft zijn verhaal gedaan. Persoon is na het gesprek ontslagen wegens coruptie en is ook niet meer welkom bij de politie! persoon graag in de gaten houden heeft goed contact met de onderwereld.&nbsp;<br /><br /></p>', 1610111540),
(224, 233, 'nvt', '25170704145', 'NVT', 'Benno', 'Nee', 'ca614797429a951519572287ec6920ddbbdc1d1e', 'nvt', 'x', '<p>Persoon staat op een een drugslocatie met een blauwe svj&nbsp; cuv 512</p>', 1610113260),
(225, 241, 'kleinschalig drugsbezit', '91066285066', 'LifeInvader', 'Ryan', 'Ja', '5915cd48de62bf84857b53287778a49dcd1d097c', 'kleinschalig drugsbezit', '9 zakken met coke', '<p>Meneer stond met een masker, en wapenholster in LifeInvader. Dit vonden wij verdacht, wij hebben hem dus meegenomen, en hij had geen wapens bij, wel wat coke. Hiervoor is hij dus gearresteerd.</p>', 1610117779),
(226, 244, 'Moord op een burger', '44483924833', 'Blokkenpark', 'Djenna', 'Ja', 'e4cc1924d6fb9c63aa8e5931653a1fa2599a2067', 'Moord op een burger', 'X', '<p>meneer heeft van mij 35 weken gekregen voor moor op een burger en openbare geweldpleging.</p>', 1610121556),
(227, 245, 'Voor het mishandelen voor een ambtenaar in functie en het hinderen van een agent in uitvoering.', '12868776283', '2 straten verwijderd van het Politiebureau', 'Ja, een andere collega en dit was Ryan.', 'Ja', 'e19631f09bc522ffeb2a6a5e187298c68b461d05', 'Voor het mishandelen voor een ambtenaar in functie en het hinderen van een agent in uitvoering.', '', '<p>We waren bezig met een aanhouding van een persoon die te hard reed en was gecrashed, hierna kwam meneer bij ons staan en heb ik heb verzocht het gebied te verlaten, dit deed hij maar hij keerde terug. Hierna begon hij mij te slaan en heb ik hem getazerd om hem uiteindelijk aan te houden en mee te nemen naar het bureau.</p>', 1610121649),
(228, 245, 'Het vluchten voor politie, meerdere stopsignalen negeren en rijden met hogere snelheden.', '29669131910', 'Op de weg richting gevangenis.', 'Bij deze aanhouding waren Niels en Ryan betrokken.', 'Ja', 'a42767a3a0edff57312adf6f1b45d68b92277059', 'Het vluchten voor politie, meerdere stopsignalen negeren en rijden met hogere snelheden.', '1 coke', '<p>Jan Perenboom is aangehouden en naar de gevangenis gestuurd omdat hij een voertuig overnam van een andere gearresteerde en hiermee vluchtte voor de politie, we hebben hem hier meerdere stopsignalen voor gegeven. Hierna waren we genodigd hem te tazeren en aan te houden met een celstraf van 35 weken.</p>', 1610124155),
(229, 233, '', '88500292490', 'bureau', 'benno', 'Nee', '941fc25aa1d52e32ffa96241d3451f0d0edd058a', '', '', '<p>persoon heeft mes opzak en mag ten alle tijden gefouilleerd worden</p>', 1610124629),
(230, 241, 'vluchten voor politie, illegaal wapenbezit', '40682721830', 'Snelweg bij casino', 'Ryan', 'Ja', '4388f811b6b481a3af991a0dbd18e5ec7243c9ea', 'vluchten voor politie, illegaal wapenbezit', 'mes', '', 1610124631),
(231, 239, 'Meneer was bij een schotmeldig, hier hebben we hem gefoullieerd en troffen we drugs aan', '21610379020', 'Winkel in sany shores', 'Melvin, Roy, Djenna, Joren, Bean & Nelis', 'Ja', 'ca614797429a951519572287ec6920ddbbdc1d1e', 'Meneer was bij een schotmeldig, hier hebben we hem gefoullieerd en troffen we drugs aan', '60 Wiet zakken en veel contant geld in auto vonden we meer drugs.', '', 1610125455);
INSERT INTO `reports` (`id`, `user`, `incident`, `cad`, `located`, `otherUnits`, `arrested`, `person`, `arrestedFor`, `foundItems`, `whatHappened`, `dateline`) VALUES
(232, 234, '', '16382043367', '', 'Benno', 'Nee', '893fb9db5417a4df6fc7d974763cc5d4137c827d', '', '', '<p>Meneer komt uit eigen initiatief naar de politie met bepaalde informatie over de onderwereld. Informatie bekend bij Benno en Maxim</p>', 1610126859),
(233, 233, 'Medeplichtig op moord en twee maal carthief', '66807476597', 'cardealer', 'nee ', 'Ja', 'a25f8740cffbc3fe7af77cc6c576b14c86a57ab0', 'Medeplichtig op moord en twee maal carthief', 'x', '<p>Heeft nu 90 weken gezeten en volgende keer word het een dubbele straf afgesproken met de advocaten.&nbsp;</p>', 1610130884),
(234, 235, 'vluchten voor politie en rijden in een gestolen voertuig', '4693660329', 'oude anwb', 'Cleamen', 'Ja', 'cc8898894ab6523fabe642ae40b8dacbe3c1a587', 'vluchten voor politie en rijden in een gestolen voertuig', '/', '<p>Hij werd geholpen door een zwarte rs6.</p>', 1610134669),
(235, 245, 'Voor het door rood rijden en vluchten van de politie', '80693757076', 'Bij een autogarage in het zuiden van de stad', 'Bij deze arrestatie waren Jesse, Ryan, Gillas en ik betrokken.', 'Ja', '7966291344fd260d3233b3c7ccc9fa6b6930a17d', 'Voor het door rood rijden en vluchten van de politie', '', '<p>Joeri Knehans is na het door rood rijden gevlucht, wij zijn achter hem aan gereden alleen meneer wilde niet stoppen. Hierna hebben wij hem 1x moeten beuken om hem tot stilstand te krijgen, dit is ons gelukt. Zijn maatje is ervandoor gegaan en Joeri hebben we succesvol kunnen aanhouden. Hiermee heb ik hem ook 30 weken naar de gevangenis gestuurd.</p>', 1610135395),
(236, 241, 'Gijzeling', '65694832350', '!!!!!!Nog niet gearresteerd!!!!!!', '-', 'Nee', '4d8985e09ecc3d7f8b4a30e160083153f4fd49e4', 'Gijzeling', 'onbekend', '<p>Meneer was het contactpersoon bij de gijzeling</p>', 1610137576),
(237, 246, 'vluchten voor politie - roekeloos rijgedrag', '7081279441', 'dicht bij Maaskrant gebouw', 'Ryan', 'Ja', '7966291344fd260d3233b3c7ccc9fa6b6930a17d', 'vluchten voor politie - roekeloos rijgedrag', 'Niks verdacht', '<p>Zwarte kleding, wit met zwarte sneakers, heeft veel openstaande facturen</p>', 1610138165),
(238, 234, 'Illegaal steekwapenbezit', '41796107502', 'Cardealer', 'Benno', 'Ja', 'e4ad21001b75d68f572591dcd8ae6606a3bc79cc', 'Illegaal steekwapenbezit', 'Mes', '<p>Tijdens een melding waarbij 2 politiecollega\'s worden neergeschoten tref ik 1 persoon aan bij de cardealer. Ik fouilleer hem in verband met mogelijke betrokkenheid bij de schietpartij. Meneer had een mes bij zich die in beslag is genomen.</p>', 1610140363),
(239, 236, 'Zware mishandeling agent', '11954528002', 'BP Parking', 'Benno\r\nNick\r\n...', 'Ja', '543a32bd0aa7e3ec12bcd4824a1906332cc20a6a', 'Zware mishandeling agent', '1 opium', '<p>Sloeg mij in elkaar terwijl er een wapen op hem gericht stond, had hem neer kunnen schieten maar toch gekozen om bijna neergeslagen te worden.</p>', 1610144104),
(240, 236, 'Medeplichtig mishandeling + helpen vluchten', '78179812389', 'BP parking', 'Ryan', 'Ja', '772ce9b768a2ca40b15d1308794de1235d146e8d', 'Medeplichtig mishandeling + helpen vluchten', '', '<p>Meneer nam zijn vriend die in de boeien stond mee.</p>', 1610144421),
(241, 245, 'Voor het vluchten van de politie en rijden in een gestolen voertuig.', '4211314917', 'Blokkenpark', 'Ryan was betrokken bij deze aanhouding.', 'Ja', 'eac2237361a2521cc32ec30782792e44f2db57a8', 'Voor het vluchten van de politie en rijden in een gestolen voertuig.', '', '<p>Wij waren aan het surveilleren toen we een scooter tegen kwamen die roekeloos reed, deze hebben we aan de kant proberen te zetten maar dit ging niet soepel. Roy Koekje is daarna tegen een paal gebotst op Blokkenpark en van zijn scooter gevallen, hierna is hij gevlucht van ons en hebben we hem moeten tazeren en aanhouden door hem in de boeien te zetten. Hij is voor 35 weken naar de gevangenis gegaan.</p>', 1610191574),
(242, 245, 'Vluchten voor de politie (meerdere keren) en te hard rijden', '5138753070', 'Blokkenpark', 'Bij deze aanhouding waren Ryan en Niels betrokken.', 'Ja', 'e4ad21001b75d68f572591dcd8ae6606a3bc79cc', 'Vluchten voor de politie (meerdere keren) en te hard rijden', '', '<p>Jan Pan reed eerst met hoge snelheden door rood, wij hebben hem daar op proberen te attenderen maar meneer reed weg. We hebben hierna meerdere malen geprobeerd hem staande te houden zonder succes. Niels ging ons helpen en met zijn drieen hebben we het voor elkaar gekregen hem succesvol aan te houden en naar de gevangenis te sturen voor 40 weken.</p>', 1610193157),
(243, 244, 'Carthief ', '66575455870', 'in de buurt van de legerbasis', 'Bean , Nelis , ryan en ikzelf ', 'Ja', '6e8f42511bda8fe195b8e40f0c1486ce0d4b3552', 'Carthief ', 'X', '<p>meneer deed een carthief reed naar zijn eindbestemming leverde het gestolen voertuig NIET in pakt de boot en reed weg heb hem achtervolgd met een andere boot en heb hem nadien kunnen pakken meneer heeft 25 weken gekregen omdat hij moeilijk deed over bepaalde dingen.</p>', 1610197439),
(244, 235, 'vluchten voor politie en grootschalig drugsbezit ', '83129914333', 'Vliegveld', 'Joren en Nelis', 'Ja', '94c943213ef3250749780cea3b91b2abc4962c04', 'vluchten voor politie en grootschalig drugsbezit ', '210 zakken coke', '<p>Hij rijd in een grijze porsche gt4</p>', 1610199920),
(245, 238, 'medeplichtig aan straf... , vluchten voor politie', '89650905033', 'snelweg THV ikea', 'Djenna, Nick , Maxim', 'Ja', 'a6ed961213301189c4af31e9e22e57433b997c03', 'medeplichtig aan straf... , vluchten voor politie', '', '<p>Deze persoon heeft een auto dief die wij op heterdaad betrapt hebben helpen vluchten voor de politie. DMV zijn lambo (dit is een lambo aangepast voor over de treinsporen te reiden blijkbaar).</p>\r\n<p>meneer heeft 10 weken + geldboeten gekregen voor wat hij gedaan heeft.</p>', 1610271367),
(246, 245, 'Het produceren van wiet en grootschalig drugsbezit.', '85118678609', 'In een havenpand.\r\n', 'Bij deze aanhouding was Niels aanwezig.', 'Ja', 'df38bcd6bbc7dc7d6ac176c1b6df3e5e0ac2071d', 'Het produceren van wiet en grootschalig drugsbezit.', '460 wiet en bronwater', '<p>Wij hebben een wietplantage aangetroffen in een havenpand. Hier troffen wij Thijs Mem aan en hebben we hem aangehouden . Verder is er 460 wiet aangetroffen in zijn auto. En verder stonden er rond de 20 planten wiet in het pand.</p>', 1610285967),
(247, 246, 'vluchten voor politie ', '42264362862', 'Straat rond BP', 'Neen', 'Ja', 'f1e44d736efc516fdb358d1caeacdc1db1359e7d', 'vluchten voor politie ', 'Niks verdacht', '<p>Rijbewijs NIET ingetrokken wegens niet te hoge snelheden en niet al te roekeloos</p>', 1610295094),
(248, 244, 'wapenbezit', '1089595256', 'blokkenpark', 'cleamen,Dako,Djenna en ikzelf ', 'Ja', '9569707b96d6415431bbacb40f8fad07c01dc542', 'wapenbezit', 'heavy pistol ', '<p>meneer reed tegen ons aan stapte uit en had nog een heavy pistol in zn hand en kreeg van mij 30 weken&nbsp;</p>\r\n<p>&nbsp;</p>', 1610305084),
(249, 234, 'Vluchten voor de politie + stelen van een voertuig (carthief)', '46261072483', 'Snelweg net ten zuiden van het ziekenhuis', 'Benno, Nelis, Ryan', 'Ja', 'ea1908f637d250cb99b14f3775b702860ae55f35', 'Vluchten voor de politie + stelen van een voertuig (carthief)', '', '<p>Na een achtervolging van een aantal minuten vloog meneer met zijn oranje sportwagen zeer hard uit de bocht waarop het voertuig meerdere keren over de kop vloog. De bestuurder werd hierbij uit de auto geslingerd en had dringend medische hulp nodig. Agenten belden direct de ambulance en deze was er binnen 1 minuut. Meneer moest zelfs gereanimeerd worden, maar tijdens de reanimatie sprong meneer ineens overeind om bij een vriend van hem in een Lamborghini SVJ te stappen. Nadat een god zich ermee heeft bemoeid is meneer alsnog meegenomen naar het ziekenhuis. Na een medische behandeling in het ziekenhuis is meneer overgebracht naar het politiebureau. Hij kreeg een celstraf van 20 weken en meerdere bekeuringen.</p>', 1610310531),
(250, 244, 'Carthief ', '88959850993', 'naast politiebureau', 'neen', 'Ja', '9192159d0659e24363941e4a5989f6de767a24d0', 'Carthief ', 'X', '<p>meneer had nog 60 weken tegoed die heb ik hem ook gegeven!</p>', 1610311388),
(251, 246, 'Carthief - achterlijk rijgedrag', '16739008643', 'snelweg aan gevangenis richting het Noorden', 'Nelis, Ryan en BÃ©an', 'Ja', '1431ce976eec016e49d9e460993b6c55b4d1a9ab', 'Carthief - achterlijk rijgedrag', 'Niks verdachts', '<p>Rijbewijs NIET ingevorderd (geen gekke acties op de baan verricht)</p>', 1610392009),
(252, 241, 'Medeplichtig aan carthief, vluchten voor politie', '22721203630', 'Brug op de rechter snelweg', 'BeÃ¡n, Gillas, Ryan.', 'Ja', 'f4938ed345b537d66d0ba3be99339066cdefe8a8', 'Medeplichtig aan carthief, vluchten voor politie', 'niks', '', 1610392125),
(253, 241, 'Pakken van illegale goederen, grootschalig drugsbezit.', '15325393356', 'Coke Pluk bij 3 appartementen', 'Heel het korps', 'Ja', '370d2d2dbcd0ba9ef4361929636761dd379b70ea', 'Pakken van illegale goederen, grootschalig drugsbezit.', '94 coke', '<p>Meneer is tijdens een inval aangehouden. Hij bezit een titat waar veel coke in zat. Hij had zelf 94 coke op zak. Meneer heeft een celstraf van 30 weken ontvangen</p>', 1610393712),
(254, 234, '', '3687471812', 'Chihuahua Hotdog-winkel naast Blokkenpark', 'Benno', 'Ja', 'a42767a3a0edff57312adf6f1b45d68b92277059', '', '1 gram opium', '<p>Meneer komt uit zichzelf naar Benno nabij Blokkenpark en meldt dat hij een zakje met een onbekende substantie heeft aangetroffen nabij de normale cardealer. Hij weet niet van wie het is en wat er in zit. Meneer geeft vrijwillig 1 gram opium af waarop het zakje in beslag is genomen. Naam: Vigo Whiteeyes</p>', 1610453221),
(255, 234, 'Mishandeling van een agent', '26251672800', 'Vlakbij politiebureau', 'Benno, Opper', 'Ja', '8fd04bb14ce823e66d6b1b660f33497966a43e2e', 'Mishandeling van een agent', '', '<p>Tijdens een reguliere staandehouding liepen de gemoederen hoog op waarop er agenten in elkaar geslagen werden, onder andere door deze meneer Piet Henkie. De politie was genoodzaakd om gericht te schieten waarbij de heer Patrick Battle helaas is overleden. Meneer Piet is aangehouden en kreeg naast een boete een gevangenisstraf van 20 weken.</p>', 1610457037),
(256, 244, 'Carthief ', '74445490209', 'achter het ambulance gebouw ', 'Djenna , Willy , ryan en ikzelf', 'Ja', 'c4d97fbc46a8bdf6f86945b55385b200b1d01a12', 'Carthief ', '18.500 zwartgeld ', '<p>meneer had er een mooi verhaal rondverzonnen en heb hem 15 weken gegeven.</p>', 1610463828),
(257, 241, 'Vluchten voor politie, kleine hoeveelheid drugs, rijden zonder rijbewijs', '44719632979', 'Vlakbij de Anwb', 'Ryan, Joren, Djenna', 'Ja', '2814e1b2911981a5b679fc6fb6ca3a3684e02222', 'Vluchten voor politie, kleine hoeveelheid drugs, rijden zonder rijbewijs', '1 coke en 19 opium', '<p>Meneer werd staande gehouden en hij en zijn vriend vluchtte weg. Meneer had ook wat drugs bij zich, dat is ingenomen.</p>', 1610466328),
(258, 241, 'Vluchten voor politie Roekeloos rijgedrag.', '63352174500', 'Vlakbij de ANWB', 'Ryan, Joren, Djenna', 'Ja', 'eef9df3d6a7f5a8e9eba2a8a78c67b9c70d8891f', 'Vluchten voor politie Roekeloos rijgedrag.', 'niks', '<p>Meneer vluchtte voor de politie na een staande houding.</p>', 1610466387),
(259, 246, 'Carthief - achterlijk rijgedrag - te hoge snelheden - rijden onder invloed', '65363355416', 'Net op de linker snelweg', 'Piet, Joren, Willy en Marcel De Haan onze streamer/stagair', 'Ja', '05b86fc77ddcf04455d448a15fab27ab67ef76cd', 'Carthief - achterlijk rijgedrag - te hoge snelheden - rijden onder invloed', 'Niks verdachts', '<p>Meneer kon niet rijden en z\'n auto was meteen kapot. Meneer beschouwt auto\'s stelen als zijn manier om geld te verdienen. Verder heeft meneer momenteel 10 000 euro open boetes</p>\r\n<p>&nbsp;</p>', 1610478473),
(260, 244, 'Carthief ', '83964426355', 'sandy shores', 'djenna , bean en ikzelf', 'Ja', 'bdb575948ab624376319ae5f40d49d6039c3888b', 'Carthief ', 'x', '<p>meneer heeft 15 weken gekregen&nbsp;</p>', 1610542892);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `reports_nieuw`
--

CREATE TABLE `reports_nieuw` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `citizenid` varchar(255) NOT NULL,
  `dossier` varchar(255) NOT NULL,
  `report` text NOT NULL,
  `laws` text,
  `created` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `reports_nieuw`
--

INSERT INTO `reports_nieuw` (`id`, `title`, `author`, `citizenid`, `dossier`, `report`, `laws`, `created`) VALUES
(20, 'Moker snel messentrekkert', ' ', '6013279a8420d831c9cc7381c560ac33c3cc65cc', '23292815113', '<p class=\"\"><br />\r\n        <center><br />\r\n            <img src=\"https://i.imgur.com/sziaD4u.png\" style=\"width: 25%;\"><br />\r\n            <h1>Procesverbaal</h1><br />\r\n            <h2>Aangifte</h2><br />\r\n        </center><br />\r\n        <b>EENHEID LOS SANTOS</b><br><br />\r\n        <b>DISTRICT TAKKA</b><br><br />\r\n        <b>BASISTEAM MISSION ROW</b><br><br><br />\r\n        <p>Proces-verbaalnummer:&nbsp;23292815113</p><br><br />\r\n<br />\r\n        <p>Feit:</p><br />\r\n        <p>Plaatsdelict:</p><br />\r\n        <p>Pleegdatum/tijd:</p><br />\r\n<br />\r\n        <br><br />\r\n<br />\r\n        <p>Ik, verbalisant,  , Aspirant van Politie Eenheid Los Santos, verklaar het volgende.</p><br><br />\r\n<br />\r\n        <p>Op 21-1-2021, 22:42 ,  verscheen voor mij, in het politiebureau, Mission Row, Sinner Street, Los Santos, een persoon, de aangever die mij opgaf te zijn: </p><br />\r\n<br />\r\n        <p>Achternaam: </p><br />\r\n        <p>Voornamen: </p><br />\r\n        <p>Geboren: </p><br />\r\n        <p>Geboorteplaats: </p><br />\r\n        <p>Geslacht: </p><br />\r\n        <p>Nationaliteit: </p><br />\r\n        <p>Adres: </p><br><br />\r\n<br />\r\n        <p>Hij/Zij deed aangifte en verklaarde het volgende over het in de aanhef vermelde incident, dat plaatsvond op de locatie genoemd bij plaats delict, op de genoemde pleegdatum/tijd.</p><br><br />\r\n<br />\r\n        <p><b>BEVINDINGEN</b></p><br><br />\r\n        <p>Aan niemand werd het recht of de toestemming geven tot het plegen van dit feit.</p><br><br />\r\n        <p>De verbalisant,</p><br><br />\r\n        <p>Naam</p><br><br />\r\n        <p>Ik, NAAM AANGEVER, verklaar dat ik dit proces-verbaal heb gelezen. Ik verklaar dat ik de waarheid heb verteld. Ik verklaar dat mijn verhaal goed is weergegeven in het proces-verbaal. Ik weet dat het doen van een valse aangifte strafbaar is.</p><br><br />\r\n        <p>De aangever,</p><br><br />\r\n        <p>NAAM AANGEVER</p><br><br />\r\n        <p>Eventuele opmerkingen verbalisant</p><br />\r\n        <p>Waarvan door mij is opgemaakt dit proces-verbaal, dat ik sloot en ondertekende te Los Santos op 21-1-2021, 22:42 </p><br><br />\r\n        <p><b> </b></p><br />\r\n    </p>', '2021', 1611265386),
(21, 'Dit is sjors', ' ', '1ecb185390cfed3e7f8700c7061660bcb2861039', '39950891119', '<p>dfgdfdfg</p>', '2021', 1611309868),
(22, 'sdfsdf', ' ', '7fca54b8d1a4e6a488fd3e7b39eac95dd677bd0e', '47422056988', '<p>sfsdfsdfsdf</p>', '2021', 1611336858),
(23, '3MulO53R An3Ra 7.3.0', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '80151490986', '<p>sfsdfsdfs dfg asdaf&nbsp;</p>', '2021', 1611336862),
(24, 'MaaslandRP-Meos', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '51222250063', '<p>sdfasdf</p>', '2021', 1611336865),
(25, 'meos', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '9740733832', '<p>sdfsdfsdf</p>', '2021', 1611336870),
(26, 'asfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '72226826747', '<p>asdfasdfasf saf asdf asd fas</p>', '2021', 1611336873),
(27, 'asdf asdf as', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '76645652455', '<p>df asdf asdfasdf</p>', '2021', 1611336876),
(28, 'asdfasdf as ', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '74165785662', '<p>asdf asd&nbsp; asd</p>', '2021', 1611336879),
(29, 'gfd dfg d', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '56234087329', '<p>asdfasdfas fdsa fsad&nbsp; ds</p>', '2021', 1611336887),
(30, 'fdg sdfg', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '49436862766', '<p>dfg sdfg</p>', '2021', 1611336889),
(31, ' dfsg', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '108676433', '<p>dfg sd fg</p>', '2021', 1611336892),
(32, 'sdfgsdfg ', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '48166612010', '<p>sdfgsdfg</p>', '2021', 1611336894),
(33, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '14787939264', '<p>asdfasdf</p>', '2021', 1611336901),
(34, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '6075494308', '<p>sadfasdf<br></p>', '2021', 1611336903),
(35, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '56957850909', '<p>sadfasdf<br></p>', '2021', 1611336904),
(36, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '36830424593', '<p>sadfasdf<br></p>', '2021', 1611336906),
(37, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '27391988959', '<p>sadfasdf<br></p>', '2021', 1611336907),
(38, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '19808560316', '<p>sadfasdf<br></p>', '2021', 1611336909),
(39, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '89901914408', '<p>sadfasdf<br></p>', '2021', 1611336917),
(40, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '9977311743', '<p>sadfasdf<br></p>', '2021', 1611336918),
(41, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '42211394931', '<p>sadfasdf<br></p>', '2021', 1611336920),
(42, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '10410886723', '<p>sadfasdf<br></p>', '2021', 1611336922),
(43, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '53554933244', '<p>sadfasdf<br></p>', '2021', 1611336923),
(44, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '70897497003', '<p>sadfasdf<br></p>', '2021', 1611336924),
(45, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '34565007244', '<p>sadfasdf<br></p>', '2021', 1611336970),
(46, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '30222482122', '<p>sadfasdf<br></p>', '2021', 1611336971),
(47, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '16710440592', '<p>sadfasdf<br></p>', '2021', 1611336973),
(48, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(49, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '48560542663', '<p>sadfasdf<br></p>', '2021', 1611336976),
(50, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '8887275528', '<p>sadfasdf<br></p>', '2021', 1611336977),
(51, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(52, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(53, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(54, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(55, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(56, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(57, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(58, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(59, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(60, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(61, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(62, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(63, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(64, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(65, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(66, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(67, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(68, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(69, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(70, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(71, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(72, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(73, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(74, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(75, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(76, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(77, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(78, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(79, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(80, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(81, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(82, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(83, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(84, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(85, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(86, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(87, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(88, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(89, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(90, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(91, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(92, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(93, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(94, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(95, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(96, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(97, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(98, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(99, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(100, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(101, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(102, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(103, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(104, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(105, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(106, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(107, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(108, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(109, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(110, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(111, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(112, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(113, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(114, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(115, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(116, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(117, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(118, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(119, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(120, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(121, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(122, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(123, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(124, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(125, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(126, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(127, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(128, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(129, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(130, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(131, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(132, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(133, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(134, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(135, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(136, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(137, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(138, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(139, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(140, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(141, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(142, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(143, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(144, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(145, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(146, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(147, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(148, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(149, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(150, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(151, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(152, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(153, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(154, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(155, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(156, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(157, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(158, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(159, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(160, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(161, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(162, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(163, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(164, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(165, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(166, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(167, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(168, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(169, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(170, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(171, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(172, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(173, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(174, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(175, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(176, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(177, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(178, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(179, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(180, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(181, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(182, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(183, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(184, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(185, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(186, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(187, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(188, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(189, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(190, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(191, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(192, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(193, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(194, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(195, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(196, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(197, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(198, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(199, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(200, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(201, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(202, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(203, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(204, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(205, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(206, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(207, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(208, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(209, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(210, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(211, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(212, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(213, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(214, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(215, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(216, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(217, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(218, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(219, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(220, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(221, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(222, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(223, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(224, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(225, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(226, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(227, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(228, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(229, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(230, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(231, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(232, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(233, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(234, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(235, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(236, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(237, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(238, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(239, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(240, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(241, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(242, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(243, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(244, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(245, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(246, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(247, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(248, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(249, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(250, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(251, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(252, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(253, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(254, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(255, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(256, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(257, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(258, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(259, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(260, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(261, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(262, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(263, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(264, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(265, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(266, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(267, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(268, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(269, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(270, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(271, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(272, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(273, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(274, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(275, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(276, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(277, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(278, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(279, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(280, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(281, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(282, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(283, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(284, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(285, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(286, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(287, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(288, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(289, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(290, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(291, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(292, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(293, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(294, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(295, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(296, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(297, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(298, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(299, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(300, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(301, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(302, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(303, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(304, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(305, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(306, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(307, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(308, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(309, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(310, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(311, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(312, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(313, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(314, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(315, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(316, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(317, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(318, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(319, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(320, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(321, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(322, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(323, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(324, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(325, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(326, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(327, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(328, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(329, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(330, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(331, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(332, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(333, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(334, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(335, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(336, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(337, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(338, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(339, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(340, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(341, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(342, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(343, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(344, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(345, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(346, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(347, 'sadfasdf', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '20767348110', '<p>sadfasdf<br></p>', '2021', 1611336974),
(348, 'Overval', ' ', '15b5e389b53f936a9b95c2c713d8b77fa3daded4', '27015939020', '<p>.</p><p><br></p>', '2021', 1611677477);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `settings`
--

CREATE TABLE `settings` (
  `sid` mediumint(9) NOT NULL DEFAULT '1',
  `user_db` mediumtext NOT NULL,
  `search_prefix` mediumtext NOT NULL,
  `owned_vehicles_db` mediumtext NOT NULL,
  `vehicles_db` mediumtext NOT NULL,
  `plate_row` varchar(50) NOT NULL,
  `licenses_db` mediumtext NOT NULL,
  `license_db` mediumtext NOT NULL,
  `bills_db` mediumtext NOT NULL,
  `billing` mediumtext NOT NULL,
  `banlijst` mediumtext NOT NULL,
  `shops` tinytext NOT NULL,
  `owned_shops` mediumtext NOT NULL,
  `jobs_db` varchar(255) NOT NULL,
  `jobs_grades_db` varchar(255) NOT NULL,
  `table_money` varchar(50) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `addon_account_data_db` varchar(255) NOT NULL,
  `css_header_color` mediumtext NOT NULL,
  `css_logo_color` mediumtext NOT NULL,
  `discord_db` mediumtext NOT NULL,
  `steamname_db` mediumtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `settings`
--

INSERT INTO `settings` (`sid`, `user_db`, `search_prefix`, `owned_vehicles_db`, `vehicles_db`, `plate_row`, `licenses_db`, `license_db`, `bills_db`, `billing`, `banlijst`, `shops`, `owned_shops`, `jobs_db`, `jobs_grades_db`, `table_money`, `firstname`, `lastname`, `addon_account_data_db`, `css_header_color`, `css_logo_color`, `discord_db`, `steamname_db`) VALUES
(1, 'users', 'identifier', 'owned_vehicles', 'vehicles', 'plate', 'user_licenses', 'licenses', 'fine_types', 'billing', 'ea_bans', 'true', 'owned_shops', 'jobs', 'job_grades', 'money', 'firstname', 'lastname', 'addon_account_data', '#b31e1e', '', 'discord', 'name');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `sollicitaties`
--

CREATE TABLE `sollicitaties` (
  `id` int(11) NOT NULL,
  `discordid` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `dob` varchar(50) NOT NULL,
  `job` varchar(255) NOT NULL,
  `daysonline` int(10) NOT NULL,
  `motivation` text NOT NULL,
  `dateline` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `sollicitaties`
--

INSERT INTO `sollicitaties` (`id`, `discordid`, `email`, `dob`, `job`, `daysonline`, `motivation`, `dateline`) VALUES
(5, '712264941918224424', 'bart@meos.store', '16-02-2021', 'ambulance', 3, 'Hier is mijn motivatie', 1610884043),
(6, '712264941918224424', 'wer', '22-02-0222', 'police', 2, 'sdfsdfsdf', 1610884556),
(7, '539877816259313674', '', '01-01-1970', 'police', 0, '', 1611327002),
(8, '199574133879734272', '', '01-01-1970', 'police', 0, '', 1611432824),
(9, '175655791750152196', '', '01-01-1970', 'police', 0, '', 1611439567),
(10, '536964409239535627', 'amineabou1467@gmail.com', '01-09-2005', 'police', 6, '<p><span id=\"docs-internal-guid-36817e69-7fff-22b5-5d5e-1fea8f1c3a3d\"><span style=\"font-size: 11pt; font-family: Arial; color: rgb(0, 0, 0); background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;\">Ik ben er altijd. Ik sta altijd klaar voor iedereen. Ik zal alle inspiratie vanuit mij zelf naar buiten halen. Ik ken de kennis van de baan politie al veel. Ik kijk altijd mee in de leven van een agent. Ik ben altijd voorbereid geweest om dit te doen.</span></span><br></p>', 1611587743),
(11, '480717043205668864', '', '01-01-1970', 'police', 0, '', 1611664016),
(12, '480717043205668864', '', '01-01-1970', 'mechanic', 0, '', 1611665244);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `tuning`
--

CREATE TABLE `tuning` (
  `id` bigint(20) NOT NULL,
  `kenteken` varchar(255) NOT NULL,
  `werk` longtext NOT NULL,
  `door` mediumtext NOT NULL,
  `kosten` mediumtext NOT NULL,
  `dateline` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `tuning`
--

INSERT INTO `tuning` (`id`, `kenteken`, `werk`, `door`, `kosten`, `dateline`) VALUES
(22, 'AGP 302', 'TEST WERKZAAMHEDEN', 'Tester', '9000', 1559937651),
(23, 'QQP 819', 'band verwisselt ', 'Alexander', '100', 1560006417),
(24, 'QQP 819', 'band verwisselt ', 'Alexander', '100', 1560006451),
(25, 'QQP 819', 'band verwisselt ', 'Alexander', '100', 1560019546),
(26, 'ERK 438', 'Audi rs6 moter 4 erin en turbo erin gedaan', 'Alexander', '70000', 1560019624),
(27, 'ERK 438', 'Audi rs6 moter 4 erin en turbo erin gedaan', 'Alexander', '70000', 1560019736),
(28, 'YKS 272', 'Motor 2 erin gezet en een kentekenplaatje veranderd ', 'Alexander', '10550', 1560020065),
(29, 'YKS 272', 'Motor 2 erin gezet en een kentekenplaatje veranderd ', 'Alexander', '10550', 1560020148),
(30, 'YKS 272', 'Motor 2 erin gezet en een kentekenplaatje veranderd ', 'Alexander', '10550', 1560020256),
(31, 'YKS 272', 'Motor 2 erin gezet en een kentekenplaatje veranderd ', 'Alexander', '10550', 1560020286),
(32, 'FAJ 924', 'Kleur aangepast naar matte zwart ', 'Alexander', '1330', 1560027989),
(33, 'EMB 225', 'Kleur 500 en repareren 100 \r\n', 'Wesley', '600', 1560040030),
(34, 'WTV 249', 'Mercedes benz g65 tier 3 \r\nmoter+1,suspe+1,remmen+1,turbo,trans+1\r\nneonlicht en kleur', 'Wesley', '87000', 1560043047),
(35, 'WPG 025', 'kleur matte grijs', 'Wesley', '500', 1560044186),
(36, 'WPG 025', 'velgen matte zwart ', 'Wesley', '350', 1560044539),
(37, 'GJG 257', 'wielen/paint bijde kleuren/ dak/skirts/voor +achterbumper/motorkap/uitaat/kuipstoelen ', 'Dries', '14900', 1560089985),
(38, 'YHK 110', 'SHIRTS', 'Dries', '600', 1560093355),
(39, 'YHK 110', 'TOETER ', 'Dries', '400', 1560093464),
(40, 'GJG 257', 'turbo ', 'Dries', '20000', 1560097225),
(41, 'FST 290', 'reperatie', 'Dries', '100', 1560123270),
(42, 'RIR 117', 'full tuning geen armer ', 'Dries', '57000', 1560123428),
(43, 'FAJ 924', 'Nieuwe velgen en banden. ', 'Alexander', '2000', 1560124291),
(44, 'BIN 876', 'even fixen', 'Alexander', '100', 1560124452),
(45, 'FST 290', 'verlagen/ turbo', 'Dries', '55000', 1560182078),
(46, 'IXU 705', 'opel corsa kleur aangepast ', 'Alexander', '800', 1560202621),
(47, 'AZN 756', 'M - Benz ramen gedaan', 'Alexander', '750', 1560209617),
(48, 'TCA 710', 'coke meuk', 'Alexander', '2000', 1560213386),
(49, 'LLR 926', 'full tuning /body kit ', 'Dries', '150000', 1560214480),
(50, 'NTP 412', 'full tunt zonder armer', 'Dries', '57000', 1560268830),
(51, 'LPK 952', 'turbo', 'Dries', '20000', 1560269143),
(52, 'BRV 572', 'transmissi full en remmen full', 'Dries', '19000', 1560288018);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `vois`
--

CREATE TABLE `vois` (
  `id` bigint(20) NOT NULL,
  `vehicle_id` varchar(225) NOT NULL,
  `image` mediumtext NOT NULL,
  `reason` mediumtext NOT NULL,
  `notes` mediumtext NOT NULL,
  `look` mediumtext NOT NULL,
  `dateline` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `vois`
--

INSERT INTO `vois` (`id`, `vehicle_id`, `image`, `reason`, `notes`, `look`, `dateline`) VALUES
(156, 'NEK 731', '', 'Voertuig gezien op verdachte locatie \'opium pluk\'', '', '', 1608385032),
(158, 'JBH 002', '', 'Voertuig gezien op verdachte locatie \'opium pluk\'', '', '', 1608385055),
(160, 'KXZ 716', '', 'Voertuig gezien op verdachte locatie \'opium pluk\'', '', '', 1608385083),
(163, 'OUY 708', '', 'Voertuig gezien op verdachte locatie \'opium pluk\'', '', '', 1608385110),
(164, 'WRN 486', '', 'Voertuig gezien op verdachte locatie \'opium pluk\'', '', '', 1608385121),
(165, 'PKK 821', '', 'Voertuig gezien op verdachte locatie \'opium pluk\'', '', '', 1608385133),
(166, 'LGM 945', '', 'Voertuig gezien op verdachte locatie \'coke verpak\'', '', '', 1608385160),
(168, 'SPI 056', '', 'Gijzelen van een burger', 'Vuurwapen gevaarlijk', 'Goude lamborghini SVJ', 1608417566),
(171, 'MKD 885', '', 'Voertuig kapot aangetroffen (niet op slot) met wat coke in de kofferbak', '', 'Blauwe Audi', 1608569056),
(174, 'RDX 924', '', 'Voertuig meerdere keren gezien op drugs locaties', '', 'Rode Nissan Titan met dollar tekens in zijn velg', 1608890592),
(175, 'ZJV 459', '', 'Voertuig op 25-12 om 11:00 uur gezien op locatie \'wiet verpak\'', '', '', 1608890617),
(176, 'BSL 598', '', 'Voertuig op 25-12 om 11:00 uur gezien op locatie \'wiet verpak\'', '', '', 1608890626),
(177, 'JJP 430', '', 'Voertuig op 25-12 om 11:00 uur gezien op locatie \'wiet verpak\'', '', '', 1608890635),
(179, 'QQQ 959', '', 'Voertuig rijdt zeer hard door de stad, roekeloos rijgedrag', 'Boetes uitgeschreven via MEOS. Observatie door de politiehelikopter (Benno)', 'Mercedes AMG', 1608891103),
(180, 'XNV 176', '', 'Voertuig rijdt zeer hard door de stad, roekeloos rijgedrag', 'Boetes uitgeschreven via MEOS. Observatie door de politiehelikopter (Benno)', 'Lage (mogelijk groene) sportwagen', 1608891131),
(181, 'WQP 103', '', 'Betrokken bij overval op Tequila-la', 'Op naam van Vis Slender', 'Zwart/gouden Lamborghini SVJ', 1609069363),
(182, 'SHB 464', '', 'Grote hoeveelheid drugs in deze auto aangetroffen', 'Op naam van Bas Woods', 'Zwarte Opel Corsa', 1609101253),
(183, 'VGN 517', '', 'Vluchten voor de politie', 'Reed weg, negeren van stopteken.', 'Blauwe bentley met zwarte spoiler', 1609152790),
(185, 'XII 199', '', 'Gezien op verdachte locatie, vluchten voor politie en 3 wapens op hem gericht.', 'Op naam van Sergio El Cassa', 'Grijze lamborghini', 1609270536),
(186, 'RHQ 824', '', 'Voertuig gespot op een drugs locatie \'opium verkoop\'', 'Persoon stond samen met 2 anderen', 'Zwarte Mercedes G63 AMG', 1609540309),
(187, 'JJX 428', '', '70 bundels met opium in voertuig', 'n.v.t.', 'zwart/donker grijze SVJ', 1609698675),
(188, 'QRA 539', '', 'vluchten voor politie', '', 'Grijs bruine lambo SVJ', 1609704607),
(189, 'FUZ 157', '', 'Persoon komt op het bureau aangifte doen. De bestuurder van dit voertuig zou hem hebben bedreigd met een vuurwapen.', 'Mogelijk vuurwapengevaarlijk. Aangifte gedaan door dhr. Roy Makkers', 'Grijze Audi R8', 1609857400),
(190, 'XII 199', '', 'Betrokken bij overval Yellowjack', '', 'Grijze lamborghini', 1609858366),
(191, 'MBA 570', '', 'Voertuig aangetroffen op verdachte locatie \'wiet verkoop\' ', '', 'Tesla Model S', 1609875995),
(193, 'JJV 200', '', 'Burger maakt een melding dat de persoon in dit voertuig iemand heeft neergestoken', 'Mogelijk vuurwapengevaarlijk', '', 1609931557),
(194, 'OMD 098', '', 'Medeplichtig bij overval Lifeinvader', 'Op de naam van Roger Jos', 'Grijze auto ', 1610006731),
(195, 'ONO 387', '', 'Betrokken overval oud politiebureau', 'Op de naam van Kobe Festa', '', 1610006909),
(196, 'SJK 150', '', 'Betrokken overval oud politiebureau', 'Op de naam van Henki Sender', '', 1610006957),
(197, 'KBI 955', '', 'Betrokken overval oud politiebureau', 'Op de naam van Sjaak de Sinterklaas', 'Zwarte Range Rover', 1610007041),
(198, 'XDN 408', '', 'Betrokken overval oud politiebureau', 'Op de naam van Jaap de Kikker', 'Zwarte Range Rover', 1610007091),
(199, 'XDN 408', '', 'Betrokken overval oud politiebureau', 'Op de naam van Jaap de Kikker', 'Zwarte Range Rover', 1610007093),
(200, 'HMG 598', '', 'Betrokken overval oud politiebureau', 'Op de naam van Roger Jos', 'Grijze lamborghini SVJ', 1610007170),
(201, 'MEE 732', '', 'Betrokken overval oud politiebureau', 'Op de naam van Young Soldier Jurro', 'Zwart voertuig', 1610007201),
(202, 'XII 199', '', 'Betrokken overval oud politiebureau', 'Op de naam van Sergio Pecasso', 'Grijze lamborghini SVJ', 1610007225),
(203, 'XII 199', '', 'Betrokken overval oud politiebureau', 'Op de naam van Sergio Pecasso', 'Grijze lamborghini SVJ', 1610007227),
(204, 'VIM 796', '', 'Betrokken bij overval Lifeinvader', 'Op de naam van XXXXX TENTACION', 'Rood zwarte Ferrari Pista', 1610007322),
(205, 'MEE 732', '', 'Betrokken bij overval Lifeinvader', 'Op de naam van Jurro is Young Soldier', 'Zwart voertuig', 1610007361),
(206, 'HZZ 230', '', 'Gezien op een drugslocatie', 'Oud collega ', 'Zwarte rs7', 1610113638),
(208, 'TQL 171', '', 'Gezien op een drugslocatie', 'gezien op coke pluk', 'lamborghini licht zwart', 1610113756),
(209, 'OWA 053', '', 'Gezien op een drugslocatie', 'gezien op coke pluk', 'blauwe sportwagen', 1610113789),
(210, 'SKG 332', '', 'Gezien op een drugslocatie', 'gezien op coke pluk', 'grijse a6 ', 1610113860),
(211, 'UHV 402', '', 'Gezien op een drugslocatie', 'gezien op coke verkoop', 'zwarte g65 amg ', 1610113918),
(212, 'PDI 434', '', 'Gezien op een drugslocatie', 'gezien op coke verkoop', '4 persoons wagen ', 1610113955),
(213, 'RNA 547', '', 'Medeplichtig aan een carthief', 'Is heel snel', 'Blauwe audi R8', 1610126906),
(215, 'IQB 545', '', 'Voertuig gezien op verdachte locatie \'coke pluk\'', '', 'Groene Citroen Berlingo', 1610275813),
(216, 'GUN 339', '', 'Voertuig gezien op verdachte locatie \'coke pluk\'', '', 'Grijze BMW', 1610275830),
(217, 'ZEA 286', '', 'Voertuig gezien op verdachte locatie \'coke pluk\'', '', 'Rode Audi RS6', 1610276104),
(218, 'QRM 549', '', 'Voertuig gezien op verdachte locatie \'coke pluk\'', '', 'Mercedes / Schafter', 1610276125),
(219, 'ECJ 127', '', 'Voertuig gezien op verdachte locatie \'coke pluk\'', '', 'Rode Porsche', 1610276143),
(220, 'ZZV 484', '', 'Voertuig gezien op verdachte locatie \'coke pluk\'', '', 'Donkerblauwe Mercedes AMG', 1610276166),
(221, 'LPS 151', '', 'Motorfiets rijdt zonder kenteken rond', '', 'Blauwe Yamaha R6', 1610478290),
(222, '2FAT4YOU', '', 'Test', 'Niks', 'Geel', 1610685882),
(223, '2FAT4YOU', '', 'testtt', 'jajajaja', 'rood', 1610834526),
(224, '2FAT4YOU', '', 'adsad', 'sdasdadsd', 'adsads', 1610904860),
(225, 'ADT 052', '', 'Rijden door de menigte', 'Geeft geen aanleiding tot stoppen.', 'Zwart', 1610969944);

--
-- Indexen voor geëxporteerde tabellen
--

--
-- Indexen voor tabel `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`logid`);

--
-- Indexen voor tabel `pois`
--
ALTER TABLE `pois`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `reports`
--
ALTER TABLE `reports`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `reports_nieuw`
--
ALTER TABLE `reports_nieuw`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexen voor tabel `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`sid`);

--
-- Indexen voor tabel `sollicitaties`
--
ALTER TABLE `sollicitaties`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `tuning`
--
ALTER TABLE `tuning`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `vois`
--
ALTER TABLE `vois`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT voor geëxporteerde tabellen
--

--
-- AUTO_INCREMENT voor een tabel `logs`
--
ALTER TABLE `logs`
  MODIFY `logid` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT voor een tabel `pois`
--
ALTER TABLE `pois`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=206;

--
-- AUTO_INCREMENT voor een tabel `reports`
--
ALTER TABLE `reports`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=261;

--
-- AUTO_INCREMENT voor een tabel `reports_nieuw`
--
ALTER TABLE `reports_nieuw`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=349;

--
-- AUTO_INCREMENT voor een tabel `sollicitaties`
--
ALTER TABLE `sollicitaties`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT voor een tabel `tuning`
--
ALTER TABLE `tuning`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT voor een tabel `vois`
--
ALTER TABLE `vois`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=226;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
