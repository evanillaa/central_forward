-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Gegenereerd op: 11 feb 2021 om 10:54
-- Serverversie: 5.7.31
-- PHP-versie: 7.4.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `meosshop_work`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `pois`
--

CREATE TABLE `pois` (
  `id` bigint(20) NOT NULL,
  `civ_id` varchar(255) NOT NULL,
  `image` mediumtext NOT NULL,
  `reason` mediumtext NOT NULL,
  `notes` mediumtext NOT NULL,
  `dateline` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `pois`
--

INSERT INTO `pois` (`id`, `civ_id`, `image`, `reason`, `notes`, `dateline`) VALUES
(145, 'b9f6f32ed2e3067f2945df5c0a858a935078756c', '', 'Vluchten voor de politie', 'Reed in groene porsche weg', 1608300451),
(146, '2ad59a21e18af6fc073bc435ab232164cab0a309', '', 'Vluchten voor de politie', 'A6 (mat zwart) kenteken: SFA 331', 1608301647),
(148, '3ab14b3583a41077a5b7bb9cb180d2340a7b0bb8', '', 'vluchten politie/achterlijk r gedrag', 'persoon negeert ale soorten vorderingen van de politie ', 1608382001),
(149, '1772c75a1b350140f4c950f131b3c6c08a9edc6b', '', 'Vluchten voor politie + verkeersovertredingen', 'Combatlog', 1608498371),
(152, 'ff7534df1fe781809a6cf0f5a3f586bb41978a52', '', 'Vluchten voor de politie', 'Je mag hem 20 weken celstraf geven/ rijdt in een rode ferari', 1608569923),
(154, 'b9f6f32ed2e3067f2945df5c0a858a935078756c', '', 'Schieten naast agent + vluchten politie', 'Zat in een zwarte G-klasse', 1608645167),
(156, '509e5882442a023bd69ef7c83970a3ccefb6835a', '', 'mogelijk slagwapen gevaarlijk', 'rijdt in een witte mercedes', 1608729959),
(157, '960dfef0120d1adb68e9c3b46443d6be5ca8b8cb', '', 'Krijgt nog 50 weken voor wapenbezit (mes) en vluchten voor politie', 'Meneer heeft snel /chardel gedaan om een andere naam/uiterlijk te krijgen zodat hij kon ontkomen. Hij mag (ongeacht hoe hij op dit moment heet) alsnog voor 50 weken zitten.', 1608753147),
(159, 'f52fcdbeb66345c9c4a39aeea757fcf5b510980c', '', 'Meneer staat met zijn Nissan Titan op een drugslocatie en draagt een wapenholster aan zijn riem met daarin een op een vuurwapen gelijkend voorwerp', 'Mogelijk vuurwapengevaarlijk', 1608892292),
(160, 'a42767a3a0edff57312adf6f1b45d68b92277059', '', 'betrokken bij schoten en inbraak op HB', 'Wees alert op communicatie afnemen het is mogelijk een groep mensen ', 1608898258),
(161, '1295fdfefd9289bdd2d0b004ecf154befaafedb6', '', 'Geeft drugs aan de ambu', '122opium', 1608908747),
(163, 'b9f6f32ed2e3067f2945df5c0a858a935078756c', '', 'Word verdacht van het verkopen van wiet zakken', '-', 1608994466),
(164, '78d8d1d1b283f7a9574fc49cdc4dfe215398ed8c', '', 'Medeplichtig aan gijzelen van collega en overval op bar.', '-', 1608994719),
(165, '235127453aacd075f7f0435b524e36d67c8b2c77', '', 'Medeplichtig aan gijzelen van collega en overval op bar.', '-', 1608994732),
(166, 'ad8c51f579efe2460da3414e5ed9e5e5ea84be24', '', 'Medeplichtig aan gijzelen van collega en overval op bar.', '-', 1608994752),
(167, '1aa9028baa2b87bcc3174b56dfd156982dc02d44', '', '189 opium in wagen aangetroffen', 'RS6 rood', 1609089634),
(168, '296f66e26b2904b4b339198f8bcf9aec751bc056', '', 'Overval op de tequila bar', 'Gewapende overval met 2 gijzelaars.', 1609110995),
(169, '79aa5a7a47e5f75c0202f81921fe8d72141a8f10', '', 'Overval op de tequila bar', 'Gewapende overval met 2 gijzelaars.', 1609111010),
(170, 'ff9a7e870bd2bcebef05fc09ef7eee8958560cae', '', 'Betrapt op het gijzelen van een persoon met een aantal andere.', '-', 1609193472),
(171, '9e6a4228d141ad85da08fa6fde1d1293bcd9c2e1', '', 'Fabriceren van illegaal waar', 'stond op opium pluk locatie', 1609200336),
(172, '5b0bc9550c305b53d0875ec0039c840b8fcecb35', '', 'Auto  bevat grote hoeveelheid drugs', '', 1609249882),
(173, '235127453aacd075f7f0435b524e36d67c8b2c77', '', 'Gemaskerde man, mogelijk betrokken bij vuurgevecht. Mogelijk vuurwapen gevaarlijk. Medeplichtig bij overval.', 'Zwarte Lamborghini OZW 304', 1609257852),
(174, '66b18c91f3131503fa592866636a4487edad504b', '', 'Ontplofte auto aangetroffen op wiet verkoop locatie', 'Niks in auto aangetroffen ', 1609281243),
(175, 'a3fe13b82c75c892f5e31706a6dc895cb63e9c75', '', 'Voertuig aangetroffen bij een overval', 'Het gaat om zijn enige voertuig.', 1609332794),
(176, '2814e1b2911981a5b679fc6fb6ca3a3684e02222', '', 'Auto bevat grote hoeveelheid drugs', 'kenteken REV 925', 1609337990),
(177, '960dfef0120d1adb68e9c3b46443d6be5ca8b8cb', '', 'Meneer zou met zijn gele Lamborghini een persoon (Mike Oxmaul) hebben aangereden en vervolgens zijn gevlucht.', 'Meneer Spetter heeft aangifte gedaan wegens zware mishandeling cq. poging tot doodslag.', 1609365349),
(178, '4d8985e09ecc3d7f8b4a30e160083153f4fd49e4', '', 'Meneer is betrokken bij een carthief', 'Rijdt ondanks waarschuwingsschoten gewoon door', 1609526538),
(180, '828d19703870ebfefbed6939b5d36527f21f175d', '', 'Medeplichtig aan ov', '', 1609622684),
(181, 'b9f6f32ed2e3067f2945df5c0a858a935078756c', '', 'Medeplichtig aan overval', '', 1609623657),
(182, 'e19631f09bc522ffeb2a6a5e187298c68b461d05', '', 'Zijn voertuig (SVJ) wordt aangetroffen op coke pluk met 364 coke erin', '', 1609792118),
(183, '0cb72f25a1703dc974256a780d8470d7fbe13988', '', 'Is betrokken geweest bij een incident met een knuppel', 'Mag gefouilleerd worden ivm mogelijk slagwapenbezit (knuppel)', 1609792646),
(187, '7b01b6ae89d5ed03ce91e6005c3475723d10f5d6', '', 'Lag dood langs de snelweg met een knuppel.. ', 'knuppel is niet ingenomen want we mogen niet doden af foullieren. Toen is hij na 1 minuut uitgelogd...', 1610048656),
(188, '543a32bd0aa7e3ec12bcd4824a1906332cc20a6a', '', 'Rijbewijs B van deze meneer (Hamzaa Looh) mag ingevorderd worden. Snelheid, achtelijk rijgedrag. Observatie vanuit de heli', 'Boetes heeft meneer al gekregen.', 1610105907),
(189, 'd0f0cfad363f5a2a56ae9dbd9dfa7cf2579f963c', '', 'Vluchten voor de politie, roekeloos rijgedrag', 'Meneer na een achtervolging ontkomen. Boetes via MEOS geschreven en rijbewijs ingevorderd.', 1610106324),
(190, '941fc25aa1d52e32ffa96241d3451f0d0edd058a', '', 'Persoon probeert iemand te ontvoeren met een mes / klapmes', 'Aangifte gedaan door collega Jesse', 1610117681),
(191, '828d19703870ebfefbed6939b5d36527f21f175d', '', 'Word verdacht van het verkopen van Wiet', '', 1610141303),
(192, 'b9f6f32ed2e3067f2945df5c0a858a935078756c', '', 'Word verdacht van het verkopen van Wiet', '', 1610141350),
(195, 'e19631f09bc522ffeb2a6a5e187298c68b461d05', '', 'Mogelijk betrokken bij een gewapende overval op de LifeInvader', '', 1610193736),
(196, '2f40c8206c52f0cd1a67e377666a340db9f7a1b5', '', 'Poging tot doodslag Agente, vluchten voor politie onder schot, Spookrijden met meer dan 50 km te hard', 'Mag nog even gaan zitten voor heel wat weken', 1610224630),
(197, '9192159d0659e24363941e4a5989f6de767a24d0', '', 'Carthief+ niet meewerken met arrestatie', '60 weken voorwaardelijke straf', 1610301249),
(199, '46631935188e9bbdae37832caa3bd61f726a88a3', '', 'Meneer rijdt meer dan 100 km/h te hard door de stad, heeft geen rijbewijs. Bij controle vlucht meneer in zijn groene Mercedes-Benz AMG GTR.', '', 1610402007),
(200, '2db1c2ab7e16613ea1a3daa05d27997cb9a8d860', '', 'Persoon rijdt in een rode Audi A6 met kenteken JVZ 499 en vraagt op Blokkenpark mensen of hij een wapen (mes) kan kopen', '', 1610469163),
(201, '813e3d3bcc767afc14086f728359b92841a7365f', '', 'Meneer maakt op 13/01 rond 12:25 uur een 112-melding met: \'Kom me wiet maar halen\'', 'Persoon mogelijk in bezit van drugs (wiet)', 1610537761),
(202, '4d8985e09ecc3d7f8b4a30e160083153f4fd49e4', '', 'Betrokken bij gijzeling', '', 1610568670),
(204, '13fca1db700f16b40d9ce296831de0469a4beecd', '', 'heb me even laten gaan ', '', 1611663786),
(205, '9ca81bb8024bc476ebce033955d1501e522800c4', '', 'Test', 'test', 1611677509);

--
-- Indexen voor geëxporteerde tabellen
--

--
-- Indexen voor tabel `pois`
--
ALTER TABLE `pois`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT voor geëxporteerde tabellen
--

--
-- AUTO_INCREMENT voor een tabel `pois`
--
ALTER TABLE `pois`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=206;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
