-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Gegenereerd op: 11 feb 2021 om 11:04
-- Serverversie: 5.7.31
-- PHP-versie: 7.4.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `meosshop_work`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `vois`
--

CREATE TABLE `vois` (
  `id` bigint(20) NOT NULL,
  `vehicle_id` varchar(225) NOT NULL,
  `image` mediumtext NOT NULL,
  `reason` mediumtext NOT NULL,
  `notes` mediumtext NOT NULL,
  `look` mediumtext NOT NULL,
  `dateline` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `vois`
--

INSERT INTO `vois` (`id`, `vehicle_id`, `image`, `reason`, `notes`, `look`, `dateline`) VALUES
(156, 'NEK 731', '', 'Voertuig gezien op verdachte locatie \'opium pluk\'', '', '', 1608385032),
(158, 'JBH 002', '', 'Voertuig gezien op verdachte locatie \'opium pluk\'', '', '', 1608385055),
(160, 'KXZ 716', '', 'Voertuig gezien op verdachte locatie \'opium pluk\'', '', '', 1608385083),
(163, 'OUY 708', '', 'Voertuig gezien op verdachte locatie \'opium pluk\'', '', '', 1608385110),
(164, 'WRN 486', '', 'Voertuig gezien op verdachte locatie \'opium pluk\'', '', '', 1608385121),
(165, 'PKK 821', '', 'Voertuig gezien op verdachte locatie \'opium pluk\'', '', '', 1608385133),
(166, 'LGM 945', '', 'Voertuig gezien op verdachte locatie \'coke verpak\'', '', '', 1608385160),
(168, 'SPI 056', '', 'Gijzelen van een burger', 'Vuurwapen gevaarlijk', 'Goude lamborghini SVJ', 1608417566),
(171, 'MKD 885', '', 'Voertuig kapot aangetroffen (niet op slot) met wat coke in de kofferbak', '', 'Blauwe Audi', 1608569056),
(174, 'RDX 924', '', 'Voertuig meerdere keren gezien op drugs locaties', '', 'Rode Nissan Titan met dollar tekens in zijn velg', 1608890592),
(175, 'ZJV 459', '', 'Voertuig op 25-12 om 11:00 uur gezien op locatie \'wiet verpak\'', '', '', 1608890617),
(176, 'BSL 598', '', 'Voertuig op 25-12 om 11:00 uur gezien op locatie \'wiet verpak\'', '', '', 1608890626),
(177, 'JJP 430', '', 'Voertuig op 25-12 om 11:00 uur gezien op locatie \'wiet verpak\'', '', '', 1608890635),
(179, 'QQQ 959', '', 'Voertuig rijdt zeer hard door de stad, roekeloos rijgedrag', 'Boetes uitgeschreven via MEOS. Observatie door de politiehelikopter (Benno)', 'Mercedes AMG', 1608891103),
(180, 'XNV 176', '', 'Voertuig rijdt zeer hard door de stad, roekeloos rijgedrag', 'Boetes uitgeschreven via MEOS. Observatie door de politiehelikopter (Benno)', 'Lage (mogelijk groene) sportwagen', 1608891131),
(181, 'WQP 103', '', 'Betrokken bij overval op Tequila-la', 'Op naam van Vis Slender', 'Zwart/gouden Lamborghini SVJ', 1609069363),
(182, 'SHB 464', '', 'Grote hoeveelheid drugs in deze auto aangetroffen', 'Op naam van Bas Woods', 'Zwarte Opel Corsa', 1609101253),
(183, 'VGN 517', '', 'Vluchten voor de politie', 'Reed weg, negeren van stopteken.', 'Blauwe bentley met zwarte spoiler', 1609152790),
(185, 'XII 199', '', 'Gezien op verdachte locatie, vluchten voor politie en 3 wapens op hem gericht.', 'Op naam van Sergio El Cassa', 'Grijze lamborghini', 1609270536),
(186, 'RHQ 824', '', 'Voertuig gespot op een drugs locatie \'opium verkoop\'', 'Persoon stond samen met 2 anderen', 'Zwarte Mercedes G63 AMG', 1609540309),
(187, 'JJX 428', '', '70 bundels met opium in voertuig', 'n.v.t.', 'zwart/donker grijze SVJ', 1609698675),
(188, 'QRA 539', '', 'vluchten voor politie', '', 'Grijs bruine lambo SVJ', 1609704607),
(189, 'FUZ 157', '', 'Persoon komt op het bureau aangifte doen. De bestuurder van dit voertuig zou hem hebben bedreigd met een vuurwapen.', 'Mogelijk vuurwapengevaarlijk. Aangifte gedaan door dhr. Roy Makkers', 'Grijze Audi R8', 1609857400),
(190, 'XII 199', '', 'Betrokken bij overval Yellowjack', '', 'Grijze lamborghini', 1609858366),
(191, 'MBA 570', '', 'Voertuig aangetroffen op verdachte locatie \'wiet verkoop\' ', '', 'Tesla Model S', 1609875995),
(193, 'JJV 200', '', 'Burger maakt een melding dat de persoon in dit voertuig iemand heeft neergestoken', 'Mogelijk vuurwapengevaarlijk', '', 1609931557),
(194, 'OMD 098', '', 'Medeplichtig bij overval Lifeinvader', 'Op de naam van Roger Jos', 'Grijze auto ', 1610006731),
(195, 'ONO 387', '', 'Betrokken overval oud politiebureau', 'Op de naam van Kobe Festa', '', 1610006909),
(196, 'SJK 150', '', 'Betrokken overval oud politiebureau', 'Op de naam van Henki Sender', '', 1610006957),
(197, 'KBI 955', '', 'Betrokken overval oud politiebureau', 'Op de naam van Sjaak de Sinterklaas', 'Zwarte Range Rover', 1610007041),
(198, 'XDN 408', '', 'Betrokken overval oud politiebureau', 'Op de naam van Jaap de Kikker', 'Zwarte Range Rover', 1610007091),
(199, 'XDN 408', '', 'Betrokken overval oud politiebureau', 'Op de naam van Jaap de Kikker', 'Zwarte Range Rover', 1610007093),
(200, 'HMG 598', '', 'Betrokken overval oud politiebureau', 'Op de naam van Roger Jos', 'Grijze lamborghini SVJ', 1610007170),
(201, 'MEE 732', '', 'Betrokken overval oud politiebureau', 'Op de naam van Young Soldier Jurro', 'Zwart voertuig', 1610007201),
(202, 'XII 199', '', 'Betrokken overval oud politiebureau', 'Op de naam van Sergio Pecasso', 'Grijze lamborghini SVJ', 1610007225),
(203, 'XII 199', '', 'Betrokken overval oud politiebureau', 'Op de naam van Sergio Pecasso', 'Grijze lamborghini SVJ', 1610007227),
(204, 'VIM 796', '', 'Betrokken bij overval Lifeinvader', 'Op de naam van XXXXX TENTACION', 'Rood zwarte Ferrari Pista', 1610007322),
(205, 'MEE 732', '', 'Betrokken bij overval Lifeinvader', 'Op de naam van Jurro is Young Soldier', 'Zwart voertuig', 1610007361),
(206, 'HZZ 230', '', 'Gezien op een drugslocatie', 'Oud collega ', 'Zwarte rs7', 1610113638),
(208, 'TQL 171', '', 'Gezien op een drugslocatie', 'gezien op coke pluk', 'lamborghini licht zwart', 1610113756),
(209, 'OWA 053', '', 'Gezien op een drugslocatie', 'gezien op coke pluk', 'blauwe sportwagen', 1610113789),
(210, 'SKG 332', '', 'Gezien op een drugslocatie', 'gezien op coke pluk', 'grijse a6 ', 1610113860),
(211, 'UHV 402', '', 'Gezien op een drugslocatie', 'gezien op coke verkoop', 'zwarte g65 amg ', 1610113918),
(212, 'PDI 434', '', 'Gezien op een drugslocatie', 'gezien op coke verkoop', '4 persoons wagen ', 1610113955),
(213, 'RNA 547', '', 'Medeplichtig aan een carthief', 'Is heel snel', 'Blauwe audi R8', 1610126906),
(215, 'IQB 545', '', 'Voertuig gezien op verdachte locatie \'coke pluk\'', '', 'Groene Citroen Berlingo', 1610275813),
(216, 'GUN 339', '', 'Voertuig gezien op verdachte locatie \'coke pluk\'', '', 'Grijze BMW', 1610275830),
(217, 'ZEA 286', '', 'Voertuig gezien op verdachte locatie \'coke pluk\'', '', 'Rode Audi RS6', 1610276104),
(218, 'QRM 549', '', 'Voertuig gezien op verdachte locatie \'coke pluk\'', '', 'Mercedes / Schafter', 1610276125),
(219, 'ECJ 127', '', 'Voertuig gezien op verdachte locatie \'coke pluk\'', '', 'Rode Porsche', 1610276143),
(220, 'ZZV 484', '', 'Voertuig gezien op verdachte locatie \'coke pluk\'', '', 'Donkerblauwe Mercedes AMG', 1610276166),
(221, 'LPS 151', '', 'Motorfiets rijdt zonder kenteken rond', '', 'Blauwe Yamaha R6', 1610478290),
(222, '2FAT4YOU', '', 'Test', 'Niks', 'Geel', 1610685882),
(223, '2FAT4YOU', '', 'testtt', 'jajajaja', 'rood', 1610834526),
(224, '2FAT4YOU', '', 'adsad', 'sdasdadsd', 'adsads', 1610904860),
(225, 'ADT 052', '', 'Rijden door de menigte', 'Geeft geen aanleiding tot stoppen.', 'Zwart', 1610969944);

--
-- Indexen voor geëxporteerde tabellen
--

--
-- Indexen voor tabel `vois`
--
ALTER TABLE `vois`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT voor geëxporteerde tabellen
--

--
-- AUTO_INCREMENT voor een tabel `vois`
--
ALTER TABLE `vois`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=226;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
